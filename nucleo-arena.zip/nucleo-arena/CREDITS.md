# Créditos de modelos 3D

Los modelos de los coches son mallas low-poly convertidas (horneadas, recoloreadas con el color del equipo y
reescaladas) a partir de estos trabajos de Sketchfab:

- **NOMAD** — "Blue Lowpoly Car" por Tutku Figen (https://sketchfab.com/icypassionis),
  https://sketchfab.com/3d-models/blue-lowpoly-car-f83bc865c80a477bae6b6b379d186c56 — licencia **CC-BY-SA-4.0**
  (https://creativecommons.org/licenses/by-sa/4.0/). Esta versión modificada (`models/nomad.mesh`) se comparte
  bajo la misma licencia CC-BY-SA-4.0.
- **CARIBE** — "Low Poly Fiat Uno" por yartic (https://sketchfab.com/yartic),
  https://sketchfab.com/3d-models/low-poly-fiat-uno-a5158a6a0b344c5e9bf7c731aa4abb52 — licencia **CC-BY-4.0**
  (http://creativecommons.org/licenses/by/4.0/). Modificado (`models/caribe.mesh`).
