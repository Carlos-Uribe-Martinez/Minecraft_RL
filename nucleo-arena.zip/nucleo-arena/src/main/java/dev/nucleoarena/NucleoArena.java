package dev.nucleoarena;

import dev.nucleoarena.arena.ArenaCommands;
import dev.nucleoarena.arena.MatchManager;
import dev.nucleoarena.entity.BoostPadEntity;
import dev.nucleoarena.entity.CustomBallEntity;
import dev.nucleoarena.entity.VehicleEntity;
import dev.nucleoarena.input.VehicleInput;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;

import static dev.nucleoarena.physics.PhysicsConstants.BOX_SIZE;

public class NucleoArena implements ModInitializer {
    public static final String MOD_ID = "nucleo_arena";

    // Nomad y Caribe comparten clase/hitbox; el modelo se elige con VehicleEntity.Kind.
    public static final EntityType<VehicleEntity> VEHICLE = register("vehicle",
            EntityType.Builder.<VehicleEntity>of(VehicleEntity::new, MobCategory.MISC)
                    .sized(BOX_SIZE, BOX_SIZE)
                    .passengerAttachments(0.2f)
                    .clientTrackingRange(12)
                    .updateInterval(1));

    public static final EntityType<CustomBallEntity> BALL = register("ball",
            EntityType.Builder.<CustomBallEntity>of(CustomBallEntity::new, MobCategory.MISC)
                    .sized(1.8f, 1.8f)
                    .clientTrackingRange(16)
                    .updateInterval(1));

    public static final EntityType<BoostPadEntity> BOOST_PAD = register("boost_pad",
            EntityType.Builder.<BoostPadEntity>of(BoostPadEntity::new, MobCategory.MISC)
                    .sized(1.4f, 0.2f)
                    .clientTrackingRange(10)
                    .updateInterval(20));

    private static <T extends Entity> EntityType<T> register(String id, EntityType.Builder<T> builder) {
        ResourceKey<EntityType<?>> key = ResourceKey.create(Registries.ENTITY_TYPE,
                Identifier.fromNamespaceAndPath(MOD_ID, id));
        return Registry.register(BuiltInRegistries.ENTITY_TYPE, key, builder.build(key));
    }

    @Override
    public void onInitialize() {
        VehicleInput.registerNetworking();
        CommandRegistrationCallback.EVENT.register((dispatcher, buildContext, environment) -> ArenaCommands.register(dispatcher));
        ServerTickEvents.END_SERVER_TICK.register(MatchManager::tick);
    }
}
