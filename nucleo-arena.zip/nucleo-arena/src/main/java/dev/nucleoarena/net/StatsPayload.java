package dev.nucleoarena.net;

import dev.nucleoarena.NucleoArena;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

import java.util.ArrayList;
import java.util.List;

/** Servidor → jugadores: marcador y estadísticas por jugador (una fila por jugador, sin repetir). */
public record StatsPayload(int scoreBlue, int scoreOrange, int secondsLeft, boolean overtime, List<Row> rows)
        implements CustomPacketPayload {

    public record Row(String name, int team, int goals, int assists, int shots, int saves, int demos) {}

    public static final Type<StatsPayload> TYPE =
            new Type<>(Identifier.fromNamespaceAndPath(NucleoArena.MOD_ID, "stats"));

    public static final StreamCodec<RegistryFriendlyByteBuf, StatsPayload> CODEC = StreamCodec.of(
            (buf, p) -> {
                buf.writeVarInt(p.scoreBlue); buf.writeVarInt(p.scoreOrange);
                buf.writeVarInt(p.secondsLeft); buf.writeBoolean(p.overtime);
                buf.writeVarInt(p.rows.size());
                for (Row r : p.rows) {
                    buf.writeUtf(r.name); buf.writeVarInt(r.team); buf.writeVarInt(r.goals); buf.writeVarInt(r.assists);
                    buf.writeVarInt(r.shots); buf.writeVarInt(r.saves); buf.writeVarInt(r.demos);
                }
            },
            buf -> {
                int a = buf.readVarInt(), b = buf.readVarInt(), t = buf.readVarInt();
                boolean ot = buf.readBoolean();
                int n = buf.readVarInt();
                List<Row> rows = new ArrayList<>();
                for (int i = 0; i < n; i++)
                    rows.add(new Row(buf.readUtf(), buf.readVarInt(), buf.readVarInt(), buf.readVarInt(), buf.readVarInt(), buf.readVarInt(), buf.readVarInt()));
                return new StatsPayload(a, b, t, ot, rows);
            });

    @Override public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
