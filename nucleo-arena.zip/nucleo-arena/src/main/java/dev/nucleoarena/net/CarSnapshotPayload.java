package dev.nucleoarena.net;

import dev.nucleoarena.NucleoArena;
import dev.nucleoarena.physics.CarState;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/**
 * Servidor → conductor, cada tick: estado autoritativo del coche tras procesar la entrada {@code ackSeq}.
 * El cliente lo compara con lo que predijo para ese mismo seq y, si difiere, rebobina y re-simula.
 */
public record CarSnapshotPayload(int entityId, int ackSeq, CarState state) implements CustomPacketPayload {
    public static final Type<CarSnapshotPayload> TYPE =
            new Type<>(Identifier.fromNamespaceAndPath(NucleoArena.MOD_ID, "car_snapshot"));

    public static final StreamCodec<RegistryFriendlyByteBuf, CarSnapshotPayload> CODEC = StreamCodec.of(
            (buf, p) -> { buf.writeVarInt(p.entityId); buf.writeInt(p.ackSeq); p.state.write(buf); },
            buf -> new CarSnapshotPayload(buf.readVarInt(), buf.readInt(), CarState.read(buf)));

    @Override public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
