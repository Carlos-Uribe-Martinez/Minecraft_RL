package dev.nucleoarena.net;

import dev.nucleoarena.NucleoArena;
import dev.nucleoarena.physics.CarState;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/**
 * Servidor → conductor, cada tick: estado autoritativo del coche tras procesar la entrada {@code ackSeq}.
 * {@code frozen}: el servidor tiene el coche congelado (cuenta atrás) · {@code reset}: el coche acaba de ser
 * recolocado (saque, reaparición): el cliente descarta la predicción y parte de este estado.
 * El cliente lo compara con lo que predijo para ese mismo seq y, si difiere, rebobina y re-simula.
 */
public record CarSnapshotPayload(int entityId, int ackSeq, CarState state, boolean frozen, boolean reset) implements CustomPacketPayload {
    public static final Type<CarSnapshotPayload> TYPE =
            new Type<>(Identifier.fromNamespaceAndPath(NucleoArena.MOD_ID, "car_snapshot"));

    public static final StreamCodec<RegistryFriendlyByteBuf, CarSnapshotPayload> CODEC = StreamCodec.of(
            (buf, p) -> { buf.writeVarInt(p.entityId); buf.writeInt(p.ackSeq); p.state.write(buf);
                          buf.writeByte((p.frozen ? 1 : 0) | (p.reset ? 2 : 0)); },
            buf -> {
                int id = buf.readVarInt(); int ack = buf.readInt(); CarState st = CarState.read(buf);
                int f = buf.readByte();
                return new CarSnapshotPayload(id, ack, st, (f & 1) != 0, (f & 2) != 0);
            });

    @Override public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
