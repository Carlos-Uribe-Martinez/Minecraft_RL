package dev.nucleoarena.net;

import dev.nucleoarena.NucleoArena;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/** Cliente → servidor: botones de entrenamiento (0 balón delante · 1 levantar · 2 centro hacia mí · 3 coche rival). */
public record TrainingPayload(int action) implements CustomPacketPayload {
    public static final Type<TrainingPayload> TYPE =
            new Type<>(Identifier.fromNamespaceAndPath(NucleoArena.MOD_ID, "training"));

    public static final StreamCodec<RegistryFriendlyByteBuf, TrainingPayload> CODEC = StreamCodec.of(
            (buf, p) -> buf.writeVarInt(p.action),
            buf -> new TrainingPayload(buf.readVarInt()));

    @Override public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
