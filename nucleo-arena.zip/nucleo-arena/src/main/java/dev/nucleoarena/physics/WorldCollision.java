package dev.nucleoarena.physics;

import net.minecraft.core.Direction;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.StairBlock;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

import java.util.ArrayList;
import java.util.List;

/**
 * Colisión con el mundo SIN depender de Entity.move (que aplica escalones, cuerdas, telarañas, eventos de
 * vibración…). Así servidor y cliente simulan exactamente igual y la predicción es determinista.
 *
 * ⚠ Verificar en 26.2: Level.getBlockCollisions(Entity, AABB), Shapes.collide(Axis, AABB, Iterable, double)
 *   y el constructor ClipContext(Vec3, Vec3, Block, Fluid, CollisionContext).
 */
public final class WorldCollision {
    private WorldCollision() {}

    /** Barrido de {@code box} por {@code delta}; devuelve el desplazamiento REAL (≤ delta por eje). */
    public static Vec3 move(Level level, AABB box, Vec3 delta) {
        double dx = delta.x, dy = delta.y, dz = delta.z;
        List<VoxelShape> shapes = new ArrayList<>();
        for (VoxelShape s : level.getBlockCollisions(null, box.expandTowards(delta))) shapes.add(s);
        if (shapes.isEmpty()) return delta;

        AABB b = box;
        if (dy != 0.0) { dy = Shapes.collide(Direction.Axis.Y, b, shapes, dy); b = b.move(0.0, dy, 0.0); }
        boolean zFirst = Math.abs(dx) < Math.abs(dz);          // mismo orden que vanilla
        if (zFirst && dz != 0.0) { dz = Shapes.collide(Direction.Axis.Z, b, shapes, dz); b = b.move(0.0, 0.0, dz); }
        if (dx != 0.0)           { dx = Shapes.collide(Direction.Axis.X, b, shapes, dx); b = b.move(dx, 0.0, 0.0); }
        if (!zFirst && dz != 0.0){ dz = Shapes.collide(Direction.Axis.Z, b, shapes, dz); }
        return new Vec3(dx, dy, dz);
    }

    /** Resultado de {@link #moveStep}: desplazamiento real y si se subió un peldaño / se pegó al suelo. */
    public record Step(Vec3 moved, boolean stepped) {}

    /**
     * Como {@link #move} pero "andando": si un obstáculo de ≤ stepH bloquea el avance horizontal, la caja
     * sube sobre él (como el stepHeight de un mob) y vuelve a apoyarse. Además, si {@code snapDown},
     * al bajar un peldaño se pega al suelo en vez de saltar. El movimiento se parte en tramos cortos para
     * poder subir varios peldaños en un mismo tick.
     */
    public static Step moveStep(Level level, AABB box, Vec3 delta, double stepH, boolean snapDown, double chunk) {
        double horiz = Math.max(Math.abs(delta.x), Math.abs(delta.z));
        int n = Math.max(1, (int) Math.ceil(horiz / chunk));
        Vec3 sub = delta.scale(1.0 / n);
        Vec3 total = Vec3.ZERO;
        boolean any = false;
        AABB b = box;
        for (int i = 0; i < n; i++) {
            Vec3 m = move(level, b, sub);
            boolean hBlocked = Math.abs(sub.x - m.x) > 1.0E-6 || Math.abs(sub.z - m.z) > 1.0E-6;
            boolean did = false;
            if (hBlocked && sub.y <= 1.0E-6 && stepH > 0.0) {
                Vec3 up = move(level, b, new Vec3(0.0, stepH, 0.0));
                if (up.y > 1.0E-4) {
                    AABB raised = b.move(up);
                    Vec3 h = move(level, raised, new Vec3(sub.x, 0.0, sub.z));
                    if (Math.hypot(h.x, h.z) > Math.hypot(m.x, m.z) + 1.0E-4) {
                        AABB over = raised.move(h);
                        Vec3 down = move(level, over, new Vec3(0.0, -up.y + Math.min(sub.y, 0.0), 0.0));
                        m = new Vec3(h.x, up.y + down.y, h.z);
                        did = true;
                    }
                }
            } else if (snapDown && sub.y <= 1.0E-6 && !hBlocked) {
                AABB after = b.move(m);
                Vec3 down = move(level, after, new Vec3(0.0, -stepH, 0.0));
                // solo se pega si de verdad hay suelo a menos de stepH (si no, está en el aire)
                if (down.y > -stepH + 1.0E-4 && down.y < -0.02) { m = m.add(0.0, down.y, 0.0); did = true; }
            }
            any |= did;
            total = total.add(m);
            b = b.move(m);
        }
        return new Step(total, any);
    }

    /** ¿Es el bloque una escalera? (para las sondas del coche) */
    public static boolean isStair(Level level, net.minecraft.core.BlockPos pos) {
        return level.getBlockState(pos).getBlock() instanceof StairBlock;
    }

    /** Como clipNormal pero indica también si lo golpeado es una escalera. null si no golpea nada. */
    public record Hit(Vec3 normal, boolean stair) {}
    public static Hit clipHit(Level level, Vec3 from, Vec3 to) {
        BlockHitResult hit = level.clip(new ClipContext(from, to,
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, CollisionContext.empty()));
        if (hit.getType() != HitResult.Type.BLOCK) return null;
        Direction d = hit.getDirection();
        return new Hit(new Vec3(d.getStepX(), d.getStepY(), d.getStepZ()), isStair(level, hit.getBlockPos()));
    }

    /** Normal (de la cara de bloque golpeada) del primer choque del rayo, o null si no golpea nada. */
    public static Vec3 clipNormal(Level level, Vec3 from, Vec3 to) {
        BlockHitResult hit = level.clip(new ClipContext(from, to,
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, CollisionContext.empty()));
        if (hit.getType() != HitResult.Type.BLOCK) return null;
        Direction d = hit.getDirection();
        return new Vec3(d.getStepX(), d.getStepY(), d.getStepZ());
    }
}
