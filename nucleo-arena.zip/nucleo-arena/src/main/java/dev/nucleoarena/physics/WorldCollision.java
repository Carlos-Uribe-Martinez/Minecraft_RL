package dev.nucleoarena.physics;

import net.minecraft.core.Direction;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

import java.util.ArrayList;
import java.util.List;

/**
 * Colisión con el mundo SIN depender de Entity.move (que aplica escalones, cuerdas, telarañas, eventos de
 * vibración…). Así servidor y cliente simulan exactamente igual y la predicción es determinista.
 *
 * ⚠ Verificar en 26.2: Level.getBlockCollisions(Entity, AABB), Shapes.collide(Axis, AABB, Iterable, double)
 *   y el constructor ClipContext(Vec3, Vec3, Block, Fluid, CollisionContext).
 */
public final class WorldCollision {
    private WorldCollision() {}

    /** Barrido de {@code box} por {@code delta}; devuelve el desplazamiento REAL (≤ delta por eje). */
    public static Vec3 move(Level level, AABB box, Vec3 delta) {
        double dx = delta.x, dy = delta.y, dz = delta.z;
        List<VoxelShape> shapes = new ArrayList<>();
        for (VoxelShape s : level.getBlockCollisions(null, box.expandTowards(delta))) shapes.add(s);
        if (shapes.isEmpty()) return delta;

        AABB b = box;
        if (dy != 0.0) { dy = Shapes.collide(Direction.Axis.Y, b, shapes, dy); b = b.move(0.0, dy, 0.0); }
        boolean zFirst = Math.abs(dx) < Math.abs(dz);          // mismo orden que vanilla
        if (zFirst && dz != 0.0) { dz = Shapes.collide(Direction.Axis.Z, b, shapes, dz); b = b.move(0.0, 0.0, dz); }
        if (dx != 0.0)           { dx = Shapes.collide(Direction.Axis.X, b, shapes, dx); b = b.move(dx, 0.0, 0.0); }
        if (!zFirst && dz != 0.0){ dz = Shapes.collide(Direction.Axis.Z, b, shapes, dz); }
        return new Vec3(dx, dy, dz);
    }

    /** Normal (de la cara de bloque golpeada) del primer choque del rayo, o null si no golpea nada. */
    public static Vec3 clipNormal(Level level, Vec3 from, Vec3 to) {
        BlockHitResult hit = level.clip(new ClipContext(from, to,
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, CollisionContext.empty()));
        if (hit.getType() != HitResult.Type.BLOCK) return null;
        Direction d = hit.getDirection();
        return new Vec3(d.getStepX(), d.getStepY(), d.getStepZ());
    }
}
