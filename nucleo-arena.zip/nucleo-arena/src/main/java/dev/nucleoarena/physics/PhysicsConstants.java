package dev.nucleoarena.physics;

/**
 * Todas las constantes de física del mod, EN UNIDADES DE MINECRAFT:
 *   posición = bloques (1 bloque = 1 m)
 *   velocidad = bloques / tick
 *   aceleración = bloques / tick²
 *
 * Conversión desde SI (20 TPS):  v[b/t] = v[m/s] / 20     a[b/t²] = a[m/s²] / 400
 *
 * ⚠ NOTA: la especificación dice "6.5 m/s² (0.325 m/tick)". 0.325 es el cambio de
 * velocidad en m/s POR TICK (6.5/20). La aceleración correcta por tick en la unidad
 * interna de Minecraft (bloques/tick de velocidad) es 6.5/400 = 0.01625.
 * Si se aplicara 0.325 directamente a deltaMovement, la gravedad sería 20x mayor.
 */
public final class PhysicsConstants {
    private PhysicsConstants() {}

    // ───────────── Conversión ─────────────
    public static final double TPS = 20.0;
    public static double accel(double metersPerSec2) { return metersPerSec2 / (TPS * TPS); }
    public static double speed(double metersPerSec)  { return metersPerSec / TPS; }

    // ───────────── Mundo ─────────────
    public static final double GRAVITY = accel(6.5);                 // 0.01625 b/t²

    // ───────────── Balón ─────────────
    public static final double BALL_RADIUS         = 1.5;            // esfera de 3 × 3 bloques (AABB 3.0³)
    public static final double BALL_MAX_SPEED      = speed(60.0);    // 3.0 b/t (límite estricto)
    public static final double BALL_RESTITUTION    = 0.60;
    public static final int    BALL_SUBSTEPS       = 4;              // anti-tunneling (coche 1.15 + balón 3.0 b/t)
    public static final double BALL_REST_VN        = 0.04;           // bajo esto no hay rebote (evita jitter)
    public static final double BALL_ROLL_FRICTION  = 0.995;          // por tick, solo con contacto de suelo
    public static final double BALL_TRAIL_MIN_MS   = 20.0;           // m/s para empezar la estela
    public static final double BALL_TRAIL_FULL_MS  = 60.0;           // m/s para estela al máximo

    // Impacto coche→balón: coeficiente de restitución efectivo por zona (× 0.6)
    public static final double ZONE_TRANSFER_FRONT_TOP = 1.00;       // defensa y techo: 100 %
    public static final double ZONE_TRANSFER_SIDE_REAR = 0.70;
    public static final double ZONE_TRANSFER_BOTTOM    = 0.00;       // ruedas / bajos: amortigua
    public static final double BOTTOM_TANGENT_DAMP     = 0.15;
    public static final double DRIBBLE_REST_VN         = 0.06;       // contacto casi en reposo sobre el techo
    public static final double DRIBBLE_FRICTION        = 0.10;       // fracción de vel. tangencial relativa igualada/tick
    public static final double CAR_RECOIL              = 0.03;       // reacción del balón sobre el coche

    // ───────────── Vehículo: velocidades ─────────────
    public static final double CAR_MAX_SPEED  = speed(23.0);         // 1.15 b/t
    public static final double SUPERSONIC     = speed(22.0);         // 1.10 b/t
    public static final double PASSIVE_MAX    = speed(14.1);         // tope sin boost/flips (1410 uu/s)

    /**
     * Aceleración pasiva de tracción: 16 m/s² (1600 uu/s² del juego original).
     * La especificación decía 1.6, que tarda ~9 s en llegar a 14.1 m/s y se siente injugable;
     * se interpretó como errata. Para volver al valor literal: accel(1.6).
     */
    public static final double THROTTLE_ACCEL = accel(16.0);
    public static final double BRAKE_ACCEL    = accel(35.0);
    public static final double COAST_DECEL    = accel(5.25);

    // ───────────── Boost ─────────────
    public static final double BOOST_ACCEL         = accel(11.3);    // un poco más de impulso (antes 9.91 m/s²)
    public static final float  BOOST_CAPACITY      = 100f;
    public static final float  BOOST_START         = 33.3f;
    public static final float  BOOST_COST_PER_TICK = (float) (29.0 / TPS); // dura ~15% más (antes 33.3 por segundo)

    // ───────────── Saltos / Flip ─────────────
    public static final int    FLIP_WINDOW_TICKS  = 25;              // 1.25 s
    public static final int    FLIP_UNLIMITED     = -1;              // estado tras Flip Reset
    public static final double JUMP_IMPULSE       = speed(2.92);
    public static final double JUMP_HOLD_ACCEL    = accel(14.0);     // saltar más alto manteniendo el botón
    public static final int    JUMP_HOLD_TICKS    = 4;
    public static final double DODGE_IMPULSE      = speed(5.0);
    public static final float  DODGE_DEADZONE     = 0.10f;
    public static final int    FLIP_ANIM_TICKS    = 13;              // giro visual del dodge (~0.65 s)
    public static final float  FLIP_ANGULAR       = (float) (2.0 * Math.PI / FLIP_ANIM_TICKS);
    public static final int    JUMP_GRACE_TICKS   = 3;               // ignora contacto justo tras saltar
    /** Salir de una superficie sin saltar también concede la ventana de 1.25 s (como el original). */
    public static final boolean FALL_OFF_GRANTS_FLIP_WINDOW = true;

    // ───────────── Conducción ─────────────
    public static final double NORMAL_GRIP          = 0.90;          // fracción de vel. lateral eliminada/tick
    public static final double HANDBRAKE_GRIP       = 0.04;          // power-slide
    public static final double STEER_MAX            = 0.11;          // rad/tick a baja velocidad
    public static final double HANDBRAKE_STEER_MULT = 1.5;       // derrape
    public static final double STEP_HEIGHT          = 1.05;      // el coche sube escalones/escaleras de hasta 1 bloque
    public static final float  AIR_ANGULAR          = (float) (5.5 / TPS); // rad/tick pitch/yaw/roll
    public static final float  ALIGN_RATE           = 0.35f;         // slerp hacia la normal de superficie

    // ───────────── Paredes / techo ─────────────
    public static final double WALL_STICK_SPEED = speed(5.0);        // 0.25 b/t
    public static final double WALL_SLIP_TAU    = 10.0;              // ticks; g_eff = g·(1 − e^(−t/τ))
    public static final double WALL_NORMAL_Y_MAX = 0.70;             // normal.y < esto ⇒ pared/techo
    /** Fuerza hacia la superficie mientras hay contacto: sin ella el coche se despega de paredes/techo. */
    public static final double STICK_ACCEL     = accel(6.5);
    public static final double CORNER_MIN_INTO  = speed(2.0);
    public static final double CORNER_KEEP      = 0.97;
    public static final int    TRANSITION_TICKS = 6;

    // ───────────── Reposo / auto-enderezado / techo ─────────────
    public static final double REST_FRICTION        = 0.10;   // fracción de vel. horizontal perdida/tick al estar apoyado sin ruedas
    public static final double REST_MIN_NORMAL_Y    = 0.5;    // la superficie de apoyo debe ser "suelo"
    public static final float  RIGHT_RATE           = 0.12f;  // velocidad de enderezado al pulsar avance/salto
    public static final float  SETTLE_RATE          = 0.25f;  // asentarse sobre puerta/techo al caer
    public static final double CEILING_NORMAL_Y     = -0.5;   // normal.y menor ⇒ techo
    public static final double CEILING_STICK_SPEED  = speed(7.0);
    public static final int    CEILING_MAX_TICKS    = 100;    // 5 s máx. pegado al techo aunque lleve velocidad

    public static final float  AIR_ROLL_MULT        = 1.0f;   // (sin cambio: el air roll se queda como estaba)
    public static final int    WALL_MAX_TICKS       = 160;    // 8 s máx. pegado a una pared aunque lleve velocidad
    public static final double BALL_PICK_RADIUS     = 1.0;    // hitbox ampliada para golpearla con el brazo
    public static final double BALL_MOB_REACH       = 0.7;    // alcance extra para dañar mobs
    public static final double BALL_CLIMB_MIN       = speed(11.0);   // rodando a más de esto, sube por la pared
    public static final double BALL_CLIMB_GRAVITY   = 0.12;   // fracción de gravedad mientras trepa
    public static final double BALL_CLIMB_FRICTION  = 0.985;  // pierde velocidad poco a poco pegada a la pared
    public static final int    OVERTIME_MAX_TICKS   = 15 * 60 * 20;
    public static final double ROOF_DRIVE_FACTOR    = 0.6;    // tracción al ir boca abajo / de costado

    // ───────────── Entorno (mobs / bloques) ─────────────
    public static final double CAR_HURT_MIN_MS      = 6.0;    // m/s mínimos para dañar mobs con el coche
    public static final double CAR_HURT_PER_MS      = 0.9;    // daño por m/s sobre el mínimo
    public static final double BALL_HURT_MIN_MS     = 8.0;
    public static final double BALL_HURT_PER_MS     = 0.55;   // a 60 m/s ≈ 28 de daño
    public static final double BALL_BREAK_MIN_MS    = 12.0;   // por debajo no rompe bloques
    public static final double BALL_BREAK_HARDNESS_PER_MS = 0.15; // dureza máx. = (m/s − 10)·0.15
    public static final double BALL_HIT_BASE        = 0.35;   // impulso mínimo de un golpe (b/t)
    public static final double BALL_HIT_PER_DAMAGE  = 0.09;   // impulso extra por punto de daño

    // ───────────── Hitbox y sondas ─────────────
    /** AABB cúbica (Minecraft no rota AABBs): igual en las 3 dimensiones para que pared/suelo/techo sean simétricos. */
    /** Escala de los coches respecto al diseño original (el doble). */
    public static final float  CAR_SCALE     = 2.0f;
    public static final float  BOX_SIZE      = 1.6f * CAR_SCALE;     // 3.2
    public static final double PROBE_LENGTH  = 1.0 * CAR_SCALE;      // medio cubo + 0.4 de tolerancia
    public static final int    WHEELS_REQUIRED = 3;                  // 4 para ser literal con la especificación
    public static final float[][] WHEEL_LOCAL = {                    // (izq, arriba, adelante) respecto al centro
            { 0.90f, 0f,  1.20f}, {-0.90f, 0f,  1.20f},
            { 0.90f, 0f, -1.20f}, {-0.90f, 0f, -1.20f}
    };
    /** OBB real del coche (para colisión con el balón), centrada abajo dentro de la AABB cúbica. */
    public static final float OBB_HALF_X = 0.55f, OBB_HALF_Y = 0.35f, OBB_HALF_Z = 0.80f;
    public static final float OBB_CENTER_Y = -0.45f;

    // ───────────── Demoliciones ─────────────
    public static final int    RESPAWN_TICKS  = 60;                  // 3 s
    public static final double DEMO_FRONT_DOT = 0.35;                // el atacante debe "apuntar" a la víctima

    // ───────────── BoostPads ─────────────
    public static final double PAD_RADIUS          = 1.5;
    public static final float  PAD_SMALL_AMOUNT    = 12f;
    public static final int    PAD_LARGE_COOLDOWN  = 260;            // 13 s
    public static final int    PAD_SMALL_COOLDOWN  = 110;            // 5.5 s

    // ───────────── Red / predicción en cliente ─────────────
    public static final int    INPUT_QUEUE_MAX     = 4;       // entradas pendientes en el servidor antes de descartar
    public static final int    HISTORY_FRAMES      = 128;     // historial de predicción (6.4 s)
    public static final double RECONCILE_POS_EPS   = 0.04;    // bloques de error tolerados
    public static final double RECONCILE_VEL_EPS   = 0.02;    // b/t
    public static final double RECONCILE_ROT_DOT   = 0.9998;  // |dot| mínimo entre cuaterniones
    public static final double SNAP_DISTANCE       = 3.0;     // por encima, se corrige de golpe (sin suavizado)
    public static final double ERROR_SMOOTH_DECAY  = 0.80;    // decaimiento por tick del error visual

    // ───────────── Arena ─────────────
    public static final double BALL_CENTER_Y_REST  = BALL_RADIUS;   // altura del centro del balón sobre el suelo en reposo
}
