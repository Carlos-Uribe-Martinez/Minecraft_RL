package dev.nucleoarena.physics;

import dev.nucleoarena.input.VehicleInput;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.joml.Quaternionf;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

import static dev.nucleoarena.physics.PhysicsConstants.*;

/**
 * Predicción en cliente + reconciliación con el servidor (CLIENTE, solo para el conductor local).
 *
 *  1. Cada tick de cliente: se simula la entrada con el MISMO CarPhysics y se guarda (seq, entrada, estado).
 *  2. El servidor responde con (ackSeq, estado). Se busca lo que predijimos para ackSeq.
 *  3. Si coincide (dentro de épsilon) no se hace nada. Si no: se parte del estado del servidor y se
 *     RE-SIMULAN las entradas posteriores a ackSeq (las que el servidor aún no había visto).
 *  4. El salto visual resultante se absorbe con un desplazamiento que decae (sin teletransportes).
 */
public final class CarPredictor {
    private record Frame(int seq, VehicleInput input, CarState after) {}

    private final ArrayDeque<Frame> frames = new ArrayDeque<>();
    public final CarState current = new CarState();
    private final CarState previous = new CarState();
    private boolean initialized;
    private int nextSeq;
    private Vec3 errorOffset = Vec3.ZERO;

    public boolean isInitialized() { return initialized; }

    /** Simula un tick con la entrada local. @return la entrada con su seq ya asignado (para enviar). */
    public VehicleInput step(Level level, VehicleInput raw, float steerMult, boolean frozen) {
        VehicleInput in = new VehicleInput(nextSeq++, raw.throttle(), raw.steer(), raw.jumpHeld(),
                raw.jumpPressed(), raw.boost(), raw.handbrake(), raw.airRoll());
        if (!initialized) return in;                        // esperando el primer estado del servidor

        previous.set(current);
        if (!frozen) CarPhysics.step(level, current, in, steerMult);
        frames.addLast(new Frame(in.seq(), in, current.copy()));
        while (frames.size() > HISTORY_FRAMES) frames.pollFirst();

        errorOffset = errorOffset.scale(ERROR_SMOOTH_DECAY);
        if (errorOffset.lengthSqr() < 1.0E-6) errorOffset = Vec3.ZERO;
        return in;
    }

    public void onServerState(Level level, int ackSeq, CarState server, float steerMult, boolean frozen) {
        if (!initialized) {
            current.set(server); previous.set(server);
            frames.clear();
            initialized = true;
            return;
        }

        while (!frames.isEmpty() && frames.peekFirst().seq() < ackSeq) frames.pollFirst();
        Frame match = (!frames.isEmpty() && frames.peekFirst().seq() == ackSeq) ? frames.pollFirst() : null;

        boolean far = current.center.distanceToSqr(server.center) > SNAP_DISTANCE * SNAP_DISTANCE;
        if (match != null && !match.after().differsFrom(server) && !far) return;   // predicción correcta
        if (match == null && !far) return;                  // sin referencia y sin gran error: seguimos

        Vec3 before = current.center;
        CarState rewound = server.copy();
        List<Frame> replay = new ArrayList<>(frames);
        frames.clear();
        for (Frame f : replay) {
            if (!frozen) CarPhysics.step(level, rewound, f.input(), steerMult);
            frames.addLast(new Frame(f.seq(), f.input(), rewound.copy()));
        }
        current.set(rewound);

        Vec3 err = before.subtract(current.center);
        if (far || err.lengthSqr() > SNAP_DISTANCE * SNAP_DISTANCE) {
            errorOffset = Vec3.ZERO;
            previous.set(current);
        } else {
            errorOffset = errorOffset.add(err);             // se desvanece poco a poco
        }
    }

    /** Centro de la AABB interpolado entre ticks (+ error de corrección que decae). */
    public Vec3 renderCenter(float pt) {
        return previous.center.lerp(current.center, pt).add(errorOffset);
    }

    public Quaternionf renderOrientation(float pt) {
        return new Quaternionf(previous.orient).slerp(current.orient, pt);
    }
}
