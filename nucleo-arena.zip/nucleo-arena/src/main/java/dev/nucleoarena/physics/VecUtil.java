package dev.nucleoarena.physics;

import net.minecraft.world.phys.Vec3;
import org.joml.Quaternionfc;
import org.joml.Vector3f;
import org.joml.Vector3fc;

/**
 * Puente entre Vec3 (Mojang, double) y JOML (float).
 *
 * Base local del vehículo (mano derecha):  LEFT=+X, UP=+Y, FORWARD=+Z
 *   LEFT × UP = FORWARD  → rotateX(+) = morro abajo (front flip), rotateY(+) = giro a la izquierda,
 *                           rotateZ(+) = balanceo a la derecha.
 * (En Minecraft un ente con yaw 0 mira a +Z y su izquierda es +X.)
 */
public final class VecUtil {
    private VecUtil() {}

    public static final Vec3 UP      = new Vec3(0, 1, 0);
    public static final Vec3 FORWARD = new Vec3(0, 0, 1);
    public static final Vec3 LEFT    = new Vec3(1, 0, 0);

    public static Vec3 vec(Vector3fc v)      { return new Vec3(v.x(), v.y(), v.z()); }
    public static Vector3f vec3f(Vec3 v)     { return new Vector3f((float) v.x, (float) v.y, (float) v.z); }

    /** Rota v por q (local → mundo). */
    public static Vec3 rotate(Quaternionfc q, Vec3 v) {
        return vec(q.transform(vec3f(v), new Vector3f()));
    }

    public static Vec3 clampLength(Vec3 v, double max) {
        double len = v.length();
        return len > max ? v.scale(max / len) : v;
    }

    /** Componente de v tangente al plano de normal n (n unitaria). */
    public static Vec3 tangent(Vec3 v, Vec3 n) {
        return v.subtract(n.scale(v.dot(n)));
    }
}
