package dev.nucleoarena.physics;

import dev.nucleoarena.input.VehicleInput;
import net.minecraft.util.Mth;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import static dev.nucleoarena.physics.PhysicsConstants.*;

/**
 * Física del coche: UN tick sobre un {@link CarState}. Determinista; se ejecuta igual en servidor y cliente.
 *
 * Pipeline:
 *   1 sondas de ruedas      5 gravedad (reglas de pared)      
 *   2 aterrizaje/despegue   6 tracción + agarre + adherencia
 *   3 orientación           7 boost
 *   4 salto / flip          8 límite → colisión → esquinas
 */
public final class CarPhysics {
    private CarPhysics() {}

    public static void step(Level level, CarState s, VehicleInput in, float steerMult) {
        Vec3 v = s.vel;

        // ── 1. Sondas de ruedas ──────────────────────────────────────────────
        Contact contact = probeSurface(level, s);
        boolean onSurface = contact.wheels >= WHEELS_REQUIRED;
        Vec3 normal = onSurface ? contact.normal : VecUtil.UP;

        if (s.jumpGraceTicks > 0) {                         // justo tras saltar: no cuenta como contacto
            s.jumpGraceTicks--;
            onSurface = false;
        } else if (!onSurface && s.transitionTicks > 0) {   // esquina/pared recién tomada: forzar normal
            s.transitionTicks--;
            onSurface = true;
            normal = s.transitionNormal;
        }

        // ── 2. Aterrizaje / despegue ─────────────────────────────────────────
        if (onSurface && !s.wasOnSurface) onLanded(s);
        else if (!onSurface && s.wasOnSurface) onLeftSurface(s);
        if (onSurface) s.surfaceNormal = normal;

        // ── 3. Orientación ───────────────────────────────────────────────────
        if (onSurface) alignToSurface(s, normal, s.transitionTicks > 0 ? 0.6f : ALIGN_RATE);
        else airControl(s, in);

        // ── 4. Salto / doble salto / dodge + temporizadores ─────────────────
        v = handleJump(s, in, v, onSurface);

        // ── 5. Gravedad (con reglas de pared/techo) ─────────────────────────
        double gScale = 1.0;
        if (onSurface && normal.y < WALL_NORMAL_Y_MAX) {
            double along = VecUtil.tangent(v, normal).length();
            if (along >= WALL_STICK_SPEED) {                // adherido: sin gravedad
                s.wallSlipTicks = 0;
                gScale = 0.0;
            } else {                                        // pierde velocidad: gravedad creciente exponencial
                s.wallSlipTicks++;
                gScale = 1.0 - Math.exp(-s.wallSlipTicks / WALL_SLIP_TAU);
            }
        } else {
            s.wallSlipTicks = 0;
        }
        v = v.add(0.0, -GRAVITY * gScale, 0.0);

        // ── 6. Tracción en superficie ───────────────────────────────────────
        if (onSurface) v = driveOnSurface(s, v, normal, in, steerMult);

        // ── 7. Boost ────────────────────────────────────────────────────────
        s.boosting = false;
        if (in.boost() && s.boost > 0f) {
            v = v.add(VecUtil.rotate(s.orient, VecUtil.FORWARD).scale(BOOST_ACCEL));
            s.boost = Math.max(0f, s.boost - BOOST_COST_PER_TICK);
            s.boosting = true;
        }

        // ── 8. Límite, movimiento, colisiones ───────────────────────────────
        v = VecUtil.clampLength(v, CAR_MAX_SPEED);
        v = moveAndCollide(level, s, v, onSurface, normal);

        s.vel = v;
        s.wasOnSurface = onSurface;
        s.onSurface = onSurface;
    }

    // ═════════════════════ SONDAS DE SUPERFICIE ═════════════════════

    private record Contact(int wheels, Vec3 normal) {}

    /** 4 raycasts desde las "ruedas" hacia −UP del coche. Funciona igual en suelo, pared y techo. */
    private static Contact probeSurface(Level level, CarState s) {
        Vec3 down = VecUtil.rotate(s.orient, VecUtil.UP).scale(-PROBE_LENGTH);
        int wheels = 0;
        Vec3 sum = Vec3.ZERO;
        for (float[] w : WHEEL_LOCAL) {
            Vec3 origin = s.center.add(VecUtil.rotate(s.orient, new Vec3(w[0], w[1], w[2])));
            Vec3 n = WorldCollision.clipNormal(level, origin, origin.add(down));
            if (n != null) { wheels++; sum = sum.add(n); }
        }
        Vec3 n = sum.lengthSqr() > 1.0E-6 ? sum.normalize() : VecUtil.UP;
        return new Contact(wheels, n);
    }

    // ═════════════════════ MÁQUINA DE SALTO / FLIP ═════════════════════
    //  doubleJumpAvailable  flipWindowTicks       significado
    //  false                0                     en superficie / 2.º salto ya usado
    //  true                 25 → 1                1.er salto hecho: 1.25 s para el 2.º
    //  true                 FLIP_UNLIMITED (-1)   FLIP RESET: sin límite hasta volver a saltar

    private static Vec3 handleJump(CarState s, VehicleInput in, Vec3 v, boolean onSurface) {
        if (in.jumpPressed()) {
            if (onSurface) {
                v = v.add(VecUtil.rotate(s.orient, VecUtil.UP).scale(JUMP_IMPULSE));
                s.doubleJumpAvailable = true;
                s.flipWindowTicks = FLIP_WINDOW_TICKS;
                s.jumpHoldTicks = JUMP_HOLD_TICKS;
                s.jumpGraceTicks = JUMP_GRACE_TICKS;
            } else if (s.canDoubleJump()) {
                v = performSecondJump(s, in, v);
            }
        }

        if (s.jumpHoldTicks > 0) {                          // salto variable
            if (in.jumpHeld()) {
                v = v.add(VecUtil.rotate(s.orient, VecUtil.UP).scale(JUMP_HOLD_ACCEL));
                s.jumpHoldTicks--;
            } else {
                s.jumpHoldTicks = 0;
            }
        }

        // La comprobación del botón va ANTES de decrementar ⇒ el tick T+25 todavía es válido (1.25 s exactos).
        if (!onSurface && s.flipWindowTicks > 0 && --s.flipWindowTicks == 0) {
            s.doubleJumpAvailable = false;
        }
        return v;
    }

    private static Vec3 performSecondJump(CarState s, VehicleInput in, Vec3 v) {
        s.doubleJumpAvailable = false;
        s.flipWindowTicks = 0;
        s.jumpHoldTicks = 0;

        float t = in.throttle(), st = in.steer();
        Vec3 up = VecUtil.rotate(s.orient, VecUtil.UP);

        if (Math.abs(t) < DODGE_DEADZONE && Math.abs(st) < DODGE_DEADZONE) {
            return v.add(up.scale(JUMP_IMPULSE));                       // simple doble salto
        }

        Vec3 fwd  = VecUtil.rotate(s.orient, VecUtil.FORWARD);
        Vec3 left = VecUtil.rotate(s.orient, VecUtil.LEFT);
        Vec3 dir = fwd.scale(t).add(left.scale(st)).normalize();

        s.flipAnimTicks = FLIP_ANIM_TICKS;
        s.flipAxis.set(t, 0f, -st).normalize();                         // t>0: front flip (+X) · st>0: roll izq (−Z)

        return new Vec3(v.x, v.y * 0.5, v.z).add(dir.scale(DODGE_IMPULSE));
    }

    private static void onLanded(CarState s) {
        s.doubleJumpAvailable = false;
        s.flipWindowTicks = 0;
        s.jumpHoldTicks = 0;
        s.flipAnimTicks = 0;
        s.wallSlipTicks = 0;
    }

    private static void onLeftSurface(CarState s) {
        // Caer de un borde sin saltar también concede la ventana completa de 1.25 s.
        if (FALL_OFF_GRANTS_FLIP_WINDOW && !s.doubleJumpAvailable && s.flipWindowTicks == 0) {
            s.doubleJumpAvailable = true;
            s.flipWindowTicks = FLIP_WINDOW_TICKS;
        }
    }

    /** Flip Reset (el balón toca las 4 ruedas). Lo llama el servidor; el cliente lo recibe por reconciliación. */
    public static boolean grantFlipReset(CarState s) {
        if (s.wasOnSurface) return false;               // en superficie ya hay salto disponible
        s.doubleJumpAvailable = true;
        s.flipWindowTicks = FLIP_UNLIMITED;
        return true;
    }

    // ═════════════════════════ ORIENTACIÓN ═════════════════════════

    private static void alignToSurface(CarState s, Vec3 n, float rate) {
        Vector3f up = s.orient.transform(new Vector3f(0, 1, 0));
        Vector3f target = VecUtil.vec3f(n);
        Quaternionf delta = new Quaternionf().rotationTo(up, target);   // rotación en espacio MUNDO
        Quaternionf partial = new Quaternionf().slerp(delta, rate);     // identidad → delta
        s.orient.premul(partial).normalize();
    }

    private static void airControl(CarState s, VehicleInput in) {
        if (s.flipAnimTicks > 0) {                                      // dodge en curso
            s.orient.rotateAxis(FLIP_ANGULAR, s.flipAxis.x, s.flipAxis.y, s.flipAxis.z);
            s.flipAnimTicks--;
        } else {
            s.orient.rotateX(in.throttle() * AIR_ANGULAR);                          // pitch
            if (in.airRoll()) s.orient.rotateZ(-in.steer() * AIR_ANGULAR);          // air roll
            else              s.orient.rotateY(in.steer() * AIR_ANGULAR);           // yaw
        }
        s.orient.normalize();
    }

    // ═════════════════════════ CONDUCCIÓN ═════════════════════════

    private static Vec3 surfaceForward(CarState s, Vec3 n) {
        Vec3 fwd = VecUtil.rotate(s.orient, VecUtil.FORWARD);
        Vec3 f = VecUtil.tangent(fwd, n);
        return f.lengthSqr() < 1.0E-6 ? fwd : f.normalize();
    }

    private static Vec3 driveOnSurface(CarState s, Vec3 v, Vec3 n, VehicleInput in, float steerMult) {
        Vec3 vs = VecUtil.tangent(v, n);
        double vn = v.dot(n);
        double speed = vs.length();

        // dirección (alrededor de la normal = UP local)
        Vec3 f = surfaceForward(s, n);
        double fwdSpeed = vs.dot(f);
        double steerScale = Mth.clamp(speed / 0.10, 0.0, 1.0);                 // no gira parado
        double rate = STEER_MAX * steerMult * (1.0 - 0.6 * Mth.clamp(speed / CAR_MAX_SPEED, 0.0, 1.0));
        if (in.handbrake()) rate *= HANDBRAKE_STEER_MULT;
        double dirSign = fwdSpeed >= -0.01 ? 1.0 : -1.0;                       // en reversa se invierte
        s.orient.rotateY((float) (in.steer() * rate * steerScale * dirSign)).normalize();
        f = surfaceForward(s, n);
        fwdSpeed = vs.dot(f);

        // acelerador / freno / inercia
        float t = in.throttle();
        if (Math.abs(t) > 0.01f) {
            boolean braking = fwdSpeed * t < -0.01;
            if (braking) {
                double dv = Math.min(BRAKE_ACCEL, Math.abs(fwdSpeed));
                vs = vs.subtract(f.scale(Math.signum(fwdSpeed) * dv));
            } else if (fwdSpeed * Math.signum(t) < PASSIVE_MAX) {              // tope pasivo 14.1 m/s
                vs = vs.add(f.scale(t * THROTTLE_ACCEL));
            }
        } else {
            double dv = Math.min(COAST_DECEL, Math.abs(fwdSpeed));
            vs = vs.subtract(f.scale(Math.signum(fwdSpeed) * dv));
        }

        // agarre lateral (power-slide casi no elimina velocidad lateral ⇒ conserva la del aire)
        Vec3 lateral = vs.subtract(f.scale(vs.dot(f)));
        vs = vs.subtract(lateral.scale(in.handbrake() ? HANDBRAKE_GRIP : NORMAL_GRIP));

        // Conserva solo la componente normal que se ALEJA de la superficie (el salto) y añade la fuerza
        // de adherencia hacia ella: sin esto el coche se despega de paredes y techo.
        return vs.add(n.scale(Math.max(0.0, vn) - STICK_ACCEL));
    }

    // ═════════════════════ MOVIMIENTO Y COLISIONES ═════════════════════

    private static Vec3 moveAndCollide(Level level, CarState s, Vec3 v, boolean onSurface, Vec3 surfN) {
        Vec3 moved = WorldCollision.move(level, s.box(), v);
        s.center = s.center.add(moved);
        Vec3 blocked = v.subtract(moved);                                      // lo que NO pudo recorrer

        Vec3 hitN = Vec3.ZERO;
        if (Math.abs(blocked.x) > 1.0E-5) hitN = hitN.add(-Math.signum(blocked.x), 0, 0);
        if (Math.abs(blocked.y) > 1.0E-5) hitN = hitN.add(0, -Math.signum(blocked.y), 0);
        if (Math.abs(blocked.z) > 1.0E-5) hitN = hitN.add(0, 0, -Math.signum(blocked.z));
        if (hitN.lengthSqr() < 1.0E-6) return v;

        hitN = hitN.normalize();
        double into = -v.dot(hitN);
        if (into <= 0.0) return v;

        Vec3 resolved = v.add(hitN.scale(into));                               // anula la componente contra el bloque

        // Transición de esquina (suelo→pared, pared→techo…): la velocidad contra el nuevo plano se
        // redirige a lo largo del plano anterior en vez de perderse ⇒ el coche "trepa".
        if (onSurface && into > CORNER_MIN_INTO && hitN.dot(surfN) < 0.5) {
            resolved = resolved.add(surfN.scale(into * CORNER_KEEP));
            s.transitionNormal = hitN;
            s.transitionTicks = TRANSITION_TICKS;
        }
        return resolved;
    }
}
