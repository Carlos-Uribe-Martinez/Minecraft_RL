package dev.nucleoarena.physics;

import dev.nucleoarena.input.VehicleInput;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.util.Mth;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import static dev.nucleoarena.physics.PhysicsConstants.*;

/**
 * Física del coche: UN tick sobre un {@link CarState}. Determinista; se ejecuta igual en servidor y cliente.
 *
 * Pipeline:
 *   1 sondas de ruedas      5 gravedad (reglas de pared)      
 *   2 aterrizaje/despegue   6 tracción + agarre + adherencia
 *   3 orientación           7 boost
 *   4 salto / flip          8 límite → colisión → esquinas
 */
public final class CarPhysics {
    private CarPhysics() {}

    public static void step(Level level, CarState s, VehicleInput in, float steerMult) {
        Vec3 v = s.vel;

        // ── 1. Sondas de ruedas ──────────────────────────────────────────────
        Contact contact = probeSurface(level, s);
        boolean onSurface = contact.wheels >= WHEELS_REQUIRED;
        Vec3 normal = onSurface ? contact.normal : VecUtil.UP;

        if (s.jumpGraceTicks > 0) {                         // justo tras saltar: no cuenta como contacto
            s.jumpGraceTicks--;
            onSurface = false;
        } else if (!onSurface && s.transitionTicks > 0) {   // esquina/pared recién tomada: forzar normal
            s.transitionTicks--;
            onSurface = true;
            normal = s.transitionNormal;
        }

        // ── 2. Aterrizaje / despegue ─────────────────────────────────────────
        if (onSurface && !s.wasOnSurface) onLanded(s);
        else if (!onSurface && s.wasOnSurface) onLeftSurface(s);
        if (onSurface) s.surfaceNormal = normal;

        // ── 3. Orientación ───────────────────────────────────────────────────
        // Apoyado sobre el suelo SIN ruedas (de costado / boca abajo): se asienta y espera la entrada
        boolean resting = !onSurface && s.contactTicks > 0 && s.contactNormal.y > REST_MIN_NORMAL_Y
                && s.jumpGraceTicks == 0 && s.jumpHoldTicks == 0 && s.flipAnimTicks == 0;

        if (onSurface) alignToSurface(s, normal, s.transitionTicks > 0 ? 0.6f : ALIGN_RATE);
        else if (resting) restOrient(s, in);
        else { airControl(s, in); autoLand(level, s, in); if (in.handbrake()) s.airSlide = true; }

        // ── 4. Salto / doble salto / dodge + temporizadores ─────────────────
        v = handleJump(s, in, v, onSurface, resting ? s.contactNormal : null);

        // ── 5. Gravedad (con reglas de pared/techo) ─────────────────────────
        double gScale = 1.0;
        double stick = 1.0;                                 // factor de adherencia a la superficie
        boolean steep = onSurface && normal.y < WALL_NORMAL_Y_MAX;           // pared o techo
        boolean ceiling = onSurface && normal.y < CEILING_NORMAL_Y;
        s.ceilingTicks = steep ? s.ceilingTicks + 1 : 0;                      // ticks seguidos pegado a pared/techo
        if (steep) {
            double along = VecUtil.tangent(v, normal).length();
            double need = ceiling ? CEILING_STICK_SPEED : WALL_STICK_SPEED;
            boolean expired = s.ceilingTicks > (ceiling ? CEILING_MAX_TICKS : WALL_MAX_TICKS);
            if (along >= need && !expired) {                // adherido: sin gravedad
                s.wallSlipTicks = 0;
                gScale = 0.0;
            } else {                                        // pared o techo: sin velocidad (o tiempo agotado) ⇒ gravedad completa y sin adherencia
                s.wallSlipTicks++;
                gScale = 1.0;
                stick = 0.0;
            }
        } else {
            s.wallSlipTicks = 0;
        }
        v = v.add(0.0, -GRAVITY * gScale, 0.0);

        // Apoyado sin ruedas: fricción fuerte (antes se deslizaba sin parar)
        if (resting) {
            double ud = VecUtil.rotate(s.orient, VecUtil.UP).dot(s.contactNormal);
            double fr = REST_FRICTION * (ud < -0.6 ? 0.7 : Math.abs(ud) < 0.6 ? 1.6 : 1.0);   // techo: más inercia · puerta: más fricción
            v = v.subtract(VecUtil.tangent(v, VecUtil.UP).scale(fr));
            // Boca abajo / de costado también avanza (tracción reducida) mientras se endereza
            if (Math.abs(in.throttle()) > 0.1f) {
                Vec3 fwd = VecUtil.tangent(VecUtil.rotate(s.orient, VecUtil.FORWARD), s.contactNormal);
                if (fwd.lengthSqr() > 1.0E-6 && VecUtil.tangent(v, VecUtil.UP).length() < speed(9.0))
                    v = v.add(fwd.normalize().scale(Math.signum(in.throttle()) * THROTTLE_ACCEL * ROOF_DRIVE_FACTOR));
            }
        }

        // ── 6. Tracción en superficie ───────────────────────────────────────
        if (onSurface) v = driveOnSurface(s, v, normal, in, steerMult, stick);
        if (s.landSlowTicks > 0) {                                       // recién caído: con derrape sigue rápido; sin él, con fricción
            s.landSlowTicks--;
            if (onSurface && !in.handbrake()) v = v.subtract(VecUtil.tangent(v, normal).scale(LAND_FRICTION));
        }

        // ── 7. Boost ────────────────────────────────────────────────────────
        s.boosting = false;
        if (in.boost() && s.boost > 0f) {
            v = v.add(VecUtil.rotate(s.orient, VecUtil.FORWARD).scale(BOOST_ACCEL));
            s.boost = Math.max(0f, s.boost - BOOST_COST_PER_TICK);
            s.boosting = true;
        }

        // ── 8. Límite, movimiento, colisiones ───────────────────────────────
        v = VecUtil.clampLength(v, CAR_MAX_SPEED);
        v = moveAndCollide(level, s, v, onSurface, normal);

        s.vel = v;
        s.wasOnSurface = onSurface;
        s.airTicks = onSurface ? s.airTicks : s.airTicks + 1;
        s.onSurface = onSurface;
    }

    // ═════════════════════ SONDAS DE SUPERFICIE ═════════════════════

    private record Contact(int wheels, Vec3 normal) {}

    /** 4 raycasts desde las "ruedas" hacia −UP del coche. Funciona igual en suelo, pared y techo. */
    private static Contact probeSurface(Level level, CarState s) {
        Vec3 down = VecUtil.rotate(s.orient, VecUtil.UP).scale(-PROBE_LENGTH);
        int wheels = 0;
        Vec3 sum = Vec3.ZERO;
        for (float[] w : WHEEL_LOCAL) {
            Vec3 origin = s.center.add(VecUtil.rotate(s.orient, new Vec3(w[0], w[1], w[2])));
            Vec3 n = WorldCollision.clipNormal(level, origin, origin.add(down));
            if (n != null) { wheels++; sum = sum.add(n); }
        }
        Vec3 n = sum.lengthSqr() > 1.0E-6 ? sum.normalize() : VecUtil.UP;
        return new Contact(wheels, n);
    }

    // ═════════════════════ MÁQUINA DE SALTO / FLIP ═════════════════════
    //  doubleJumpAvailable  flipWindowTicks       significado
    //  false                0                     en superficie / 2.º salto ya usado
    //  true                 25 → 1                1.er salto hecho: 1.25 s para el 2.º
    //  true                 FLIP_UNLIMITED (-1)   FLIP RESET: sin límite hasta volver a saltar

    private static Vec3 handleJump(CarState s, VehicleInput in, Vec3 v, boolean onSurface, Vec3 restNormal) {
        if (in.jumpPressed()) {
            if (!onSurface && restNormal != null) {         // salto desde reposo (de costado / boca abajo)
                v = v.add(restNormal.scale(JUMP_IMPULSE));
                s.doubleJumpAvailable = true;
                s.flipWindowTicks = FLIP_WINDOW_TICKS;
                s.jumpHoldTicks = JUMP_HOLD_TICKS;
                s.jumpGraceTicks = JUMP_GRACE_TICKS;
            } else if (onSurface) {
                v = v.add(VecUtil.rotate(s.orient, VecUtil.UP).scale(JUMP_IMPULSE));
                s.doubleJumpAvailable = true;
                s.flipWindowTicks = FLIP_WINDOW_TICKS;
                s.jumpHoldTicks = JUMP_HOLD_TICKS;
                s.jumpGraceTicks = JUMP_GRACE_TICKS;
            } else if (s.canDoubleJump()) {
                v = performSecondJump(s, in, v);
            }
        }

        if (s.jumpHoldTicks > 0) {                          // salto variable
            if (in.jumpHeld()) {
                v = v.add(VecUtil.rotate(s.orient, VecUtil.UP).scale(JUMP_HOLD_ACCEL));
                s.jumpHoldTicks--;
            } else {
                s.jumpHoldTicks = 0;
            }
        }

        // La comprobación del botón va ANTES de decrementar ⇒ el tick T+25 todavía es válido (1.25 s exactos).
        if (!onSurface && s.flipWindowTicks > 0 && --s.flipWindowTicks == 0) {
            s.doubleJumpAvailable = false;
        }
        return v;
    }

    private static Vec3 performSecondJump(CarState s, VehicleInput in, Vec3 v) {
        s.doubleJumpAvailable = false;
        s.flipWindowTicks = 0;
        s.jumpHoldTicks = 0;

        float t = in.throttle(), st = in.steer();
        Vec3 up = VecUtil.rotate(s.orient, VecUtil.UP);

        if (Math.abs(t) < DODGE_DEADZONE && Math.abs(st) < DODGE_DEADZONE) {
            return v.add(up.scale(JUMP_IMPULSE));                       // simple doble salto
        }

        Vec3 fwd  = VecUtil.rotate(s.orient, VecUtil.FORWARD);
        Vec3 left = VecUtil.rotate(s.orient, VecUtil.LEFT);
        Vec3 dir = fwd.scale(t).add(left.scale(st)).normalize();

        s.flipAnimTicks = FLIP_ANIM_TICKS;
        s.flipAxis.set(t, 0f, -st).normalize();                         // t>0: front flip (+X) · st>0: roll izq (−Z)

        return new Vec3(v.x, v.y * 0.5, v.z).add(dir.scale(DODGE_IMPULSE));
    }

    private static void onLanded(CarState s) {
        if (s.airTicks > LONG_AIR_TICKS) s.landSlowTicks = LAND_SLOW_TICKS;     // salto largo (p. ej. speed flip): frena un poco al caer
        s.airTicks = 0;
        s.doubleJumpAvailable = false;
        s.flipWindowTicks = 0;
        s.jumpHoldTicks = 0;
        s.flipAnimTicks = 0;
        s.wallSlipTicks = 0;
    }

    private static void onLeftSurface(CarState s) {
        // Caer de un borde sin saltar también concede la ventana completa de 1.25 s.
        if (FALL_OFF_GRANTS_FLIP_WINDOW && !s.doubleJumpAvailable && s.flipWindowTicks == 0) {
            s.doubleJumpAvailable = true;
            s.flipWindowTicks = FLIP_WINDOW_TICKS;
        }
    }

    /** Flip Reset (el balón toca las 4 ruedas). Lo llama el servidor; el cliente lo recibe por reconciliación. */
    public static boolean grantFlipReset(CarState s) {
        if (s.wasOnSurface) return false;               // en superficie ya hay salto disponible
        s.doubleJumpAvailable = true;
        s.flipWindowTicks = FLIP_UNLIMITED;
        return true;
    }

    // ═════════════════════════ ORIENTACIÓN ═════════════════════════

    private static void alignToSurface(CarState s, Vec3 n, float rate) {
        Vector3f up = s.orient.transform(new Vector3f(0, 1, 0));
        Vector3f target = VecUtil.vec3f(n);
        Quaternionf delta = new Quaternionf().rotationTo(up, target);   // rotación en espacio MUNDO
        Quaternionf partial = new Quaternionf().slerp(delta, rate);     // identidad → delta
        s.orient.premul(partial).normalize();
    }

    private static void airControl(CarState s, VehicleInput in) {
        if (s.flipAnimTicks > 0) {                                      // dodge en curso
            s.orient.rotateAxis(FLIP_ANGULAR, s.flipAxis.x, s.flipAxis.y, s.flipAxis.z);
            s.flipAnimTicks--;
        } else {
            s.orient.rotateX(in.pitch() * AIR_ANGULAR);                             // cabeceo: teclas propias (W/S ya no giran en el aire)
            if (in.airRoll()) s.orient.rotateZ(-in.steer() * AIR_ANGULAR);          // air roll (mantener + A/D)
            else              s.orient.rotateY(in.steer() * AIR_ANGULAR);           // yaw
            if (in.roll() != 0) s.orient.rotateZ(-in.roll() * AIR_ANGULAR * AIR_ROLL_MULT);         // roll directo izq./der.
        }
        s.orient.normalize();
    }

    /**
     * Coche apoyado en el suelo sin ruedas:
     *  - sin entrada: se asienta sobre la cara más cercana (puerta izq./der., techo o ruedas); el morro/cola no cuentan;
     *  - con avance/retroceso o salto: se endereza poco a poco hasta quedar sobre las ruedas.
     */
    /**
     * Caída automática: en el aire, cerca del suelo y sin control manual, el coche se endereza solo para caer sobre las
     * ruedas (la fricción del aterrizaje la pone el resto de la física). Con el derrape pulsado no ayuda.
     */
    private static void autoLand(Level level, CarState s, VehicleInput in) {
        if (in.handbrake() || s.flipAnimTicks > 0 || s.jumpHoldTicks > 0) return;
        if (s.airTicks < AUTO_LAND_DELAY_TICKS) return;                                   // recién saltó: deja maniobrar sin ayuda
        if (in.pitch() != 0 || in.roll() != 0 || in.airRoll()) return;                    // control manual del cabeceo/balanceo
        Vec3 up = VecUtil.rotate(s.orient, VecUtil.UP);
        Vec3 n = WorldCollision.clipNormal(level, s.center, s.center.add(0.0, -BOX_SIZE * 2.4, 0.0));
        if (n != null && n.y >= 0.6 && up.dot(n) > -0.3) {                  // cerca del suelo: cae de pie (hasta ~107° de inclinación)
            alignToSurface(s, n, AUTO_LAND_RATE);
            return;
        }
        if (up.y > 0.3) alignToSurface(s, VecUtil.UP, AIR_LEVEL_RATE);      // lejos del suelo: nivelado suave
    }

    private static void restOrient(CarState s, VehicleInput in) {
        Vector3f n = VecUtil.vec3f(s.contactNormal);
        boolean wantsUp = Math.abs(in.throttle()) > 0.1f || in.jumpPressed() || in.jumpHeld();
        if (wantsUp) {
            alignToSurface(s, s.contactNormal, RIGHT_RATE * 0.6f);   // se endereza más despacio: antes avanza
            return;
        }
        Vector3f down = new Vector3f(n).negate();                       // hacia donde apunta la cara apoyada
        Vector3f[] faces = {
                s.orient.transform(new Vector3f(0, 1, 0), new Vector3f()),
                s.orient.transform(new Vector3f(0, -1, 0), new Vector3f()),
                s.orient.transform(new Vector3f(1, 0, 0), new Vector3f()),
                s.orient.transform(new Vector3f(-1, 0, 0), new Vector3f())
        };
        Vector3f best = faces[0];
        float bestDot = -2f;
        for (Vector3f f : faces) {
            float d = f.dot(down);
            if (d > bestDot) { bestDot = d; best = f; }
        }
        Quaternionf delta = new Quaternionf().rotationTo(best, down);
        float rate = best == faces[1] ? 0.5f : SETTLE_RATE;                 // sobre las ruedas se asienta más rápido
        s.orient.premul(new Quaternionf().slerp(delta, rate)).normalize();
    }

    // ═════════════════════════ CONDUCCIÓN ═════════════════════════

    private static Vec3 surfaceForward(CarState s, Vec3 n) {
        Vec3 fwd = VecUtil.rotate(s.orient, VecUtil.FORWARD);
        Vec3 f = VecUtil.tangent(fwd, n);
        return f.lengthSqr() < 1.0E-6 ? fwd : f.normalize();
    }

    private static Vec3 driveOnSurface(CarState s, Vec3 v, Vec3 n, VehicleInput in, float steerMult, double stick) {
        Vec3 vs = VecUtil.tangent(v, n);
        double vn = v.dot(n);
        double speed = vs.length();
        if (!in.handbrake()) s.airSlide = false;
        final boolean slide = s.airSlide && in.handbrake();                    // llegó del aire con el derrape: sigue sin fricción

        // dirección (alrededor de la normal = UP local)
        Vec3 f = surfaceForward(s, n);
        double fwdSpeed = vs.dot(f);
        double steerScale = Mth.clamp(speed / 0.10, 0.0, 1.0);                 // no gira parado
        double rate = STEER_MAX * steerMult * (1.0 - 0.6 * Mth.clamp(speed / CAR_MAX_SPEED, 0.0, 1.0));
        if (in.handbrake()) rate *= HANDBRAKE_STEER_MULT;
        double dirSign = fwdSpeed >= -0.01 ? 1.0 : -1.0;                       // en reversa se invierte
        s.orient.rotateY((float) (in.steer() * rate * steerScale * dirSign)).normalize();
        f = surfaceForward(s, n);
        fwdSpeed = vs.dot(f);

        // acelerador / freno / inercia
        float t = in.throttle();
        if (Math.abs(t) > 0.01f) {
            boolean braking = fwdSpeed * t < -0.01;
            if (braking) {
                double dv = Math.min(BRAKE_ACCEL, Math.abs(fwdSpeed));
                vs = vs.subtract(f.scale(Math.signum(fwdSpeed) * dv));
            } else if (fwdSpeed * Math.signum(t) < PASSIVE_MAX) {              // tope pasivo 14.1 m/s
                vs = vs.add(f.scale(t * THROTTLE_ACCEL));
            }
        } else if (!slide) {
            double dv = Math.min(COAST_DECEL, Math.abs(fwdSpeed));
            vs = vs.subtract(f.scale(Math.signum(fwdSpeed) * dv));
        }

        // agarre lateral (power-slide casi no elimina velocidad lateral ⇒ conserva la del aire)
        Vec3 lateral = vs.subtract(f.scale(vs.dot(f)));
        if (!slide) vs = vs.subtract(lateral.scale(in.handbrake() ? HANDBRAKE_GRIP : NORMAL_GRIP));

        // Conserva solo la componente normal que se ALEJA de la superficie (el salto) y añade la fuerza
        // de adherencia hacia ella: sin esto el coche se despega de paredes y techo.
        return vs.add(n.scale(Math.max(0.0, vn) - STICK_ACCEL * stick));
    }

    // ═════════════════════ MOVIMIENTO Y COLISIONES ═════════════════════

    /** Bloques que el vehículo NO rompe (rebota/trepa como siempre): cristales, barrera, obsidiana, bedrock y la cancha. */
    private static boolean isUnbreakable(BlockState st) {
        if (st.isAir()) return true;                                           // sin bloque en el punto: comportamiento normal
        String id = BuiltInRegistries.BLOCK.getKey(st.getBlock()).getPath();
        return id.contains("glass") || id.equals("barrier") || id.contains("obsidian") || id.equals("bedrock")
                || id.equals("light") || id.equals("sea_lantern") || id.startsWith("smooth_quartz");
    }

    private static Vec3 moveAndCollide(Level level, CarState s, Vec3 v, boolean onSurface, Vec3 surfN) {
        Vec3 moved = WorldCollision.move(level, s.box(), v);
        Vec3 blocked = v.subtract(moved);                                      // lo que NO pudo recorrer

        // Subir escalones / escaleras: si algo bloquea el avance horizontal, probar a levantar la caja hasta
        // STEP_HEIGHT, avanzar por encima y volver a apoyarla; se acepta si así avanza más.
        boolean horizBlocked = Math.abs(blocked.x) > 1.0E-5 || Math.abs(blocked.z) > 1.0E-5;
        if (horizBlocked && onSurface && surfN.y > 0.6 && v.y <= 0.05) {
            Vec3 h = new Vec3(v.x, 0.0, v.z);
            Vec3 up = WorldCollision.move(level, s.box(), new Vec3(0.0, STEP_HEIGHT, 0.0));
            if (up.y > 0.05) {
                var raised = s.box().move(up);
                Vec3 fwd = WorldCollision.move(level, raised, h);
                double gain = fwd.horizontalDistance() - new Vec3(moved.x, 0, moved.z).horizontalDistance();
                if (gain > 0.02) {
                    Vec3 down = WorldCollision.move(level, raised.move(fwd), new Vec3(0.0, -up.y, 0.0));
                    s.center = s.center.add(up).add(fwd).add(down);
                    return new Vec3(v.x, Math.min(v.y, 0.0), v.z);              // sin golpe: conserva la velocidad
                }
            }
        }
        s.center = s.center.add(moved);

        Vec3 hitN = Vec3.ZERO;
        if (Math.abs(blocked.x) > 1.0E-5) hitN = hitN.add(-Math.signum(blocked.x), 0, 0);
        if (Math.abs(blocked.y) > 1.0E-5) hitN = hitN.add(0, -Math.signum(blocked.y), 0);
        if (Math.abs(blocked.z) > 1.0E-5) hitN = hitN.add(0, 0, -Math.signum(blocked.z));
        if (hitN.lengthSqr() < 1.0E-6) {
            if (s.contactTicks > 0) s.contactTicks--;
            return v;
        }

        hitN = hitN.normalize();
        s.contactNormal = hitN;                                                // para reposo / auto-enderezado
        s.contactTicks = 2;
        double into = -v.dot(hitN);
        if (into <= 0.0) return v;

        // Bloques rompibles (todo salvo cristal, barrera, obsidiana, bedrock y la cancha): choque seco, SIN rebote.
        // Si el golpe es lo bastante fuerte, el servidor destruye el bloque (breakByImpact).
        if (into > BUMP_MIN_INTO && hitN.y < 0.6) {
            BlockPos bp = BlockPos.containing(s.center.subtract(hitN.scale(BOX_SIZE / 2.0 + 0.15)));
            if (!isUnbreakable(level.getBlockState(bp))) return Vec3.ZERO;
        }

        // Choque de MORRO/COLA en el aire contra pared o techo: rebota casi con la misma velocidad (no trepa)
        if (!onSurface && into > BUMP_MIN_INTO) {                               // paredes, techo Y suelo (pogo)
            Vec3 fwdW = VecUtil.rotate(s.orient, VecUtil.FORWARD);
            if (Math.abs(fwdW.dot(hitN)) > 0.55) {
                s.jumpGraceTicks = Math.max(s.jumpGraceTicks, BUMP_NO_STICK_TICKS);   // sin adherencia unos ticks
                return v.add(hitN.scale(into * (1.0 + BUMP_RESTITUTION)));
            }
        }

        Vec3 resolved = v.add(hitN.scale(into));                               // anula la componente contra el bloque

        // Transición de esquina (suelo→pared, pared→techo…): la velocidad contra el nuevo plano se
        // redirige a lo largo del plano anterior en vez de perderse ⇒ el coche "trepa".
        if (onSurface && into > CORNER_MIN_INTO && hitN.dot(surfN) < 0.5) {
            resolved = resolved.add(surfN.scale(into * CORNER_KEEP));
            s.transitionNormal = hitN;
            s.transitionTicks = TRANSITION_TICKS;
        }
        return resolved;
    }
}
