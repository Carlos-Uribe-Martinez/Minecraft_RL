package dev.nucleoarena.physics;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import static dev.nucleoarena.physics.PhysicsConstants.BOOST_START;
import static dev.nucleoarena.physics.PhysicsConstants.BOX_SIZE;

/**
 * Estado COMPLETO y determinista de un coche. {@link CarPhysics#step} es una función pura sobre esto,
 * así servidor (autoritativo) y cliente (predicción) ejecutan exactamente el mismo código.
 * Todo lo que influye en el siguiente tick debe estar aquí, y se serializa en {@link #write}.
 */
public final class CarState {
    public Vec3 center = Vec3.ZERO;                 // centro de la AABB cúbica
    public Vec3 vel = Vec3.ZERO;                    // bloques / tick
    public final Quaternionf orient = new Quaternionf();
    public float boost = BOOST_START;

    // Máquina de estados del salto (ver ARQUITECTURA.md §4)
    public boolean doubleJumpAvailable;
    public int flipWindowTicks;
    public int jumpHoldTicks;
    public int jumpGraceTicks;
    public int flipAnimTicks;
    public final Vector3f flipAxis = new Vector3f();

    // Superficie
    public boolean wasOnSurface;
    public Vec3 surfaceNormal = VecUtil.UP;
    public Vec3 transitionNormal = VecUtil.UP;
    public int transitionTicks;
    public int wallSlipTicks;

    // Salidas del último paso (no afectan al siguiente; solo para efectos/HUD)
    public boolean boosting;
    public boolean onSurface;

    public boolean canDoubleJump() {
        return doubleJumpAvailable && (flipWindowTicks == PhysicsConstants.FLIP_UNLIMITED || flipWindowTicks > 0);
    }

    public AABB box() {
        double h = BOX_SIZE / 2.0;
        return new AABB(center.x - h, center.y - h, center.z - h, center.x + h, center.y + h, center.z + h);
    }

    public CarState copy() { return new CarState().set(this); }

    public CarState set(CarState o) {
        center = o.center; vel = o.vel; orient.set(o.orient); boost = o.boost;
        doubleJumpAvailable = o.doubleJumpAvailable; flipWindowTicks = o.flipWindowTicks;
        jumpHoldTicks = o.jumpHoldTicks; jumpGraceTicks = o.jumpGraceTicks; flipAnimTicks = o.flipAnimTicks;
        flipAxis.set(o.flipAxis);
        wasOnSurface = o.wasOnSurface; surfaceNormal = o.surfaceNormal; transitionNormal = o.transitionNormal;
        transitionTicks = o.transitionTicks; wallSlipTicks = o.wallSlipTicks;
        boosting = o.boosting; onSurface = o.onSurface;
        return this;
    }

    /** Reinicio completo en una posición (kickoff / respawn). yawRad: giro alrededor de Y local. */
    public void reset(Vec3 newCenter, float yawRad, float newBoost) {
        center = newCenter; vel = Vec3.ZERO;
        orient.identity().rotateY(yawRad);
        boost = newBoost;
        doubleJumpAvailable = false; flipWindowTicks = 0; jumpHoldTicks = 0; jumpGraceTicks = 0; flipAnimTicks = 0;
        flipAxis.set(0, 0, 0);
        wasOnSurface = false; surfaceNormal = VecUtil.UP; transitionNormal = VecUtil.UP;
        transitionTicks = 0; wallSlipTicks = 0; boosting = false; onSurface = false;
    }

    /** ¿Difiere lo bastante del estado del servidor como para corregir? */
    public boolean differsFrom(CarState s) {
        if (center.distanceToSqr(s.center) > PhysicsConstants.RECONCILE_POS_EPS * PhysicsConstants.RECONCILE_POS_EPS) return true;
        if (vel.distanceToSqr(s.vel) > PhysicsConstants.RECONCILE_VEL_EPS * PhysicsConstants.RECONCILE_VEL_EPS) return true;
        if (Math.abs(orient.dot(s.orient)) < PhysicsConstants.RECONCILE_ROT_DOT) return true;
        return doubleJumpAvailable != s.doubleJumpAvailable || flipWindowTicks != s.flipWindowTicks
                || wasOnSurface != s.wasOnSurface || Math.abs(boost - s.boost) > 0.5f;
    }

    // ───────────── Serialización ─────────────

    public void write(FriendlyByteBuf b) {
        writeVec(b, center); writeVec(b, vel);
        b.writeFloat(orient.x); b.writeFloat(orient.y); b.writeFloat(orient.z); b.writeFloat(orient.w);
        b.writeFloat(boost);
        b.writeVarInt(flipWindowTicks + 1);                     // +1: FLIP_UNLIMITED (-1) → 0
        b.writeVarInt(jumpHoldTicks); b.writeVarInt(jumpGraceTicks); b.writeVarInt(flipAnimTicks);
        b.writeFloat(flipAxis.x); b.writeFloat(flipAxis.y); b.writeFloat(flipAxis.z);
        writeVec(b, surfaceNormal); writeVec(b, transitionNormal);
        b.writeVarInt(transitionTicks); b.writeVarInt(wallSlipTicks);
        b.writeByte((doubleJumpAvailable ? 1 : 0) | (wasOnSurface ? 2 : 0) | (boosting ? 4 : 0) | (onSurface ? 8 : 0));
    }

    public static CarState read(FriendlyByteBuf b) {
        CarState s = new CarState();
        s.center = readVec(b); s.vel = readVec(b);
        s.orient.set(b.readFloat(), b.readFloat(), b.readFloat(), b.readFloat());
        s.boost = b.readFloat();
        s.flipWindowTicks = b.readVarInt() - 1;
        s.jumpHoldTicks = b.readVarInt(); s.jumpGraceTicks = b.readVarInt(); s.flipAnimTicks = b.readVarInt();
        s.flipAxis.set(b.readFloat(), b.readFloat(), b.readFloat());
        s.surfaceNormal = readVec(b); s.transitionNormal = readVec(b);
        s.transitionTicks = b.readVarInt(); s.wallSlipTicks = b.readVarInt();
        int f = b.readByte();
        s.doubleJumpAvailable = (f & 1) != 0; s.wasOnSurface = (f & 2) != 0;
        s.boosting = (f & 4) != 0; s.onSurface = (f & 8) != 0;
        return s;
    }

    private static void writeVec(FriendlyByteBuf b, Vec3 v) { b.writeDouble(v.x); b.writeDouble(v.y); b.writeDouble(v.z); }
    private static Vec3 readVec(FriendlyByteBuf b) { return new Vec3(b.readDouble(), b.readDouble(), b.readDouble()); }
}
