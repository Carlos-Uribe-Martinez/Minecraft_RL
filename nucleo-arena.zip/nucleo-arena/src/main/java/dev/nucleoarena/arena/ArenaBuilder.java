package dev.nucleoarena.arena;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.Half;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;


/**
 * Construye la cancha con bloques vanilla (solo "planos": suelo, techo, 4 paredes y 2 porterías).
 * NO limpia el interior: constrúyela en un mundo plano/vacío (superflat o void).
 * Las paredes son verticales; el coche las "trepa" con la regla de transición de esquina de CarPhysics.
 */
public final class ArenaBuilder {
    private ArenaBuilder() {}

    /** Bloque vanilla por id de registro (evita depender del nombre de la constante en Blocks). */
    private static BlockState blockById(String id) {
        return BuiltInRegistries.BLOCK.getValue(Identifier.withDefaultNamespace(id)).defaultBlockState();
    }

    private static final int FLAGS = Block.UPDATE_CLIENTS;       // sin actualizaciones de vecinos (rápido)

    public static void build(ServerLevel level, ArenaConfig a) {
        int cx = (int) Math.round(a.center().x), cz = (int) Math.round(a.center().z);
        int fy = (int) Math.round(a.center().y);                   // y del primer bloque de aire sobre el suelo
        int x0 = cx - a.halfW(), x1 = cx + a.halfW() - 1;          // interior jugable (inclusive)
        int z0 = cz - a.halfL(), z1 = cz + a.halfL() - 1;
        int top = fy + a.height();                                  // capa del techo

        BlockState wall = Blocks.GLASS.defaultBlockState();
        BlockState ceil = Blocks.GLASS.defaultBlockState();
        BlockState floorA = blockById("blue_concrete");
        BlockState floorB = blockById("orange_concrete");
        BlockState line = blockById("white_concrete");

        // Suelo (mitades de color + línea central)
        for (int x = x0; x <= x1; x++)
            for (int z = z0; z <= z1; z++) {
                BlockState st = (z == cz || z == cz - 1) ? line : (z < cz ? floorA : floorB);
                set(level, x, fy - 1, z, st);
            }
        // Techo
        fill(level, x0 - 1, top, z0 - 1, x1 + 1, top, z1 + 1, ceil);
        // Paredes largas (x) y de fondo (z)
        fill(level, x0 - 1, fy, z0 - 1, x0 - 1, top - 1, z1 + 1, wall);
        fill(level, x1 + 1, fy, z0 - 1, x1 + 1, top - 1, z1 + 1, wall);
        fill(level, x0 - 1, fy, z0 - 1, x1 + 1, top - 1, z0 - 1, wall);
        fill(level, x0 - 1, fy, z1 + 1, x1 + 1, top - 1, z1 + 1, wall);
        // Marco del suelo bajo las paredes
        fill(level, x0 - 1, fy - 1, z0 - 1, x1 + 1, fy - 1, z0 - 1, Blocks.SMOOTH_BASALT.defaultBlockState());
        fill(level, x0 - 1, fy - 1, z1 + 1, x1 + 1, fy - 1, z1 + 1, Blocks.SMOOTH_BASALT.defaultBlockState());

        goal(level, a, cx, fy, z0 - 1, -1, blockById("blue_concrete"));
        goal(level, a, cx, fy, z1 + 1, +1, blockById("orange_concrete"));
        ramps(level, a, x0, x1, z0, z1, fy, top, cx);
    }

    /**
     * Rampas escalonadas (escaleras) en TODOS los bordes: suelo↔paredes y techo↔paredes, con las esquinas unidas.
     * No existen escaleras de cristal en vainilla: se usa cuarzo liso. Las paredes de fondo dejan libre la portería.
     */
    private static void ramps(ServerLevel level, ArenaConfig a, int x0, int x1, int z0, int z1, int fy, int top, int cx) {
        int n = Math.max(3, Math.min(6, a.halfL() / 17));              // 3 (cancha RL) ó 6 (doble)
        int gx0 = cx - a.goalHalfW() - 1, gx1 = cx + a.goalHalfW();
        for (int up = 0; up < 2; up++) {
            boolean ceiling = up == 1;
            for (int d = 0; d < n; d++) {
                int h = n - 1 - d;                                      // bloques llenos bajo el escalón
                for (int z = z0 + n; z <= z1 - n; z++) {
                    rampColumn(level, x0 + d, z, h, Direction.EAST, ceiling, fy, top);
                    rampColumn(level, x1 - d, z, h, Direction.WEST, ceiling, fy, top);
                }
                for (int x = x0 + n; x <= x1 - n; x++) {
                    if (x >= gx0 && x <= gx1) continue;                 // abertura de la portería
                    rampColumn(level, x, z0 + d, h, Direction.SOUTH, ceiling, fy, top);
                    rampColumn(level, x, z1 - d, h, Direction.NORTH, ceiling, fy, top);
                }
            }
            BlockState solid = blockById("smooth_quartz");
            for (int dx = 0; dx < n; dx++)
                for (int dz = 0; dz < n; dz++) {
                    int hh = n - Math.min(dx, dz);                      // unión de las dos rampas
                    for (int k = 0; k < hh; k++) {
                        int y = ceiling ? top - 1 - k : fy + k;
                        set(level, x0 + dx, y, z0 + dz, solid);
                        set(level, x1 - dx, y, z0 + dz, solid);
                        set(level, x0 + dx, y, z1 - dz, solid);
                        set(level, x1 - dx, y, z1 - dz, solid);
                    }
                }
        }
    }

    private static void rampColumn(ServerLevel level, int x, int z, int h, Direction facing, boolean ceiling, int fy, int top) {
        BlockState solid = blockById("smooth_quartz");
        for (int k = 0; k < h; k++) set(level, x, ceiling ? top - 1 - k : fy + k, z, solid);
        BlockState stair = blockById("smooth_quartz_stairs")
                .setValue(BlockStateProperties.HORIZONTAL_FACING, facing)
                .setValue(BlockStateProperties.HALF, ceiling ? Half.TOP : Half.BOTTOM);
        set(level, x, ceiling ? top - 1 - h : fy + h, z, stair);
    }

    /** Portería: caja de color detrás del plano de pared con la abertura tallada. wallZ = z de la capa de pared. */
    private static void goal(ServerLevel level, ArenaConfig a, int cx, int fy, int wallZ, int dir, BlockState color) {
        int gx0 = cx - a.goalHalfW(), gx1 = cx + a.goalHalfW() - 1;
        int gTop = fy + a.goalHeight();                              // capa del techo de la portería
        int zEnd = wallZ + dir * a.goalDepth();                      // pared del fondo
        int zLo = Math.min(wallZ, zEnd), zHi = Math.max(wallZ, zEnd);

        // Carcasa
        fill(level, gx0 - 1, fy - 1, zLo, gx1 + 1, gTop, zHi, color);
        // Interior hueco (incluye la abertura en el plano de pared); el fondo queda cerrado
        int innerLo = dir < 0 ? zLo + 1 : zLo, innerHi = dir < 0 ? zHi : zHi - 1;
        fill(level, gx0, fy, innerLo, gx1, gTop - 1, innerHi, Blocks.AIR.defaultBlockState());
        // Techo de la portería sobre la abertura queda como pared; redondea con linternas en el marco
        fill(level, gx0 - 1, fy, wallZ, gx0 - 1, gTop, wallZ, Blocks.SEA_LANTERN.defaultBlockState());
        fill(level, gx1 + 1, fy, wallZ, gx1 + 1, gTop, wallZ, Blocks.SEA_LANTERN.defaultBlockState());
        fill(level, gx0, gTop, wallZ, gx1, gTop, wallZ, Blocks.SEA_LANTERN.defaultBlockState());
    }

    /** Puntos de saque por equipo: 5 posiciones estándar, escaladas a la cancha. */
    public static void registerSpawns(ServerLevel level, ArenaConfig a) {
        ArenaSpawnRegistry.clear(level);
        double s = a.scale();
        double[][] slots = { {-20.48, 25.6}, {20.48, 25.6}, {0, 46.08}, {-2.56, 38.4}, {2.56, 38.4} };
        Vec3 c = a.center();
        for (int team = 0; team < 2; team++) {
            double sgn = team == 0 ? -1 : 1;
            for (double[] sl : slots) {
                Vec3 p = new Vec3(c.x + sl[0] * s, c.y, c.z + sgn * sl[1] * s);
                float yaw = (float) Math.toDegrees(Math.atan2(-(c.x - p.x), (c.z - p.z)));
                ArenaSpawnRegistry.add(level, new ArenaSpawnRegistry.SpawnPoint(p, yaw, team));
            }
        }
    }

    private static void set(ServerLevel level, int x, int y, int z, BlockState st) {
        level.setBlock(new BlockPos(x, y, z), st, FLAGS);
    }

    private static void fill(ServerLevel level, int x0, int y0, int z0, int x1, int y1, int z1, BlockState st) {
        for (int x = Math.min(x0, x1); x <= Math.max(x0, x1); x++)
            for (int y = Math.min(y0, y1); y <= Math.max(y0, y1); y++)
                for (int z = Math.min(z0, z1); z <= Math.max(z0, z1); z++)
                    set(level, x, y, z, st);
    }

}
