package dev.nucleoarena.arena;

import dev.nucleoarena.entity.VehicleEntity;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * Puntos de reaparición (SpawnPoints) por equipo, a los lados de su propia mitad de la cancha.
 *
 * Esta versión es en memoria: para persistir entre reinicios, mover POINTS a un SavedData
 * del ServerLevel y añadir comandos (/nucleo spawn add <team>) que llamen a add().
 */
public final class ArenaSpawnRegistry {
    private ArenaSpawnRegistry() {}

    /** yawDeg usa la convención de Minecraft (0 = +Z, 90 = -X). */
    public record SpawnPoint(Vec3 pos, float yawDeg, int team) {}

    private static final Map<ResourceKey<Level>, List<SpawnPoint>> POINTS = new HashMap<>();
    private static final Random RNG = new Random();

    public static void add(ServerLevel level, SpawnPoint p) {
        POINTS.computeIfAbsent(level.dimension(), k -> new ArrayList<>()).add(p);
    }

    public static List<SpawnPoint> forTeam(ServerLevel level, int team) {
        List<SpawnPoint> out = new ArrayList<>();
        for (SpawnPoint p : POINTS.getOrDefault(level.dimension(), List.of())) if (p.team() == team) out.add(p);
        return out;
    }

    public static void clear(ServerLevel level) {
        POINTS.remove(level.dimension());
    }

    /** Elige un punto libre del equipo (sin coches a < 3 bloques); si todos están ocupados, uno al azar. */
    public static SpawnPoint pick(ServerLevel level, int team, VehicleEntity self) {
        List<SpawnPoint> mine = new ArrayList<>();
        for (SpawnPoint p : POINTS.getOrDefault(level.dimension(), List.of())) {
            if (p.team() == team) mine.add(p);
        }
        if (mine.isEmpty()) return null;

        List<SpawnPoint> free = new ArrayList<>();
        for (SpawnPoint p : mine) {
            AABB zone = new AABB(p.pos(), p.pos()).inflate(3.0);
            boolean occupied = !level.getEntitiesOfClass(VehicleEntity.class, zone,
                    c -> c != self && c.isActiveCar()).isEmpty();
            if (!occupied) free.add(p);
        }
        List<SpawnPoint> pool = free.isEmpty() ? mine : free;
        return pool.get(RNG.nextInt(pool.size()));
    }
}
