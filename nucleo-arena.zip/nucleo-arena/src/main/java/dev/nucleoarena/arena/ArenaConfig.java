package dev.nucleoarena.arena;

import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Cancha rectangular. Largo en Z, ancho en X. {@code center} = centro del suelo (y = cara superior del suelo).
 * Equipo 0 (AZUL) defiende la portería de −Z; equipo 1 (NARANJA) la de +Z.
 * Medidas "full" ≈ las de Rocket League (82 × 102 × 20 m, portería 14 × 9 × 5 m).
 */
public record ArenaConfig(Vec3 center, int halfW, int halfL, int height,
                          int goalHalfW, int goalHeight, int goalDepth) {

    /** Doble de grande que Rocket League (164 × 204 × 40; portería 28 × 17 × 11). */
    public static ArenaConfig full(Vec3 c)  { return new ArenaConfig(c, 82, 102, 40, 14, 17, 11); }
    /** Tamaño Rocket League (82 × 102 × 20; portería 18 × 7 × 9). */
    public static ArenaConfig small(Vec3 c) { return new ArenaConfig(c, 41, 51, 20, 7, 9, 5); }

    /** Factor respecto a la cancha completa (para escalar pads y posiciones de saque). */
    public double scale() { return halfL / 51.2; }

    public AABB bounds() {
        return new AABB(center.x - halfW - 2, center.y - 2, center.z - halfL - goalDepth - 3,
                center.x + halfW + 2, center.y + height + 2, center.z + halfL + goalDepth + 3);
    }

    /** Equipo que ANOTA si el balón entra en la portería indicada (end = −1 ó +1 en Z). */
    public static int scorerForEnd(int end) { return end < 0 ? 1 : 0; }
}
