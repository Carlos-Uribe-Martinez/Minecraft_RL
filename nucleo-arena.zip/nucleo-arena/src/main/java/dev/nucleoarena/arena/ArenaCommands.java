package dev.nucleoarena.arena;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import dev.nucleoarena.NucleoArena;
import dev.nucleoarena.entity.BoostPadEntity;
import dev.nucleoarena.entity.CustomBallEntity;
import dev.nucleoarena.entity.VehicleEntity;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.phys.Vec3;

/**
 * /nucleo arena build [full|small] · join blue|orange · kind nomad|caribe · start · stop
 *         car · ball · pad small|large · clean
 *
 * ⚠ SIN restricción de permisos: en 1.21.11+ el sistema de permisos cambió (PermissionCheck).
 *   Añade .requires(Commands.hasPermission(...)) con la constante de tu versión antes de usarlo en un servidor público.
 */
public final class ArenaCommands {
    private ArenaCommands() {}

    public static void register(CommandDispatcher<CommandSourceStack> d) {
        d.register(Commands.literal("nucleo")
            .then(Commands.literal("arena").then(Commands.literal("build")
                .executes(c -> build(c, false))
                .then(Commands.literal("full").executes(c -> build(c, false)))
                .then(Commands.literal("small").executes(c -> build(c, true)))))
            .then(Commands.literal("join")
                .then(Commands.literal("blue").executes(c -> join(c, 0)))
                .then(Commands.literal("orange").executes(c -> join(c, 1))))
            .then(Commands.literal("kind")
                .then(Commands.literal("nomad").executes(c -> kind(c, VehicleEntity.Kind.NOMAD)))
                .then(Commands.literal("caribe").executes(c -> kind(c, VehicleEntity.Kind.CARIBE))))
            .then(Commands.literal("start").executes(ArenaCommands::start))
            .then(Commands.literal("stop").executes(c -> { MatchManager.stop(); return msg(c, "Partido detenido"); }))
            .then(Commands.literal("car").executes(ArenaCommands::car))
            .then(Commands.literal("ball").executes(ArenaCommands::ball))
            .then(Commands.literal("pad")
                .then(Commands.literal("small").executes(c -> pad(c, false)))
                .then(Commands.literal("large").executes(c -> pad(c, true))))
            .then(Commands.literal("clean").executes(ArenaCommands::clean)));
    }

    private static int msg(CommandContext<CommandSourceStack> c, String m) {
        c.getSource().sendSuccess(() -> Component.literal(m), false);
        return 1;
    }

    private static int build(CommandContext<CommandSourceStack> c, boolean small) throws CommandSyntaxException {
        ServerPlayer p = c.getSource().getPlayerOrException();
        var pos = p.blockPosition();
        MatchManager.buildArena(c.getSource().getLevel(), new Vec3(pos.getX(), pos.getY(), pos.getZ()), small);
        return msg(c, "Cancha construida. Úne a los jugadores con /nucleo join blue|orange y usa /nucleo start");
    }

    private static int join(CommandContext<CommandSourceStack> c, int team) throws CommandSyntaxException {
        MatchManager.join(c.getSource().getPlayerOrException(), team);
        return msg(c, "Equipo " + (team == 0 ? "AZUL" : "NARANJA"));
    }

    private static int kind(CommandContext<CommandSourceStack> c, VehicleEntity.Kind k) throws CommandSyntaxException {
        MatchManager.setKind(c.getSource().getPlayerOrException(), k);
        return msg(c, "Coche: " + k.name());
    }

    private static int start(CommandContext<CommandSourceStack> c) {
        String err = MatchManager.start(c.getSource().getServer());
        if (err != null) { c.getSource().sendFailure(Component.literal(err)); return 0; }
        return msg(c, "¡Partido iniciado!");
    }

    /** Modo práctica: coche suelto delante del jugador, sin partido. */
    private static int car(CommandContext<CommandSourceStack> c) throws CommandSyntaxException {
        ServerPlayer p = c.getSource().getPlayerOrException();
        ServerLevel level = c.getSource().getLevel();
        VehicleEntity car = NucleoArena.VEHICLE.create(level, EntitySpawnReason.COMMAND);
        car.setTeam(MatchManager.teamOf(p));
        car.setKind(MatchManager.kindOf(p));
        car.setPos(p.position());
        level.addFreshEntity(car);
        car.placeAt(p.position().add(p.getLookAngle().multiply(3, 0, 3)), p.getYRot(), 33.3f);
        p.startRiding(car);
        return msg(c, "Coche creado. Mayús (sneak) para bajar.");
    }

    private static int ball(CommandContext<CommandSourceStack> c) throws CommandSyntaxException {
        ServerPlayer p = c.getSource().getPlayerOrException();
        CustomBallEntity b = NucleoArena.BALL.create(c.getSource().getLevel(), EntitySpawnReason.COMMAND);
        b.placeCenterAt(p.position().add(p.getLookAngle().multiply(8, 0, 8)).add(0, 3, 0));
        c.getSource().getLevel().addFreshEntity(b);
        return msg(c, "Balón creado");
    }

    private static int pad(CommandContext<CommandSourceStack> c, boolean large) throws CommandSyntaxException {
        ServerPlayer p = c.getSource().getPlayerOrException();
        BoostPadEntity pad = NucleoArena.BOOST_PAD.create(c.getSource().getLevel(), EntitySpawnReason.COMMAND);
        pad.setLarge(large);
        pad.setPos(p.getX(), p.getY() + 0.05, p.getZ());
        c.getSource().getLevel().addFreshEntity(pad);
        return msg(c, "Pad creado");
    }

    private static int clean(CommandContext<CommandSourceStack> c) {
        ServerLevel level = c.getSource().getLevel();
        var box = c.getSource().getPosition();
        var area = new net.minecraft.world.phys.AABB(box, box).inflate(150);
        int n = 0;
        for (Entity e : level.getEntitiesOfClass(Entity.class, area,
                x -> x instanceof VehicleEntity || x instanceof CustomBallEntity || x instanceof BoostPadEntity)) { e.discard(); n++; }
        final int removed = n;
        return msg(c, "Eliminadas " + removed + " entidades");
    }
}
