package dev.nucleoarena.arena;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import dev.nucleoarena.NucleoArena;
import dev.nucleoarena.entity.BoostPadEntity;
import dev.nucleoarena.entity.CustomBallEntity;
import dev.nucleoarena.entity.VehicleEntity;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.phys.Vec3;

/**
 * /nucleo arena build [full|small] [rampas 0-4] · time add|set <min> · train ball|lob|lift|dummy · join blue|orange · kind nomad|caribe · start · stop
 *         car · ball · pad small|large · clean
 *
 * ⚠ SIN restricción de permisos: en 1.21.11+ el sistema de permisos cambió (PermissionCheck).
 *   Añade .requires(Commands.hasPermission(...)) con la constante de tu versión antes de usarlo en un servidor público.
 */
public final class ArenaCommands {
    private ArenaCommands() {}

    public static void register(CommandDispatcher<CommandSourceStack> d) {
        d.register(Commands.literal("nucleo")
            .then(Commands.literal("arena")
                .then(Commands.literal("destroy")
                    .then(Commands.literal("small").executes(c -> destroy(c, true)))
                    .then(Commands.literal("full").executes(c -> destroy(c, false))))
                .then(Commands.literal("build")
                .executes(c -> build(c, false, -1))
                .then(Commands.literal("full").executes(c -> build(c, false, -1))
                    .then(Commands.argument("rampas", com.mojang.brigadier.arguments.IntegerArgumentType.integer(0, 4))
                        .executes(c -> build(c, false, com.mojang.brigadier.arguments.IntegerArgumentType.getInteger(c, "rampas")))))
                .then(Commands.literal("small").executes(c -> build(c, true, -1))
                    .then(Commands.argument("rampas", com.mojang.brigadier.arguments.IntegerArgumentType.integer(0, 4))
                        .executes(c -> build(c, true, com.mojang.brigadier.arguments.IntegerArgumentType.getInteger(c, "rampas")))))
                .then(Commands.argument("rampas", com.mojang.brigadier.arguments.IntegerArgumentType.integer(0, 4))
                    .executes(c -> build(c, false, com.mojang.brigadier.arguments.IntegerArgumentType.getInteger(c, "rampas"))))))
            .then(Commands.literal("join")
                .then(Commands.literal("blue").executes(c -> join(c, 0)))
                .then(Commands.literal("orange").executes(c -> join(c, 1))))
            .then(Commands.literal("kind")
                .then(Commands.literal("nomad").executes(c -> kind(c, VehicleEntity.Kind.NOMAD)))
                .then(Commands.literal("caribe").executes(c -> kind(c, VehicleEntity.Kind.CARIBE))))
            .then(Commands.literal("time")
                .then(Commands.literal("add").then(Commands.argument("min", com.mojang.brigadier.arguments.IntegerArgumentType.integer(1, 120))
                    .executes(c -> time(c, true))))
                .then(Commands.literal("set").then(Commands.argument("min", com.mojang.brigadier.arguments.IntegerArgumentType.integer(1, 120))
                    .executes(c -> time(c, false)))))
            .then(Commands.literal("train")
                .then(Commands.literal("ball").executes(c -> train(c, 0)))
                .then(Commands.literal("lift").executes(c -> train(c, 1)))
                .then(Commands.literal("lob").executes(c -> train(c, 2)))
                .then(Commands.literal("dummy").executes(c -> train(c, 3))))
            .then(Commands.literal("sulfur").executes(ArenaCommands::sulfur))
            .then(Commands.literal("invisible")
                .then(Commands.argument("que", com.mojang.brigadier.arguments.StringArgumentType.word())
                    .then(Commands.argument("valor", com.mojang.brigadier.arguments.BoolArgumentType.bool())
                        .executes(ArenaCommands::invisible))))
            .then(Commands.literal("start").executes(ArenaCommands::start))
            .then(Commands.literal("stop").executes(c -> { MatchManager.stop(); return msg(c, "Partido detenido"); }))
            .then(Commands.literal("car").executes(ArenaCommands::car))
            .then(Commands.literal("ball").executes(ArenaCommands::ball))
            .then(Commands.literal("pad")
                .then(Commands.literal("small").executes(c -> pad(c, false)))
                .then(Commands.literal("large").executes(c -> pad(c, true))))
            .then(Commands.literal("clean").executes(ArenaCommands::clean)));
    }

    private static int msg(CommandContext<CommandSourceStack> c, String m) {
        c.getSource().sendSuccess(() -> Component.literal(m), false);
        return 1;
    }

    /** /nucleo arena destroy small|full: borra la cancha de ese tamaño (centro = la arena actual, o tu posición) y sus entidades. */
    private static int destroy(CommandContext<CommandSourceStack> c, boolean small) throws CommandSyntaxException {
        ServerPlayer p = c.getSource().getPlayerOrException();
        Vec3 center;
        if (MatchManager.arena() != null) center = MatchManager.arena().center();
        else { var pos = p.blockPosition(); center = new Vec3(pos.getX(), pos.getY(), pos.getZ()); }
        MatchManager.destroyArena(c.getSource().getLevel(), small ? ArenaConfig.small(center) : ArenaConfig.full(center));
        return msg(c, "Arena " + (small ? "small" : "full") + " destruida (bloques y entidades)");
    }

    private static int build(CommandContext<CommandSourceStack> c, boolean small, int rampRows) throws CommandSyntaxException {
        ServerPlayer p = c.getSource().getPlayerOrException();
        var pos = p.blockPosition();
        MatchManager.buildArena(c.getSource().getLevel(), new Vec3(pos.getX(), pos.getY(), pos.getZ()), small, rampRows);
        return msg(c, "Cancha construida. Úne a los jugadores con /nucleo join blue|orange y usa /nucleo start");
    }

    private static int join(CommandContext<CommandSourceStack> c, int team) throws CommandSyntaxException {
        MatchManager.join(c.getSource().getPlayerOrException(), team);
        return msg(c, "Equipo " + (team == 0 ? "AZUL" : "NARANJA"));
    }

    private static int kind(CommandContext<CommandSourceStack> c, VehicleEntity.Kind k) throws CommandSyntaxException {
        ServerPlayer p = c.getSource().getPlayerOrException();
        MatchManager.setKind(p, k);
        if (p.getVehicle() instanceof VehicleEntity car) car.setKind(k);       // cambia el coche que conduces ahora mismo
        return msg(c, "Coche: " + k.name());
    }

    private static int time(CommandContext<CommandSourceStack> c, boolean add) {
        int min = com.mojang.brigadier.arguments.IntegerArgumentType.getInteger(c, "min");
        String err = add ? MatchManager.addMinutes(min) : MatchManager.setMinutes(min);
        if (err != null) { c.getSource().sendFailure(Component.literal(err)); return 0; }
        return msg(c, add ? "+" + min + " min" : "Tiempo restante: " + min + " min");
    }

    private static int train(CommandContext<CommandSourceStack> c, int action) throws CommandSyntaxException {
        MatchManager.train(c.getSource().getPlayerOrException(), action);
        return 1;
    }

    /** Prueba: cubo de azufre "football" (escala 4, gravedad de Rocket League 6.5 m/s²) delante del jugador. */
    /** /nucleo invisible <ball|car|cube|all> <true|false>: oculta o muestra el balón, los coches o los cubos de azufre. */
    private static int invisible(CommandContext<CommandSourceStack> c) throws CommandSyntaxException {
        String what = com.mojang.brigadier.arguments.StringArgumentType.getString(c, "que").toLowerCase(java.util.Locale.ROOT);
        boolean v = com.mojang.brigadier.arguments.BoolArgumentType.getBool(c, "valor");
        ServerPlayer p = c.getSource().getPlayerOrException();
        var box = new net.minecraft.world.phys.AABB(p.position(), p.position()).inflate(500.0);
        int n = 0;
        for (net.minecraft.world.entity.Entity e : p.level().getEntitiesOfClass(net.minecraft.world.entity.Entity.class, box)) {
            boolean ball = e instanceof CustomBallEntity, car = e instanceof VehicleEntity, cube = dev.nucleoarena.Football.isSulfur(e);
            boolean match = switch (what) {
                case "ball", "balon" -> ball;
                case "car", "coche" -> car;
                case "cube", "cubo" -> cube;
                case "all", "todo" -> ball || car || cube;
                default -> false;
            };
            if (match) { e.setInvisible(v); n++; }
        }
        return msg(c, (v ? "Invisibles: " : "Visibles: ") + n + " (" + what + ")");
    }

    private static int sulfur(CommandContext<CommandSourceStack> c) throws CommandSyntaxException {
        ServerPlayer p = c.getSource().getPlayerOrException();
        Vec3 look = p.getLookAngle().multiply(1, 0, 1);
        Vec3 pos = p.position().add(look.lengthSqr() > 1.0E-6 ? look.normalize().scale(8) : Vec3.ZERO).add(0, 2, 0);
        var server = c.getSource().getServer();
        net.minecraft.server.level.ServerLevel lvl = p.level() instanceof net.minecraft.server.level.ServerLevel sl ? sl : server.overworld();
        var src = server.createCommandSourceStack().withLevel(lvl).withPosition(pos);
        var cmds = server.getCommands();
        String sel = "@e[type=minecraft:sulfur_cube,limit=1,sort=nearest,distance=..3]";   // el recién invocado (en la posición del origen)

        cmds.performPrefixedCommand(src, String.format(java.util.Locale.ROOT, "summon minecraft:sulfur_cube %.2f %.2f %.2f", pos.x, pos.y, pos.z));
        cmds.performPrefixedCommand(src, "data modify entity " + sel + " CustomName set value \"football\"");
        cmds.performPrefixedCommand(src, "data modify entity " + sel + " equipment.body set value {id:\"minecraft:oak_planks\",count:1}");
        cmds.performPrefixedCommand(src, "attribute " + sel + " minecraft:scale base set 4");

        // El cubo adopta la física del balón del mod: un balón invisible (física, colisiones, goles) y el cubo lo sigue.
        net.minecraft.world.entity.LivingEntity cube = null;
        double best = Double.MAX_VALUE;
        for (var e : lvl.getEntitiesOfClass(net.minecraft.world.entity.LivingEntity.class,
                new net.minecraft.world.phys.AABB(pos, pos).inflate(3.0), dev.nucleoarena.Football::isSulfur)) {
            double d = e.position().distanceToSqr(pos);
            if (d < best) { best = d; cube = e; }
        }
        if (cube == null) return msg(c, "No se pudo invocar el cubo de azufre (¿existe minecraft:sulfur_cube en esta versión?)");

        if (cube instanceof net.minecraft.world.entity.Mob m) m.setNoAi(true);
        cube.setNoGravity(true);
        // Sin hitbox contra entidades: equipo con colisión "never" (el balón invisible lleva toda la colisión)
        cmds.performPrefixedCommand(src, "team add nucleo_nocol");
        cmds.performPrefixedCommand(src, "team modify nucleo_nocol collisionRule never");
        cmds.performPrefixedCommand(src, "team join nucleo_nocol " + cube.getUUID());

        dev.nucleoarena.entity.CustomBallEntity ball = NucleoArena.BALL.create(lvl, net.minecraft.world.entity.EntitySpawnReason.COMMAND);
        ball.setPos(pos.x, pos.y, pos.z);
        lvl.addFreshEntity(ball);
        ball.placeCenterAt(pos);
        ball.setPuppet(cube.getUUID());
        dev.nucleoarena.Football.link(cube.getUUID(), ball.getUUID());
        MatchManager.adoptBall(ball);                                   // cuenta para gol si hay arena
        return msg(c, "Cubo de azufre \"football\" con física de balón (escala 4)");
    }

    private static int start(CommandContext<CommandSourceStack> c) {
        String err = MatchManager.start(c.getSource().getServer());
        if (err != null) { c.getSource().sendFailure(Component.literal(err)); return 0; }
        return msg(c, "¡Partido iniciado!");
    }

    /** Modo práctica: coche suelto delante del jugador, sin partido. */
    private static int car(CommandContext<CommandSourceStack> c) throws CommandSyntaxException {
        ServerPlayer p = c.getSource().getPlayerOrException();
        ServerLevel level = c.getSource().getLevel();
        VehicleEntity car = NucleoArena.VEHICLE.create(level, EntitySpawnReason.COMMAND);
        car.setTeam(MatchManager.teamOf(p));
        car.setKind(MatchManager.kindOf(p));
        car.setPos(p.position());
        level.addFreshEntity(car);
        car.placeAt(p.position().add(p.getLookAngle().multiply(3, 0, 3)), p.getYRot(), 33.3f);
        p.startRiding(car);
        return msg(c, "Coche creado. Mayús (sneak) para bajar.");
    }

    private static int ball(CommandContext<CommandSourceStack> c) throws CommandSyntaxException {
        ServerPlayer p = c.getSource().getPlayerOrException();
        CustomBallEntity b = NucleoArena.BALL.create(c.getSource().getLevel(), EntitySpawnReason.COMMAND);
        b.placeCenterAt(p.position().add(p.getLookAngle().multiply(8, 0, 8)).add(0, 3, 0));
        c.getSource().getLevel().addFreshEntity(b);
        return msg(c, "Balón creado");
    }

    private static int pad(CommandContext<CommandSourceStack> c, boolean large) throws CommandSyntaxException {
        ServerPlayer p = c.getSource().getPlayerOrException();
        BoostPadEntity pad = NucleoArena.BOOST_PAD.create(c.getSource().getLevel(), EntitySpawnReason.COMMAND);
        pad.setLarge(large);
        pad.setPos(p.getX(), p.getY() + 0.05, p.getZ());
        c.getSource().getLevel().addFreshEntity(pad);
        return msg(c, "Pad creado");
    }

    private static int clean(CommandContext<CommandSourceStack> c) {
        ServerLevel level = c.getSource().getLevel();
        var box = c.getSource().getPosition();
        var area = new net.minecraft.world.phys.AABB(box, box).inflate(150);
        int n = 0;
        for (Entity e : level.getEntitiesOfClass(Entity.class, area,
                x -> x instanceof VehicleEntity || x instanceof CustomBallEntity || x instanceof BoostPadEntity
                        || dev.nucleoarena.Football.isBigSulfur(x) || MatchManager.isProp(x))) { e.discard(); n++; }
        final int removed = n;
        return msg(c, "Eliminadas " + removed + " entidades");
    }
}
