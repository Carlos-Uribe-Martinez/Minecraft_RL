package dev.nucleoarena.arena;

import dev.nucleoarena.NucleoArena;
import dev.nucleoarena.entity.BoostPadEntity;
import dev.nucleoarena.entity.CustomBallEntity;
import dev.nucleoarena.entity.VehicleEntity;
import dev.nucleoarena.net.StatsPayload;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.phys.Vec3;

import java.util.*;

import static dev.nucleoarena.physics.PhysicsConstants.*;

/**
 * Reglas de partido (un único partido global, en memoria):
 *   IDLE → COUNTDOWN (3 s, todo congelado) → PLAYING (5 min) → GOAL (celebración 3 s) → COUNTDOWN …
 *   Si el tiempo acaba empatado: OVERTIME (gol de oro). Al terminar: ENDED y limpieza a los 10 s.
 */
public final class MatchManager {
    private MatchManager() {}

    public enum State { IDLE, COUNTDOWN, PLAYING, GOAL, OVERTIME, ENDED }

    private static final int MATCH_TICKS = 5 * 60 * 20;
    private static final int COUNTDOWN_TICKS = 3 * 20;
    private static final int GOAL_TICKS = 3 * 20;
    private static final int END_TICKS = 10 * 20;
    private static final String[] TEAM_NAME = { "AZUL", "NARANJA" };
    private static final int[] TEAM_RGB = { 0x3C8CFF, 0xFF8C1E };

    /** Estadísticas por jugador (una entrada por jugador). */
    public static final class Stats {
        public String name = ""; public int team, goals, assists, shots, saves, demos;
        long lastShot, lastSave;
    }
    private static final Map<UUID, Stats> stats = new LinkedHashMap<>();
    private static UUID lastTouchId, prevTouchId;
    private static long lastTouchTick, prevTouchTick;

    private static ServerLevel level;
    private static ArenaConfig arena;
    private static State state = State.IDLE;
    private static int timer, clock, overtimeTicks;
    private static final int[] score = new int[2];
    private static CustomBallEntity ball;
    private static final Map<UUID, Integer> teams = new HashMap<>();
    private static final Map<UUID, VehicleEntity.Kind> kinds = new HashMap<>();

    // Pads de Rocket League (uu → m); 6 grandes + 28 pequeños, simétricos
    private static final double[][] LARGE = { {-3072,-4096},{3072,-4096},{-3584,0},{3584,0},{-3072,4096},{3072,4096} };
    private static final double[][] SMALL = {
        {0,-4240},{-1792,-4184},{1792,-4184},{-940,-3308},{940,-3308},{0,-2816},{-3584,-2484},{3584,-2484},
        {-1788,-2300},{1788,-2300},{-2048,-1036},{0,-1024},{2048,-1036},{-1024,0},{1024,0},{-2048,1036},
        {0,1024},{2048,1036},{-1788,2300},{1788,2300},{-3584,2484},{3584,2484},{0,2816},{-940,3308},
        {940,3308},{-1792,4184},{1792,4184},{0,4240} };

    // ───────────────────────── Configuración ─────────────────────────

    public static void buildArena(ServerLevel lvl, Vec3 center, boolean small, int rampRows) {
        level = lvl;
        ArenaBuilder.rampRows = rampRows;
        arena = small ? ArenaConfig.small(center) : ArenaConfig.full(center);
        ArenaBuilder.build(lvl, arena);
        ArenaBuilder.registerSpawns(lvl, arena);
    }

    public static boolean hasArena() { return arena != null; }
    public static ArenaConfig arena() { return arena; }
    public static ServerLevel level() { return level; }
    public static void join(ServerPlayer p, int team) { teams.put(p.getUUID(), team); }
    public static void setKind(ServerPlayer p, VehicleEntity.Kind k) { kinds.put(p.getUUID(), k); }
    public static int teamOf(ServerPlayer p) { return teams.getOrDefault(p.getUUID(), 0); }
    public static VehicleEntity.Kind kindOf(ServerPlayer p) { return kinds.getOrDefault(p.getUUID(), VehicleEntity.Kind.NOMAD); }
    public static State state() { return state; }
    public static CustomBallEntity matchBall() { return ball; }

    // ───────────────────────── Tiempo ─────────────────────────

    /** Añade minutos al reloj (en tiempo extra lo cancela y vuelve al tiempo reglamentario). @return mensaje o null */
    public static String addMinutes(int minutes) {
        if (state != State.PLAYING && state != State.OVERTIME && state != State.COUNTDOWN) return "No hay partido en juego";
        if (state == State.OVERTIME) { state = State.PLAYING; clock = minutes * 1200; overtimeTicks = 0; }
        else clock += minutes * 1200;
        return null;
    }

    /** Fija el tiempo restante en minutos. */
    public static String setMinutes(int minutes) {
        if (state != State.PLAYING && state != State.OVERTIME && state != State.COUNTDOWN) return "No hay partido en juego";
        if (state == State.OVERTIME) { state = State.PLAYING; overtimeTicks = 0; }
        clock = Math.max(20, minutes * 1200);
        return null;
    }

    // ───────────────────────── Entrenamiento ─────────────────────────

    /** Acciones de práctica sobre el balón más cercano al jugador (o el del partido). */
    public static void train(ServerPlayer p, int action) {
        ServerLevel lvl = p.level() instanceof ServerLevel sl ? sl : null;
        if (lvl == null) return;
        VehicleEntity car = p.getVehicle() instanceof VehicleEntity v ? v : null;
        Vec3 base = car != null ? car.position() : p.position();
        float yaw = (float) Math.toRadians(car != null ? car.getYRot() : p.getYRot());
        Vec3 fwd = new Vec3(-Math.sin(yaw), 0, Math.cos(yaw));

        if (action == 3) {                       // coche rival inmóvil delante: prueba de demolición
            for (VehicleEntity d : lvl.getEntitiesOfClass(VehicleEntity.class, new net.minecraft.world.phys.AABB(base, base).inflate(60),
                    e -> e.getFirstPassenger() == null)) d.discard();
            VehicleEntity dummy = NucleoArena.VEHICLE.create(lvl, EntitySpawnReason.COMMAND);
            dummy.setTeam(car != null ? 1 - car.getArenaTeamId() : 1);
            dummy.setKind(VehicleEntity.Kind.CARIBE);
            dummy.setPos(base.add(fwd.scale(26)));
            lvl.addFreshEntity(dummy);
            dummy.placeAt(base.add(fwd.scale(26)), p.getYRot() + 180f, 33.3f);
            return;
        }

        CustomBallEntity b = ball;
        double best = Double.MAX_VALUE;
        for (CustomBallEntity e : lvl.getEntitiesOfClass(CustomBallEntity.class, new net.minecraft.world.phys.AABB(base, base).inflate(300))) {
            double d = e.position().distanceToSqr(base);
            if (d < best) { best = d; b = e; }
        }
        if (b == null) {                         // sin balón: crea uno de práctica
            b = NucleoArena.BALL.create(lvl, EntitySpawnReason.COMMAND);
            b.setPos(base.add(fwd.scale(10)));
            lvl.addFreshEntity(b);
        }
        b.setFrozen(false);
        switch (action) {
            case 0 -> {                          // balón delante del coche
                b.placeCenterAt(base.add(fwd.scale(7)).add(0, BALL_CENTER_Y_REST, 0));
                b.setDeltaMovement(Vec3.ZERO);
            }
            case 1 -> {                          // levantarlo: sube y rebota en su sitio
                b.setDeltaMovement(new Vec3(0, 1.1, 0));
            }
            case 2 -> {                          // lanzarlo hacia mí con altura y arco (como un centro)
                Vec3 from = base.add(fwd.scale(45)).add(0, 6, 0);
                b.placeCenterAt(from);
                int T = 60;                                              // ticks de vuelo
                Vec3 target = base.add(0, BALL_CENTER_Y_REST + 1.0, 0);
                double vx = (target.x - from.x) / T, vz = (target.z - from.z) / T;
                double vy = (target.y - from.y + 0.5 * GRAVITY * T * (T + 1)) / T;
                b.setDeltaMovement(new Vec3(vx, vy, vz));
            }
            default -> {}
        }
    }


    // ───────────────────────── Ciclo de vida ─────────────────────────

    /** @return mensaje de error, o null si arrancó. */
    public static String start(MinecraftServer server) {
        if (arena == null || level == null) return "Primero construye la cancha: /nucleo arena build";
        List<ServerPlayer> players = new ArrayList<>();
        for (ServerPlayer p : server.getPlayerList().getPlayers()) if (teams.containsKey(p.getUUID())) players.add(p);
        if (players.isEmpty()) return "Nadie se ha unido: /nucleo join blue|orange";

        cleanEntities();
        score[0] = score[1] = 0;
        clock = MATCH_TICKS;
        overtimeTicks = 0;
        stats.clear();
        for (ServerPlayer sp : players) { Stats st = stat(sp); st.team = teamOf(sp); }

        Vec3 c = arena.center();
        double s = arena.scale();
        for (double[] p : LARGE) spawnPad(c.x + p[0] / 100.0 * s, c.z + p[1] / 100.0 * s, true);
        for (double[] p : SMALL) spawnPad(c.x + p[0] / 100.0 * s, c.z + p[1] / 100.0 * s, false);

        ball = NucleoArena.BALL.create(level, EntitySpawnReason.COMMAND);
        ball.setTrail(0);
        ball.setPos(c.x, c.y, c.z);
        level.addFreshEntity(ball);

        int[] slot = new int[2];
        for (ServerPlayer p : players) {
            int team = teamOf(p);
            VehicleEntity car = NucleoArena.VEHICLE.create(level, EntitySpawnReason.COMMAND);
            car.setTeam(team);
            car.setKind(kindOf(p));
            car.setPos(c.x, c.y, c.z);                 // dentro de chunks cargados antes de añadirlo
            level.addFreshEntity(car);
            p.startRiding(car);
            carSlots.put(car, slot[team]++);
        }
        beginKickoff();
        return null;
    }

    private static final Map<VehicleEntity, Integer> carSlots = new HashMap<>();

    /** Si un coche sale de la cancha, vuelve dentro, detrás del coche más cercano que siga dentro (o en su saque). */
    public static void rescueIfEscaped(VehicleEntity car) {
        if (arena == null || level == null || car.level() != level) return;
        if (state != State.PLAYING && state != State.OVERTIME && state != State.GOAL) return;
        if (car.getFirstPassenger() == null) return;
        if (arena.bounds().inflate(3.0).contains(car.position().add(0, 1.0, 0))) return;

        VehicleEntity nearest = null;
        double bd = Double.MAX_VALUE;
        for (VehicleEntity o : level.getEntitiesOfClass(VehicleEntity.class, arena.bounds(),
                x -> x != car && x.isActiveCar() && x.getFirstPassenger() != null)) {
            double d = o.position().distanceToSqr(car.position());
            if (d < bd) { bd = d; nearest = o; }
        }
        Vec3 pos;
        float yaw;
        if (nearest != null) {
            yaw = nearest.getYRot();
            double r = Math.toRadians(yaw);
            Vec3 fwd = new Vec3(-Math.sin(r), 0, Math.cos(r));
            pos = nearest.position().subtract(fwd.scale(6.0));              // detrás del más cercano
        } else {
            List<ArenaSpawnRegistry.SpawnPoint> pts = ArenaSpawnRegistry.forTeam(level, car.getArenaTeamId());
            if (pts.isEmpty()) return;
            pos = pts.get(0).pos(); yaw = pts.get(0).yawDeg();
        }
        car.placeAt(pos, yaw, car.getBoost());
    }

    public static void stop() {
        cleanEntities();
        carSlots.clear();
        ball = null;
        state = State.IDLE;
    }

    private static void cleanEntities() {
        if (level == null || arena == null) return;
        for (Entity e : level.getEntitiesOfClass(Entity.class, arena.bounds(),
                x -> x instanceof VehicleEntity || x instanceof CustomBallEntity || x instanceof BoostPadEntity)) e.discard();
        carSlots.clear();
    }

    private static void spawnPad(double x, double z, boolean large) {
        BoostPadEntity pad = NucleoArena.BOOST_PAD.create(level, EntitySpawnReason.COMMAND);
        pad.setPos(x, arena.center().y + 0.05, z);
        pad.setLarge(large);
        level.addFreshEntity(pad);
    }

    private static void beginKickoff() {
        state = State.COUNTDOWN;
        timer = COUNTDOWN_TICKS;
        // En cada saque se RECREAN los coches igual que en /nucleo start (que siempre funciona): coche nuevo,
        // estado y colas de entrada limpios, jugador vuelve a montarse. Evita jugadores "atascados" tras un gol.
        List<Map.Entry<VehicleEntity, Integer>> old = new ArrayList<>(carSlots.entrySet());
        carSlots.clear();
        for (Map.Entry<VehicleEntity, Integer> e : old) {
            VehicleEntity prev = e.getKey();
            if (prev.isRemoved()) continue;
            int team = prev.getArenaTeamId();
            VehicleEntity.Kind kind = prev.getKind();
            Entity rider = prev.getFirstPassenger();
            prev.ejectPassengers();
            prev.discard();

            List<ArenaSpawnRegistry.SpawnPoint> pts = ArenaSpawnRegistry.forTeam(level, team);
            ArenaSpawnRegistry.SpawnPoint sp = pts.get(Math.min(e.getValue(), pts.size() - 1));
            VehicleEntity car = NucleoArena.VEHICLE.create(level, EntitySpawnReason.COMMAND);
            car.setTeam(team);
            car.setKind(kind);
            car.setPos(sp.pos().x, sp.pos().y, sp.pos().z);
            level.addFreshEntity(car);
            car.placeAt(sp.pos(), sp.yawDeg(), BOOST_START);
            car.setFrozen(true);
            if (rider != null) rider.startRiding(car);
            carSlots.put(car, e.getValue());
        }
        Vec3 c = arena.center();
        ball.placeCenterAt(new Vec3(c.x, c.y + BALL_CENTER_Y_REST, c.z));
        ball.setFrozen(true);
    }

    private static void release() {
        for (VehicleEntity car : carSlots.keySet()) car.setFrozen(false);
        ball.setFrozen(false);
    }

    // ───────────────────────── Tick ─────────────────────────

    public static void tick(MinecraftServer server) {
        if (state == State.IDLE || level == null || ball == null) return;

        switch (state) {
            case COUNTDOWN -> {
                if (timer % 20 == 0) {
                    Component t = timer == 0
                            ? Component.literal("¡YA!").withStyle(s -> s.withColor(0x55FF55).withBold(true))
                            : Component.literal(String.valueOf(timer / 20)).withStyle(s -> s.withColor(0xFFFFFF).withBold(true));
                    titleAll(server, t, Component.empty(), 0, 18, 4);
                }
                if (--timer < 0) { release(); state = State.PLAYING; }
            }
            case PLAYING, OVERTIME -> {
                if (state == State.PLAYING && --clock <= 0) {
                    if (score[0] == score[1]) {
                        state = State.OVERTIME; overtimeTicks = 0;
                        titleAll(server, Component.literal("TIEMPO EXTRA").withStyle(s -> s.withColor(0xFFD84A).withBold(true)),
                                Component.literal("Gol de oro · máx. 15 min"), 5, 50, 15);
                    } else { finish(server); return; }
                }
                if (state == State.OVERTIME && ++overtimeTicks >= OVERTIME_MAX_TICKS) { finish(server); return; }
                int scorer = goalScorer();
                if (scorer >= 0) onGoal(server, scorer);
            }
            case GOAL -> {
                if (--timer <= 0) {
                    if (clock <= 0 && score[0] != score[1]) finish(server); else beginKickoff();
                }
            }
            case ENDED -> { if (--timer <= 0) stop(); }
            default -> {}
        }
        if (server.getTickCount() % 10 == 0) hud(server);
        if (server.getTickCount() % 20 == 0) sendStats(server);
    }

    private static int goalScorer() {
        Vec3 b = ball.getCenter(), c = arena.center();
        double dz = b.z - c.z;
        if (Math.abs(dz) > arena.halfL() + BALL_RADIUS
                && Math.abs(b.x - c.x) < arena.goalHalfW()
                && b.y < c.y + arena.goalHeight()) {
            return ArenaConfig.scorerForEnd(dz < 0 ? -1 : 1);
        }
        return -1;
    }

    private static void onGoal(MinecraftServer server, int scorer) {
        score[scorer]++;
        Stats st = ball.getLastToucherId() != null ? stats.get(ball.getLastToucherId()) : null;
        boolean credited = st != null && st.team == scorer;
        if (credited) {
            st.goals++;
            Stats as = prevTouchId != null ? stats.get(prevTouchId) : null;          // asistencia: pase previo (<10 s) de un compañero
            if (as != null && as != st && as.team == scorer && level.getGameTime() - prevTouchTick < 200) as.assists++;
        }
        prevTouchId = null; lastTouchId = null;
        String who = credited ? st.name : TEAM_NAME[scorer];
        Component title = Component.literal(who).withStyle(s -> s.withColor(TEAM_RGB[scorer]).withBold(true))
                .append(Component.literal(" anotó").withStyle(s -> s.withColor(0xFFFFFF).withBold(true)));
        Component sub = Component.literal("AZUL " + score[0] + " - " + score[1] + " NARANJA");
        titleAll(server, title, sub, 3, 50, 15);
        goalEffects(scorer);
        boolean golden = state == State.OVERTIME;
        state = State.GOAL;
        timer = GOAL_TICKS;
        if (golden) clock = 0;                      // fuerza el final tras la celebración
    }

    private static void finish(MinecraftServer server) {
        state = State.ENDED;
        timer = END_TICKS;
        if (score[0] == score[1]) {
            titleAll(server, Component.literal("EMPATE").withStyle(s -> s.withColor(0xFFFFFF).withBold(true)),
                    Component.literal("AZUL " + score[0] + " - " + score[1] + " NARANJA"), 5, 80, 20);
        } else {
            int w = score[0] > score[1] ? 0 : 1;
            titleAll(server, Component.literal(TEAM_NAME[w] + " GANA").withStyle(s -> s.withColor(TEAM_RGB[w]).withBold(true)),
                    Component.literal("AZUL " + score[0] + " - " + score[1] + " NARANJA"), 5, 80, 20);
        }
    }

    private static void hud(MinecraftServer server) {
        int secs = state == State.OVERTIME ? overtimeTicks / 20 : Math.max(0, clock / 20);
        String time = (state == State.OVERTIME ? "EXTRA +" : "") + (secs / 60) + ":" + String.format("%02d", secs % 60);
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            if (!teams.containsKey(p.getUUID())) continue;
            Component bar = Component.literal("AZUL ").withStyle(s -> s.withColor(TEAM_RGB[0]).withBold(true))
                    .append(Component.literal(score[0] + " - " + score[1] + " ").withStyle(s -> s.withColor(0xFFFFFF)))
                    .append(Component.literal("NARANJA").withStyle(s -> s.withColor(TEAM_RGB[1]).withBold(true)))
                    .append(Component.literal("  |  " + time).withStyle(s -> s.withColor(0xFFFFFF)));
            if (p.getVehicle() instanceof VehicleEntity c) {
                int b = Math.round(c.getBoost());
                int col = b >= 75 ? 0x55FF55 : b >= 50 ? 0xFF8C1E : b >= 25 ? 0xFFFF55 : 0xFF5555;    // verde / naranja / amarillo / rojo
                bar = bar.copy().append(Component.literal("  |  ").withStyle(s -> s.withColor(0xFFFFFF)))
                        .append(Component.literal("Boost ").withStyle(s -> s.withColor(0xFFFF55).withBold(true)))
                        .append(Component.literal(String.valueOf(b)).withStyle(s -> s.withColor(col).withBold(true)));
            }
            p.sendSystemMessage(bar, true);
        }
    }

    // ───────────────────────── Estadísticas, títulos y efectos ─────────────────────────

    private static Stats stat(ServerPlayer p) {
        Stats s = stats.computeIfAbsent(p.getUUID(), k -> new Stats());
        s.name = p.getName().getString();
        s.team = teamOf(p);
        return s;
    }

    private static void title(ServerPlayer p, Component title, Component sub, int in, int stay, int out) {
        p.connection.send(new ClientboundSetTitlesAnimationPacket(in, stay, out));
        p.connection.send(new ClientboundSetSubtitleTextPacket(sub));
        p.connection.send(new ClientboundSetTitleTextPacket(title));
    }

    private static void titleAll(MinecraftServer server, Component t, Component sub, int in, int stay, int out) {
        for (ServerPlayer p : server.getPlayerList().getPlayers()) title(p, t, sub, in, stay, out);
    }

    /** Reproduce un sonido para cada jugador, esté donde esté (sonando en su propia posición). */
    private static void playToAll(SoundEvent ev, SoundSource src, float vol, float pitch) {
        if (ev == null || level == null) return;
        for (ServerPlayer p : level.getServer().getPlayerList().getPlayers())
            level.playSound(null, p.getX(), p.getY(), p.getZ(), ev, src, vol, pitch);
    }

    private static SoundEvent sound(String id) {
        return BuiltInRegistries.SOUND_EVENT.getValue(Identifier.withDefaultNamespace(id));
    }

    private static void sendStats(MinecraftServer server) {
        if (arena == null) return;
        List<StatsPayload.Row> rows = new ArrayList<>();
        for (Stats s : stats.values()) rows.add(new StatsPayload.Row(s.name, s.team, s.goals, s.assists, s.shots, s.saves, s.demos));
        rows.sort(Comparator.comparingInt((StatsPayload.Row r) -> r.team()).thenComparing(r -> -r.goals()));
        int secs = state == State.OVERTIME ? overtimeTicks / 20 : Math.max(0, clock / 20);
        StatsPayload payload = new StatsPayload(score[0], score[1], secs, state == State.OVERTIME, rows);
        for (ServerPlayer p : server.getPlayerList().getPlayers()) ServerPlayNetworking.send(p, payload);
    }

    /** Partículas del color del equipo que anota + cuerno de cabra (trompeta de estadio). */
    private static void goalEffects(int scorer) {
        Vec3 c = arena.center();
        double dir = scorer == 0 ? 1 : -1;                                   // el azul anota en la portería +Z
        double gz = c.z + dir * (arena.halfL() + arena.goalDepth() * 0.5);
        double gy = c.y + arena.goalHeight() * 0.5;
        DustParticleOptions dust = new DustParticleOptions(TEAM_RGB[scorer], 2.2f);
        level.sendParticles(dust, c.x, gy, gz, 400, arena.goalHalfW() * 0.8, arena.goalHeight() * 0.45, arena.goalDepth() * 0.4, 0.02);
        level.sendParticles(ParticleTypes.FIREWORK, c.x, gy, gz, 120, arena.goalHalfW() * 0.6, arena.goalHeight() * 0.4, arena.goalDepth() * 0.3, 0.25);
        playToAll(sound("item.goat_horn.sound.0"), SoundSource.RECORDS, 2.0f, 1.0f);   // gol: lo oyen TODOS los jugadores
    }

    /** Toque del coche al balón: cuenta tiros y salvadas (preV/postV = velocidad del balón antes/después). */
    public static void onBallTouch(VehicleEntity car, Vec3 preV, Vec3 postV) {
        if ((state != State.PLAYING && state != State.OVERTIME) || arena == null || ball == null) return;
        if (!(car.getFirstPassenger() instanceof ServerPlayer p)) return;
        Stats st = stat(p);
        long now = level.getGameTime();
        if (!p.getUUID().equals(lastTouchId)) {                              // cambio de jugador que toca: guarda el anterior (asistencias)
            prevTouchId = lastTouchId; prevTouchTick = lastTouchTick;
            lastTouchId = p.getUUID();
        }
        lastTouchTick = now;
        double own = car.getArenaTeamId() == 0 ? -1 : 1;                     // sentido Z de su propia portería
        Vec3 b = ball.getCenter(), c = arena.center();
        double distOwnGoal = Math.abs(c.z + own * arena.halfL() - b.z);

        if (preV.z * own > speed(7) && postV.z * own < speed(2)
                && distOwnGoal < arena.halfL() * 0.9
                && Math.abs(b.x - c.x) < arena.goalHalfW() * 3.5
                && now - st.lastSave > 40) {                                              // SALVADA (ventana amplia)
            st.saves++; st.lastSave = now;
            title(p, Component.literal("SAVE").withStyle(s -> s.withColor(0xFF8C1E).withBold(true)), Component.empty(), 0, 25, 8);
            playToAll(sound("entity.villager.yes"), SoundSource.PLAYERS, 1.6f, 1.0f);       // salvada: "yes" de aldeano para todos
        } else if (-postV.z * own > speed(17) && Math.abs(b.x - c.x) < arena.goalHalfW() * 2.5
                && now - st.lastShot > 30) {                                              // TIRO a puerta contraria
            st.shots++; st.lastShot = now;
        }
    }

    /** Demolición: título "DEMOLITION" solo para quien la causa + sonido explosivo. */
    public static void onDemolition(VehicleEntity attacker, VehicleEntity victim) {
        if (attacker == null || !(attacker.getFirstPassenger() instanceof ServerPlayer p)) return;
        stat(p).demos++;
        title(p, Component.literal("DEMOLITION").withStyle(s -> s.withColor(0xFF5A1E).withBold(true)), Component.empty(), 0, 25, 8);
        SoundEvent boom = sound("entity.generic.explode");                    // demolición: solo en el área cercana al evento
        if (boom != null) level.playSound(null, victim.getX(), victim.getY(), victim.getZ(), boom, SoundSource.PLAYERS, 3.0f, 0.8f);
    }

    private static void broadcast(MinecraftServer server, String msg, boolean overlay) {
        server.getPlayerList().broadcastSystemMessage(Component.literal(msg), overlay);
    }
}
