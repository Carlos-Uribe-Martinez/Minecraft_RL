package dev.nucleoarena.arena;

import dev.nucleoarena.NucleoArena;
import dev.nucleoarena.entity.BoostPadEntity;
import dev.nucleoarena.entity.CustomBallEntity;
import dev.nucleoarena.entity.VehicleEntity;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.phys.Vec3;

import java.util.*;

import static dev.nucleoarena.physics.PhysicsConstants.*;

/**
 * Reglas de partido (un único partido global, en memoria):
 *   IDLE → COUNTDOWN (3 s, todo congelado) → PLAYING (5 min) → GOAL (celebración 3 s) → COUNTDOWN …
 *   Si el tiempo acaba empatado: OVERTIME (gol de oro). Al terminar: ENDED y limpieza a los 10 s.
 */
public final class MatchManager {
    private MatchManager() {}

    public enum State { IDLE, COUNTDOWN, PLAYING, GOAL, OVERTIME, ENDED }

    private static final int MATCH_TICKS = 5 * 60 * 20;
    private static final int COUNTDOWN_TICKS = 3 * 20;
    private static final int GOAL_TICKS = 3 * 20;
    private static final int END_TICKS = 10 * 20;
    private static final String[] TEAM_NAME = { "AZUL", "NARANJA" };

    private static ServerLevel level;
    private static ArenaConfig arena;
    private static State state = State.IDLE;
    private static int timer, clock;
    private static final int[] score = new int[2];
    private static CustomBallEntity ball;
    private static final Map<UUID, Integer> teams = new HashMap<>();
    private static final Map<UUID, VehicleEntity.Kind> kinds = new HashMap<>();

    // Pads de Rocket League (uu → m); 6 grandes + 28 pequeños, simétricos
    private static final double[][] LARGE = { {-3072,-4096},{3072,-4096},{-3584,0},{3584,0},{-3072,4096},{3072,4096} };
    private static final double[][] SMALL = {
        {0,-4240},{-1792,-4184},{1792,-4184},{-940,-3308},{940,-3308},{0,-2816},{-3584,-2484},{3584,-2484},
        {-1788,-2300},{1788,-2300},{-2048,-1036},{0,-1024},{2048,-1036},{-1024,0},{1024,0},{-2048,1036},
        {0,1024},{2048,1036},{-1788,2300},{1788,2300},{-3584,2484},{3584,2484},{0,2816},{-940,3308},
        {940,3308},{-1792,4184},{1792,4184},{0,4240} };

    // ───────────────────────── Configuración ─────────────────────────

    public static void buildArena(ServerLevel lvl, Vec3 center, boolean small) {
        level = lvl;
        arena = small ? ArenaConfig.small(center) : ArenaConfig.full(center);
        ArenaBuilder.build(lvl, arena);
        ArenaBuilder.registerSpawns(lvl, arena);
    }

    public static boolean hasArena() { return arena != null; }
    public static ArenaConfig arena() { return arena; }
    public static ServerLevel level() { return level; }
    public static void join(ServerPlayer p, int team) { teams.put(p.getUUID(), team); }
    public static void setKind(ServerPlayer p, VehicleEntity.Kind k) { kinds.put(p.getUUID(), k); }
    public static int teamOf(ServerPlayer p) { return teams.getOrDefault(p.getUUID(), 0); }
    public static VehicleEntity.Kind kindOf(ServerPlayer p) { return kinds.getOrDefault(p.getUUID(), VehicleEntity.Kind.NOMAD); }
    public static State state() { return state; }

    // ───────────────────────── Ciclo de vida ─────────────────────────

    /** @return mensaje de error, o null si arrancó. */
    public static String start(MinecraftServer server) {
        if (arena == null || level == null) return "Primero construye la cancha: /nucleo arena build";
        List<ServerPlayer> players = new ArrayList<>();
        for (ServerPlayer p : server.getPlayerList().getPlayers()) if (teams.containsKey(p.getUUID())) players.add(p);
        if (players.isEmpty()) return "Nadie se ha unido: /nucleo join blue|orange";

        cleanEntities();
        score[0] = score[1] = 0;
        clock = MATCH_TICKS;

        Vec3 c = arena.center();
        double s = arena.scale();
        for (double[] p : LARGE) spawnPad(c.x + p[0] / 100.0 * s, c.z + p[1] / 100.0 * s, true);
        for (double[] p : SMALL) spawnPad(c.x + p[0] / 100.0 * s, c.z + p[1] / 100.0 * s, false);

        ball = NucleoArena.BALL.create(level, EntitySpawnReason.COMMAND);
        ball.setTrail(0);
        ball.setPos(c.x, c.y, c.z);
        level.addFreshEntity(ball);

        int[] slot = new int[2];
        for (ServerPlayer p : players) {
            int team = teamOf(p);
            VehicleEntity car = NucleoArena.VEHICLE.create(level, EntitySpawnReason.COMMAND);
            car.setTeam(team);
            car.setKind(kindOf(p));
            car.setPos(c.x, c.y, c.z);                 // dentro de chunks cargados antes de añadirlo
            level.addFreshEntity(car);
            p.startRiding(car);
            carSlots.put(car, slot[team]++);
        }
        beginKickoff();
        return null;
    }

    private static final Map<VehicleEntity, Integer> carSlots = new HashMap<>();

    public static void stop() {
        cleanEntities();
        carSlots.clear();
        ball = null;
        state = State.IDLE;
    }

    private static void cleanEntities() {
        if (level == null || arena == null) return;
        for (Entity e : level.getEntitiesOfClass(Entity.class, arena.bounds(),
                x -> x instanceof VehicleEntity || x instanceof CustomBallEntity || x instanceof BoostPadEntity)) e.discard();
        carSlots.clear();
    }

    private static void spawnPad(double x, double z, boolean large) {
        BoostPadEntity pad = NucleoArena.BOOST_PAD.create(level, EntitySpawnReason.COMMAND);
        pad.setPos(x, arena.center().y + 0.05, z);
        pad.setLarge(large);
        level.addFreshEntity(pad);
    }

    private static void beginKickoff() {
        state = State.COUNTDOWN;
        timer = COUNTDOWN_TICKS;
        for (Map.Entry<VehicleEntity, Integer> e : new ArrayList<>(carSlots.entrySet())) {
            VehicleEntity car = e.getKey();
            if (car.isRemoved()) continue;
            List<ArenaSpawnRegistry.SpawnPoint> pts = ArenaSpawnRegistry.forTeam(level, car.getTeam());
            ArenaSpawnRegistry.SpawnPoint sp = pts.get(Math.min(e.getValue(), pts.size() - 1));
            car.placeAt(sp.pos(), sp.yawDeg(), BOOST_START);
            car.setFrozen(true);
        }
        Vec3 c = arena.center();
        ball.placeCenterAt(new Vec3(c.x, c.y + BALL_CENTER_Y_REST, c.z));
        ball.setFrozen(true);
    }

    private static void release() {
        for (VehicleEntity car : carSlots.keySet()) car.setFrozen(false);
        ball.setFrozen(false);
    }

    // ───────────────────────── Tick ─────────────────────────

    public static void tick(MinecraftServer server) {
        if (state == State.IDLE || level == null || ball == null) return;

        switch (state) {
            case COUNTDOWN -> {
                if (timer % 20 == 0) broadcast(server, timer == 0 ? "¡YA!" : String.valueOf(timer / 20), true);
                if (--timer < 0) { release(); state = State.PLAYING; }
            }
            case PLAYING, OVERTIME -> {
                if (state == State.PLAYING && --clock <= 0) {
                    if (score[0] == score[1]) { state = State.OVERTIME; broadcast(server, "¡TIEMPO EXTRA! Gol de oro", false); }
                    else { finish(server); return; }
                }
                int scorer = goalScorer();
                if (scorer >= 0) onGoal(server, scorer);
            }
            case GOAL -> {
                if (--timer <= 0) {
                    if (clock <= 0 && score[0] != score[1]) finish(server); else beginKickoff();
                }
            }
            case ENDED -> { if (--timer <= 0) stop(); }
            default -> {}
        }
        if (server.getTickCount() % 10 == 0) hud(server);
    }

    private static int goalScorer() {
        Vec3 b = ball.getCenter(), c = arena.center();
        double dz = b.z - c.z;
        if (Math.abs(dz) > arena.halfL() + BALL_RADIUS
                && Math.abs(b.x - c.x) < arena.goalHalfW()
                && b.y < c.y + arena.goalHeight()) {
            return ArenaConfig.scorerForEnd(dz < 0 ? -1 : 1);
        }
        return -1;
    }

    private static void onGoal(MinecraftServer server, int scorer) {
        score[scorer]++;
        broadcast(server, "¡GOL de " + TEAM_NAME[scorer] + "!  AZUL " + score[0] + " - " + score[1] + " NARANJA", false);
        boolean golden = state == State.OVERTIME;
        state = State.GOAL;
        timer = GOAL_TICKS;
        if (golden) clock = 0;                      // fuerza el final tras la celebración
    }

    private static void finish(MinecraftServer server) {
        state = State.ENDED;
        timer = END_TICKS;
        String w = score[0] > score[1] ? TEAM_NAME[0] : TEAM_NAME[1];
        broadcast(server, "FIN: " + w + " gana " + score[0] + " - " + score[1], false);
    }

    private static void hud(MinecraftServer server) {
        int secs = Math.max(0, clock / 20);
        String time = state == State.OVERTIME ? "EXTRA" : (secs / 60) + ":" + String.format("%02d", secs % 60);
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            if (!teams.containsKey(p.getUUID())) continue;
            String boost = p.getVehicle() instanceof VehicleEntity c ? "  |  Boost " + Math.round(c.getBoost()) : "";
            p.sendSystemMessage(Component.literal("AZUL " + score[0] + " - " + score[1] + " NARANJA  |  " + time + boost), true);
        }
    }

    private static void broadcast(MinecraftServer server, String msg, boolean overlay) {
        server.getPlayerList().broadcastSystemMessage(Component.literal(msg), overlay);
    }
}
