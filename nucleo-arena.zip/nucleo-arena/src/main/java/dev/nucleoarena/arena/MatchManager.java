package dev.nucleoarena.arena;

import dev.nucleoarena.NucleoArena;
import dev.nucleoarena.entity.BoostPadEntity;
import dev.nucleoarena.entity.CustomBallEntity;
import dev.nucleoarena.entity.VehicleEntity;
import dev.nucleoarena.net.StatsPayload;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.phys.Vec3;

import java.util.*;

import static dev.nucleoarena.physics.PhysicsConstants.*;

/**
 * Reglas de partido (un único partido global, en memoria):
 *   IDLE → COUNTDOWN (3 s, todo congelado) → PLAYING (5 min) → GOAL (celebración 3 s) → COUNTDOWN …
 *   Si el tiempo acaba empatado: OVERTIME (gol de oro). Al terminar: ENDED y limpieza a los 10 s.
 */
public final class MatchManager {
    private MatchManager() {}

    public enum State { IDLE, COUNTDOWN, PLAYING, GOAL, OVERTIME, ENDED }

    private static final int MATCH_TICKS = 5 * 60 * 20;
    private static final int COUNTDOWN_TICKS = 3 * 20;
    private static final int GOAL_TICKS = 3 * 20;
    private static final int END_TICKS = 10 * 20;
    private static final String[] TEAM_NAME = { "AZUL", "NARANJA" };
    private static final int[] TEAM_RGB = { 0x3C8CFF, 0xFF8C1E };

    /** Estadísticas por jugador (una entrada por jugador). */
    public static final class Stats {
        public String name = ""; public int team, goals, shots, saves, demos;
        long lastShot, lastSave;
    }
    private static final Map<UUID, Stats> stats = new LinkedHashMap<>();

    private static ServerLevel level;
    private static ArenaConfig arena;
    private static State state = State.IDLE;
    private static int timer, clock, overtimeTicks;
    private static final int[] score = new int[2];
    private static CustomBallEntity ball;
    private static final Map<UUID, Integer> teams = new HashMap<>();
    private static final Map<UUID, VehicleEntity.Kind> kinds = new HashMap<>();

    // Pads de Rocket League (uu → m); 6 grandes + 28 pequeños, simétricos
    private static final double[][] LARGE = { {-3072,-4096},{3072,-4096},{-3584,0},{3584,0},{-3072,4096},{3072,4096} };
    private static final double[][] SMALL = {
        {0,-4240},{-1792,-4184},{1792,-4184},{-940,-3308},{940,-3308},{0,-2816},{-3584,-2484},{3584,-2484},
        {-1788,-2300},{1788,-2300},{-2048,-1036},{0,-1024},{2048,-1036},{-1024,0},{1024,0},{-2048,1036},
        {0,1024},{2048,1036},{-1788,2300},{1788,2300},{-3584,2484},{3584,2484},{0,2816},{-940,3308},
        {940,3308},{-1792,4184},{1792,4184},{0,4240} };

    // ───────────────────────── Configuración ─────────────────────────

    public static void buildArena(ServerLevel lvl, Vec3 center, boolean small) {
        level = lvl;
        arena = small ? ArenaConfig.small(center) : ArenaConfig.full(center);
        ArenaBuilder.build(lvl, arena);
        ArenaBuilder.registerSpawns(lvl, arena);
    }

    public static boolean hasArena() { return arena != null; }
    public static ArenaConfig arena() { return arena; }
    public static ServerLevel level() { return level; }
    public static void join(ServerPlayer p, int team) { teams.put(p.getUUID(), team); }
    public static void setKind(ServerPlayer p, VehicleEntity.Kind k) { kinds.put(p.getUUID(), k); }
    public static int teamOf(ServerPlayer p) { return teams.getOrDefault(p.getUUID(), 0); }
    public static VehicleEntity.Kind kindOf(ServerPlayer p) { return kinds.getOrDefault(p.getUUID(), VehicleEntity.Kind.NOMAD); }
    public static State state() { return state; }
    public static CustomBallEntity matchBall() { return ball; }

    // ───────────────────────── Ciclo de vida ─────────────────────────

    /** @return mensaje de error, o null si arrancó. */
    public static String start(MinecraftServer server) {
        if (arena == null || level == null) return "Primero construye la cancha: /nucleo arena build";
        List<ServerPlayer> players = new ArrayList<>();
        for (ServerPlayer p : server.getPlayerList().getPlayers()) if (teams.containsKey(p.getUUID())) players.add(p);
        if (players.isEmpty()) return "Nadie se ha unido: /nucleo join blue|orange";

        cleanEntities();
        score[0] = score[1] = 0;
        clock = MATCH_TICKS;
        overtimeTicks = 0;
        stats.clear();
        for (ServerPlayer sp : players) { Stats st = stat(sp); st.team = teamOf(sp); }

        Vec3 c = arena.center();
        double s = arena.scale();
        for (double[] p : LARGE) spawnPad(c.x + p[0] / 100.0 * s, c.z + p[1] / 100.0 * s, true);
        for (double[] p : SMALL) spawnPad(c.x + p[0] / 100.0 * s, c.z + p[1] / 100.0 * s, false);

        ball = NucleoArena.BALL.create(level, EntitySpawnReason.COMMAND);
        ball.setTrail(0);
        ball.setPos(c.x, c.y, c.z);
        level.addFreshEntity(ball);

        int[] slot = new int[2];
        for (ServerPlayer p : players) {
            int team = teamOf(p);
            VehicleEntity car = NucleoArena.VEHICLE.create(level, EntitySpawnReason.COMMAND);
            car.setTeam(team);
            car.setKind(kindOf(p));
            car.setPos(c.x, c.y, c.z);                 // dentro de chunks cargados antes de añadirlo
            level.addFreshEntity(car);
            p.startRiding(car);
            carSlots.put(car, slot[team]++);
        }
        beginKickoff();
        return null;
    }

    private static final Map<VehicleEntity, Integer> carSlots = new HashMap<>();

    public static void stop() {
        cleanEntities();
        carSlots.clear();
        ball = null;
        state = State.IDLE;
    }

    private static void cleanEntities() {
        if (level == null || arena == null) return;
        for (Entity e : level.getEntitiesOfClass(Entity.class, arena.bounds(),
                x -> x instanceof VehicleEntity || x instanceof CustomBallEntity || x instanceof BoostPadEntity)) e.discard();
        carSlots.clear();
    }

    private static void spawnPad(double x, double z, boolean large) {
        BoostPadEntity pad = NucleoArena.BOOST_PAD.create(level, EntitySpawnReason.COMMAND);
        pad.setPos(x, arena.center().y + 0.05, z);
        pad.setLarge(large);
        level.addFreshEntity(pad);
    }

    private static void beginKickoff() {
        state = State.COUNTDOWN;
        timer = COUNTDOWN_TICKS;
        for (Map.Entry<VehicleEntity, Integer> e : new ArrayList<>(carSlots.entrySet())) {
            VehicleEntity car = e.getKey();
            if (car.isRemoved()) continue;
            List<ArenaSpawnRegistry.SpawnPoint> pts = ArenaSpawnRegistry.forTeam(level, car.getArenaTeamId());
            ArenaSpawnRegistry.SpawnPoint sp = pts.get(Math.min(e.getValue(), pts.size() - 1));
            car.placeAt(sp.pos(), sp.yawDeg(), BOOST_START);
            car.setFrozen(true);
        }
        Vec3 c = arena.center();
        ball.placeCenterAt(new Vec3(c.x, c.y + BALL_CENTER_Y_REST, c.z));
        ball.setFrozen(true);
    }

    private static void release() {
        for (VehicleEntity car : carSlots.keySet()) car.setFrozen(false);
        ball.setFrozen(false);
    }

    // ───────────────────────── Tick ─────────────────────────

    public static void tick(MinecraftServer server) {
        if (state == State.IDLE || level == null || ball == null) return;

        switch (state) {
            case COUNTDOWN -> {
                if (timer % 20 == 0) {
                    Component t = timer == 0
                            ? Component.literal("¡YA!").withStyle(s -> s.withColor(0x55FF55).withBold(true))
                            : Component.literal(String.valueOf(timer / 20)).withStyle(s -> s.withColor(0xFFFFFF).withBold(true));
                    titleAll(server, t, Component.empty(), 0, 18, 4);
                }
                if (--timer < 0) { release(); state = State.PLAYING; }
            }
            case PLAYING, OVERTIME -> {
                if (state == State.PLAYING && --clock <= 0) {
                    if (score[0] == score[1]) {
                        state = State.OVERTIME; overtimeTicks = 0;
                        titleAll(server, Component.literal("TIEMPO EXTRA").withStyle(s -> s.withColor(0xFFD84A).withBold(true)),
                                Component.literal("Gol de oro · máx. 15 min"), 5, 50, 15);
                    } else { finish(server); return; }
                }
                if (state == State.OVERTIME && ++overtimeTicks >= OVERTIME_MAX_TICKS) { finish(server); return; }
                int scorer = goalScorer();
                if (scorer >= 0) onGoal(server, scorer);
            }
            case GOAL -> {
                if (--timer <= 0) {
                    if (clock <= 0 && score[0] != score[1]) finish(server); else beginKickoff();
                }
            }
            case ENDED -> { if (--timer <= 0) stop(); }
            default -> {}
        }
        if (server.getTickCount() % 10 == 0) hud(server);
        if (server.getTickCount() % 20 == 0) sendStats(server);
    }

    private static int goalScorer() {
        Vec3 b = ball.getCenter(), c = arena.center();
        double dz = b.z - c.z;
        if (Math.abs(dz) > arena.halfL() + BALL_RADIUS
                && Math.abs(b.x - c.x) < arena.goalHalfW()
                && b.y < c.y + arena.goalHeight()) {
            return ArenaConfig.scorerForEnd(dz < 0 ? -1 : 1);
        }
        return -1;
    }

    private static void onGoal(MinecraftServer server, int scorer) {
        score[scorer]++;
        Stats st = ball.getLastToucherId() != null ? stats.get(ball.getLastToucherId()) : null;
        boolean credited = st != null && st.team == scorer;
        if (credited) st.goals++;
        String who = credited ? st.name : TEAM_NAME[scorer];
        Component title = Component.literal(who).withStyle(s -> s.withColor(TEAM_RGB[scorer]).withBold(true))
                .append(Component.literal(" anotó").withStyle(s -> s.withColor(0xFFFFFF).withBold(true)));
        Component sub = Component.literal("AZUL " + score[0] + " - " + score[1] + " NARANJA");
        titleAll(server, title, sub, 3, 50, 15);
        goalEffects(scorer);
        boolean golden = state == State.OVERTIME;
        state = State.GOAL;
        timer = GOAL_TICKS;
        if (golden) clock = 0;                      // fuerza el final tras la celebración
    }

    private static void finish(MinecraftServer server) {
        state = State.ENDED;
        timer = END_TICKS;
        if (score[0] == score[1]) {
            titleAll(server, Component.literal("EMPATE").withStyle(s -> s.withColor(0xFFFFFF).withBold(true)),
                    Component.literal("AZUL " + score[0] + " - " + score[1] + " NARANJA"), 5, 80, 20);
        } else {
            int w = score[0] > score[1] ? 0 : 1;
            titleAll(server, Component.literal(TEAM_NAME[w] + " GANA").withStyle(s -> s.withColor(TEAM_RGB[w]).withBold(true)),
                    Component.literal("AZUL " + score[0] + " - " + score[1] + " NARANJA"), 5, 80, 20);
        }
    }

    private static void hud(MinecraftServer server) {
        int secs = state == State.OVERTIME ? overtimeTicks / 20 : Math.max(0, clock / 20);
        String time = (state == State.OVERTIME ? "EXTRA +" : "") + (secs / 60) + ":" + String.format("%02d", secs % 60);
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            if (!teams.containsKey(p.getUUID())) continue;
            String boost = p.getVehicle() instanceof VehicleEntity c ? "  |  Boost " + Math.round(c.getBoost()) : "";
            p.sendSystemMessage(Component.literal("AZUL " + score[0] + " - " + score[1] + " NARANJA  |  " + time + boost), true);
        }
    }

    // ───────────────────────── Estadísticas, títulos y efectos ─────────────────────────

    private static Stats stat(ServerPlayer p) {
        Stats s = stats.computeIfAbsent(p.getUUID(), k -> new Stats());
        s.name = p.getName().getString();
        s.team = teamOf(p);
        return s;
    }

    private static void title(ServerPlayer p, Component title, Component sub, int in, int stay, int out) {
        p.connection.send(new ClientboundSetTitlesAnimationPacket(in, stay, out));
        p.connection.send(new ClientboundSetSubtitleTextPacket(sub));
        p.connection.send(new ClientboundSetTitleTextPacket(title));
    }

    private static void titleAll(MinecraftServer server, Component t, Component sub, int in, int stay, int out) {
        for (ServerPlayer p : server.getPlayerList().getPlayers()) title(p, t, sub, in, stay, out);
    }

    private static SoundEvent sound(String id) {
        return BuiltInRegistries.SOUND_EVENT.getValue(Identifier.withDefaultNamespace(id));
    }

    private static void sendStats(MinecraftServer server) {
        if (arena == null) return;
        List<StatsPayload.Row> rows = new ArrayList<>();
        for (Stats s : stats.values()) rows.add(new StatsPayload.Row(s.name, s.team, s.goals, s.shots, s.saves, s.demos));
        rows.sort(Comparator.comparingInt((StatsPayload.Row r) -> r.team()).thenComparing(r -> -r.goals()));
        int secs = state == State.OVERTIME ? overtimeTicks / 20 : Math.max(0, clock / 20);
        StatsPayload payload = new StatsPayload(score[0], score[1], secs, state == State.OVERTIME, rows);
        for (ServerPlayer p : server.getPlayerList().getPlayers()) ServerPlayNetworking.send(p, payload);
    }

    /** Partículas del color del equipo que anota + cuerno de cabra (trompeta de estadio). */
    private static void goalEffects(int scorer) {
        Vec3 c = arena.center();
        double dir = scorer == 0 ? 1 : -1;                                   // el azul anota en la portería +Z
        double gz = c.z + dir * (arena.halfL() + arena.goalDepth() * 0.5);
        double gy = c.y + arena.goalHeight() * 0.5;
        DustParticleOptions dust = new DustParticleOptions(TEAM_RGB[scorer], 2.2f);
        level.sendParticles(dust, c.x, gy, gz, 400, arena.goalHalfW() * 0.8, arena.goalHeight() * 0.45, arena.goalDepth() * 0.4, 0.02);
        level.sendParticles(ParticleTypes.FIREWORK, c.x, gy, gz, 120, arena.goalHalfW() * 0.6, arena.goalHeight() * 0.4, arena.goalDepth() * 0.3, 0.25);
        SoundEvent horn = sound("item.goat_horn.sound.0");
        if (horn != null) {
            level.playSound(null, c.x, gy, c.z, horn, SoundSource.RECORDS, 8.0f, 1.0f);
            level.playSound(null, c.x, gy, gz, horn, SoundSource.RECORDS, 8.0f, 0.8f);
        }
    }

    /** Toque del coche al balón: cuenta tiros y salvadas (preV/postV = velocidad del balón antes/después). */
    public static void onBallTouch(VehicleEntity car, Vec3 preV, Vec3 postV) {
        if ((state != State.PLAYING && state != State.OVERTIME) || arena == null || ball == null) return;
        if (!(car.getFirstPassenger() instanceof ServerPlayer p)) return;
        Stats st = stat(p);
        long now = level.getGameTime();
        double own = car.getArenaTeamId() == 0 ? -1 : 1;                     // sentido Z de su propia portería
        Vec3 b = ball.getCenter(), c = arena.center();
        double distOwnGoal = Math.abs(c.z + own * arena.halfL() - b.z);

        if (preV.z * own > speed(13) && postV.z * own < speed(3)
                && distOwnGoal < arena.halfL() * 0.6 && now - st.lastSave > 40) {         // SALVADA
            st.saves++; st.lastSave = now;
            title(p, Component.literal("SAVE").withStyle(s -> s.withColor(0xFF8C1E).withBold(true)), Component.empty(), 0, 25, 8);
            SoundEvent ok = sound("entity.player.levelup");
            if (ok != null) level.playSound(null, p.getX(), p.getY(), p.getZ(), ok, SoundSource.PLAYERS, 1.0f, 1.2f);
        } else if (-postV.z * own > speed(17) && Math.abs(b.x - c.x) < arena.goalHalfW() * 2.5
                && now - st.lastShot > 30) {                                              // TIRO a puerta contraria
            st.shots++; st.lastShot = now;
        }
    }

    /** Demolición: título "DEMOLITION" solo para quien la causa + sonido explosivo. */
    public static void onDemolition(VehicleEntity attacker, VehicleEntity victim) {
        if (attacker == null || !(attacker.getFirstPassenger() instanceof ServerPlayer p)) return;
        stat(p).demos++;
        title(p, Component.literal("DEMOLITION").withStyle(s -> s.withColor(0xFF5A1E).withBold(true)), Component.empty(), 0, 25, 8);
        SoundEvent boom = sound("entity.generic.explode");
        if (boom != null) level.playSound(null, p.getX(), p.getY(), p.getZ(), boom, SoundSource.PLAYERS, 1.0f, 0.7f);
    }

    private static void broadcast(MinecraftServer server, String msg, boolean overlay) {
        server.getPlayerList().broadcastSystemMessage(Component.literal(msg), overlay);
    }
}
