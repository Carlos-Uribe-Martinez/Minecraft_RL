package dev.nucleoarena.entity;

import dev.nucleoarena.Football;
import dev.nucleoarena.arena.ArenaSpawnRegistry;
import dev.nucleoarena.arena.MatchManager;
import dev.nucleoarena.input.VehicleInput;
import dev.nucleoarena.net.CarSnapshotPayload;
import dev.nucleoarena.physics.PhysicsConstants;
import dev.nucleoarena.physics.CarPhysics;
import dev.nucleoarena.physics.CarPredictor;
import dev.nucleoarena.physics.CarState;
import dev.nucleoarena.physics.VecUtil;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import net.minecraft.world.phys.Vec3;
import org.joml.Quaternionf;
import org.joml.Quaternionfc;

import java.util.ArrayDeque;
import java.util.List;

import static dev.nucleoarena.physics.PhysicsConstants.*;

/**
 * Vehículo de arena (Nomad / Caribe).
 *
 * La física vive en {@link CarPhysics} sobre un {@link CarState}. Esta clase es el "envoltorio":
 *  - SERVIDOR: autoritativo. Consume UNA entrada por tick de {@link #inputQueue}, simula, aplica el
 *    resultado a la entidad y envía un {@link CarSnapshotPayload} al conductor.
 *  - CLIENTE (conductor local): predice con el mismo CarPhysics ({@link CarPredictor}) y se reconcilia.
 *  - CLIENTE (resto): interpola posición vanilla + orientación sincronizada.
 */
public class VehicleEntity extends Entity {

    public enum Kind {
        // OBB = dimensiones EXACTAS de la malla (ancho, alto, largo sin escalar); se escalan con CAR_SCALE
        NOMAD(1.00f,  0.93f, 0.60f, 2.00f),    // Blue Lowpoly Car
        CARIBE(1.12f, 0.94f, 0.73f, 1.90f);    // Fiat Uno: gira algo más ágil
        public final float steerMult, halfX, halfY, halfZ, centerY;
        Kind(float steerMult, float width, float height, float length) {
            this.steerMult = steerMult;
            this.halfX = width * PhysicsConstants.CAR_SCALE / 2f;
            this.halfY = height * PhysicsConstants.CAR_SCALE / 2f;
            this.halfZ = length * PhysicsConstants.CAR_SCALE / 2f;
            this.centerY = -PhysicsConstants.BOX_SIZE / 2f + this.halfY;      // la malla apoya sobre la base de la caja
        }
    }

    // ───────────── Datos sincronizados (para el render de TODOS los clientes) ─────────────
    private static final EntityDataAccessor<Quaternionfc> DATA_ORIENTATION = SynchedEntityData.defineId(VehicleEntity.class, EntityDataSerializers.QUATERNION);
    private static final EntityDataAccessor<Float>   DATA_BOOST      = SynchedEntityData.defineId(VehicleEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Integer> DATA_TEAM       = SynchedEntityData.defineId(VehicleEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_KIND       = SynchedEntityData.defineId(VehicleEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> DATA_DEMOLISHED = SynchedEntityData.defineId(VehicleEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> DATA_SUPERSONIC = SynchedEntityData.defineId(VehicleEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> DATA_BOOSTING   = SynchedEntityData.defineId(VehicleEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> DATA_FLIP_READY = SynchedEntityData.defineId(VehicleEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Integer> DATA_TELEPORT = SynchedEntityData.defineId(VehicleEntity.class, EntityDataSerializers.INT);
    private int seenTeleport;
    private static final EntityDataAccessor<Boolean> DATA_FROZEN     = SynchedEntityData.defineId(VehicleEntity.class, EntityDataSerializers.BOOLEAN);

    // ───────────── Servidor ─────────────
    private final CarState state = new CarState();
    private boolean stateInitialized;
    private final ArrayDeque<VehicleInput> inputQueue = new ArrayDeque<>();
    private VehicleInput lastInput = VehicleInput.NONE;
    private int lastEnqueuedSeq = -1;
    private int lastProcessedSeq = -1;
    private int respawnTicks;

    // ───────────── Cliente ─────────────
    private CarPredictor predictor;
    private final Quaternionf renderOrientation = new Quaternionf();
    private final Quaternionf prevRenderOrientation = new Quaternionf();

    public VehicleEntity(EntityType<? extends VehicleEntity> type, Level level) {
        super(type, level);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder b) {
        b.define(DATA_ORIENTATION, new Quaternionf());
        b.define(DATA_BOOST, BOOST_START);
        b.define(DATA_TEAM, 0);
        b.define(DATA_KIND, 0);
        b.define(DATA_DEMOLISHED, false);
        b.define(DATA_SUPERSONIC, false);
        b.define(DATA_BOOSTING, false);
        b.define(DATA_FLIP_READY, false);
        b.define(DATA_FROZEN, false);
        b.define(DATA_TELEPORT, 0);
    }

    // ═════════════════════════════ TICK ═════════════════════════════

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide()) clientTick();
        else serverTick();
    }

    private void serverTick() {
        if (!stateInitialized) {                         // entidad cargada de disco o creada sin placeAt()
            state.reset(position().add(0, BOX_SIZE / 2.0, 0), (float) Math.toRadians(-getYRot()), BOOST_START);
            stateInitialized = true;
        }
        if (respawnTicks > 0) { tickRespawn(); return; }
        MatchManager.rescueIfEscaped(this);

        VehicleInput in = nextInput();
        if (isFrozen()) {
            state.vel = Vec3.ZERO;
            state.boosting = false;
        } else {
            CarPhysics.step(level(), state, in, getKind().steerMult);
        }

        applyStateToEntity();
        checkCarCollisions();
        hurtMobs();
        pushFootballs();
        syncState();
        sendSnapshot();
    }

    /** Una entrada por tick. Sin paquetes nuevos se repite la última (sin el flanco de salto). */
    private VehicleInput nextInput() {
        if (getFirstPassenger() == null) {
            inputQueue.clear();
            lastInput = VehicleInput.NONE;
            return VehicleInput.NONE;
        }
        VehicleInput polled = inputQueue.pollFirst();
        if (polled != null) {
            lastInput = polled;
            lastProcessedSeq = polled.seq();
            return polled;
        }
        lastInput = lastInput.withoutPress();
        return lastInput;
    }

    private void applyStateToEntity() {
        Vec3 c = state.center;
        setPos(c.x, c.y - BOX_SIZE / 2.0, c.z);
        setDeltaMovement(state.vel);
    }

    private void sendSnapshot() {
        if (getFirstPassenger() instanceof ServerPlayer driver) {
            ServerPlayNetworking.send(driver, new CarSnapshotPayload(getId(), lastProcessedSeq, state.copy()));
        }
    }

    // ═════════════════════ API DE RED / ENTRADA (servidor) ═════════════════════

    public void enqueueInput(VehicleInput in) {
        if (isDemolished() || in.seq() <= lastEnqueuedSeq) return;      // duplicado / desordenado
        lastEnqueuedSeq = in.seq();
        while (inputQueue.size() >= INPUT_QUEUE_MAX) {                  // el cliente va adelantado: descarta el más viejo
            VehicleInput dropped = inputQueue.pollFirst();
            if (dropped.jumpPressed() && !inputQueue.isEmpty()) inputQueue.addFirst(inputQueue.pollFirst().withPress());
        }
        inputQueue.addLast(in);
    }

    // ═════════════════════ API DE RED / PREDICCIÓN (cliente) ═════════════════════

    public boolean isLocalDriver() {
        return level().isClientSide() && getFirstPassenger() instanceof Player p && p.isLocalPlayer();
    }

    /** Simula el tick local con la entrada del jugador. @return la entrada con seq asignado, lista para enviar. */
    public VehicleInput clientDrive(VehicleInput raw) {
        if (predictor == null) predictor = new CarPredictor();
        return predictor.step(level(), raw, getKind().steerMult, isFrozen());
    }

    public void onServerSnapshot(int ackSeq, CarState server) {
        if (predictor == null) predictor = new CarPredictor();
        predictor.onServerState(level(), ackSeq, server, getKind().steerMult, isFrozen());
    }

    private boolean usePrediction() { return predictor != null && predictor.isInitialized() && isLocalDriver(); }

    /** Centro de la caja interpolado (predicho para el conductor local; vanilla para el resto). */
    public Vec3 getRenderCenter(float pt) {
        if (usePrediction()) return predictor.renderCenter(pt);
        return getPosition(pt).add(0, BOX_SIZE / 2.0, 0);
    }

    /** Orientación interpolada para renderer / cámara. */
    public Quaternionf getRenderOrientation(float pt) {
        if (usePrediction()) return predictor.renderOrientation(pt);
        return new Quaternionf(prevRenderOrientation).slerp(renderOrientation, pt);
    }

    private void clientTick() {
        int tp = entityData.get(DATA_TELEPORT);
        if (tp != seenTeleport) {                       // el servidor nos recolocó (saque/reaparición): resincroniza la predicción
            seenTeleport = tp;
            if (predictor != null) predictor.reset();
        }
        prevRenderOrientation.set(renderOrientation);
        renderOrientation.slerp(entityData.get(DATA_ORIENTATION), 0.6f);

        if (isDemolished()) return;
        boolean boosting = usePrediction() ? predictor.current.boosting : entityData.get(DATA_BOOSTING);
        Vec3 c = getRenderCenter(1.0f).add(VecUtil.rotate(getRenderOrientation(1.0f), new Vec3(0, -0.2 * CAR_SCALE, -0.95 * CAR_SCALE)));
        if (boosting) {
            level().addParticle(ParticleTypes.FLAME, c.x, c.y, c.z, 0, 0, 0);
            level().addParticle(ParticleTypes.SOUL_FIRE_FLAME, c.x, c.y, c.z, 0, 0, 0);
        }
        if (isSupersonic()) level().addParticle(ParticleTypes.ELECTRIC_SPARK, c.x, c.y, c.z, 0, 0, 0);
    }

    // ═════════════════════════ POSICIONAMIENTO ═════════════════════════

    /** Coloca el coche con las 4 ruedas en el suelo: base = punto bajo el coche; yawDeg convención Minecraft. */
    public void placeAt(Vec3 base, float yawDeg, float boost) {
        state.reset(base.add(0, BOX_SIZE / 2.0, 0), (float) Math.toRadians(-yawDeg), boost);
        for (int guard = 0; guard < 16 && !level().noCollision(state.box()); guard++)    // nunca dentro de bloques
            state.center = state.center.add(0.0, 0.5, 0.0);
        entityData.set(DATA_TELEPORT, entityData.get(DATA_TELEPORT) + 1);
        stateInitialized = true;
        inputQueue.clear();
        lastInput = VehicleInput.NONE;
        applyStateToEntity();
        setYRot(yawDeg);
        entityData.set(DATA_ORIENTATION, new Quaternionf(state.orient));
        syncState();
    }

    // ═════════════════════ INTERACCIONES (balón, coches, pads) ═════════════════════

    /** Llamado por CustomBallEntity cuando el balón toca el centro inferior (4 ruedas). */
    public void grantFlipReset() {
        if (CarPhysics.grantFlipReset(state) && level() instanceof ServerLevel sl) {
            sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, getX(), getY() + 0.4, getZ(), 14, 0.4, 0.2, 0.4, 0.15);
        }
    }

    /** Cubos de azufre (pruebas de "balón"): el coche los empuja como a un balón, sin dañarlos. */
    private void pushFootballs() {
        if (!(level() instanceof ServerLevel sl)) return;
        for (LivingEntity c : sl.getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(0.3), Football::isSulfur)) {
            Vec3 d = c.getBoundingBox().getCenter().subtract(state.center);
            if (d.lengthSqr() < 1.0E-6) continue;
            Vec3 n = d.normalize();
            double closing = state.vel.subtract(c.getDeltaMovement()).dot(n);
            if (closing <= 0.02) continue;
            c.push(n.x * closing * 1.6, Math.max(0.0, n.y) * closing * 0.8 + 0.06, n.z * closing * 1.6);
        }
    }

    /** El coche daña a los mobs que atropella: daño proporcional a la velocidad (mata a gran velocidad). */
    private void hurtMobs() {
        double ms = state.vel.length() * TPS;
        if (ms < CAR_HURT_MIN_MS || !(level() instanceof ServerLevel sl)) return;
        Entity driver = getFirstPassenger();
        List<LivingEntity> targets = sl.getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(0.15),
                e -> e != driver && !(e instanceof Player) && e.isAlive() && !Football.isSulfur(e) && !(e.getVehicle() instanceof VehicleEntity));
        if (targets.isEmpty()) return;
        var source = driver instanceof Player p ? sl.damageSources().playerAttack(p) : sl.damageSources().generic();
        float dmg = (float) ((ms - CAR_HURT_MIN_MS) * CAR_HURT_PER_MS + 2.0);
        for (LivingEntity t : targets) {
            if (t.hurtServer(sl, source, dmg)) {
                Vec3 dir = state.vel.normalize();
                t.push(dir.x * 0.8, 0.35, dir.z * 0.8);
            }
        }
    }

    private void checkCarCollisions() {
        List<VehicleEntity> others = level().getEntitiesOfClass(VehicleEntity.class,
                getBoundingBox().inflate(0.05), o -> o != this && o.isActiveCar());
        for (VehicleEntity other : others) {
            if (getId() < other.getId()) resolvePair(this, other);       // cada pareja una sola vez
        }
    }

    private static void resolvePair(VehicleEntity a, VehicleEntity b) {
        Vec3 ab = b.state.center.subtract(a.state.center);
        if (ab.lengthSqr() < 1.0E-6) return;
        Vec3 n = ab.normalize();                                         // de A hacia B

        Vec3 va = a.state.vel, vb = b.state.vel;
        double aClosing = va.dot(n);
        double bClosing = -vb.dot(n);

        boolean aHits = va.length() >= SUPERSONIC && aClosing > 0
                && VecUtil.rotate(a.state.orient, VecUtil.FORWARD).dot(n) > DEMO_FRONT_DOT;
        boolean bHits = vb.length() >= SUPERSONIC && bClosing > 0
                && VecUtil.rotate(b.state.orient, VecUtil.FORWARD).dot(n.reverse()) > DEMO_FRONT_DOT;

        if (aHits && (!bHits || aClosing >= bClosing)) { b.demolish(a); return; }
        if (bHits)                                     { a.demolish(b); return; }

        double closing = aClosing + bClosing;
        if (closing > 0) {                                               // choque normal
            Vec3 j = n.scale(closing * 0.5 * 1.3);
            a.state.vel = va.subtract(j);
            b.state.vel = vb.add(j);
        }
        a.state.center = a.state.center.subtract(n.scale(0.05));
        b.state.center = b.state.center.add(n.scale(0.05));
        a.applyStateToEntity();
        b.applyStateToEntity();
    }

    public void demolish(VehicleEntity attacker) {
        if (!(level() instanceof ServerLevel sl) || respawnTicks > 0) return;

        sl.sendParticles(ParticleTypes.EXPLOSION_EMITTER, getX(), getY() + 0.8, getZ(), 1, 0, 0, 0, 0);
        sl.sendParticles(ParticleTypes.FLAME,        getX(), getY() + 0.8, getZ(), 120, 1.0, 0.8, 1.0, 0.30);
        sl.sendParticles(ParticleTypes.LARGE_SMOKE,  getX(), getY() + 0.8, getZ(), 60,  0.9, 0.7, 0.9, 0.10);
        sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, getX(), getY() + 0.8, getZ(), 80, 1.2, 1.0, 1.2, 0.40);
        // ⚠ GENERIC_EXPLODE es Holder<SoundEvent> en 1.21.5+: si falla la sobrecarga, usar un SoundEvent plano.
        sl.playSound(null, getX(), getY(), getZ(), SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 1.6f, 0.9f);

        MatchManager.onDemolition(attacker, this);
        respawnTicks = RESPAWN_TICKS;
        entityData.set(DATA_DEMOLISHED, true);
        entityData.set(DATA_SUPERSONIC, false);
        entityData.set(DATA_BOOSTING, false);
        state.vel = Vec3.ZERO;
        applyStateToEntity();
        inputQueue.clear();
    }

    private void tickRespawn() {
        // Durante la demolición se sigue acusando recibo de las entradas para no desincronizar al cliente.
        VehicleInput polled = inputQueue.pollFirst();
        if (polled != null) lastProcessedSeq = polled.seq();
        sendSnapshot();
        if (--respawnTicks > 0) return;

        ServerLevel sl = (ServerLevel) level();
        ArenaSpawnRegistry.SpawnPoint sp = ArenaSpawnRegistry.pick(sl, getArenaTeamId(), this);
        if (sp != null) placeAt(sp.pos(), sp.yawDeg(), BOOST_START);
        else            placeAt(position(), getYRot(), BOOST_START);
        entityData.set(DATA_DEMOLISHED, false);
    }

    // ═════════════════════════ SINCRONIZACIÓN ═════════════════════════

    private void syncState() {
        entityData.set(DATA_ORIENTATION, new Quaternionf(state.orient));
        entityData.set(DATA_BOOST, state.boost);
        entityData.set(DATA_BOOSTING, state.boosting);
        entityData.set(DATA_SUPERSONIC, state.vel.length() >= SUPERSONIC);
        entityData.set(DATA_FLIP_READY, state.canDoubleJump());
        Vec3 fwd = VecUtil.rotate(state.orient, VecUtil.FORWARD);
        setYRot((float) (Mth.atan2(-fwd.x, fwd.z) * Mth.RAD_TO_DEG));
    }

    // ═════════════════════════ API PÚBLICA ═════════════════════════

    /** Orientación local→mundo AUTORITATIVA (solo servidor; el balón la usa para colisionar). */
    public Quaternionf getOrientation() { return state.orient; }
    public Vec3 getVelocity() { return state.vel; }

    /** Centro de la OBB del coche (la AABB cúbica es mayor; el coche "se apoya" abajo). */
    public Vec3 obbCenter() { return state.center.add(VecUtil.rotate(state.orient, new Vec3(0, getKind().centerY, 0))); }

    public void addVelocity(Vec3 dv) { state.vel = state.vel.add(dv); setDeltaMovement(state.vel); }

    /** Estado que ve el cliente local: el predicho si conduce él, si no el último del servidor. */
    public CarState clientState() { return usePrediction() ? predictor.current : state; }

    public boolean isActiveCar()   { return !isRemoved() && !entityData.get(DATA_DEMOLISHED); }
    public boolean isDemolished()  { return entityData.get(DATA_DEMOLISHED); }
    public boolean isSupersonic()  { return entityData.get(DATA_SUPERSONIC); }
    public boolean isFlipReady()   { return entityData.get(DATA_FLIP_READY); }
    public boolean isFrozen()      { return entityData.get(DATA_FROZEN); }
    public void    setFrozen(boolean f) { entityData.set(DATA_FROZEN, f); }
    public boolean isBoosting()    { return entityData.get(DATA_BOOSTING); }
    public float   getBoost()      { return level().isClientSide() ? entityData.get(DATA_BOOST) : state.boost; }
    public void    setBoost(float b) { state.boost = Mth.clamp(b, 0f, BOOST_CAPACITY); entityData.set(DATA_BOOST, state.boost); }
    public void    addBoost(float b) { setBoost(getBoost() + b); }
    public int     getArenaTeamId() { return entityData.get(DATA_TEAM); }
    public void    setTeam(int t)  { entityData.set(DATA_TEAM, t); }
    public Kind    getKind()       { return Kind.values()[Mth.clamp(entityData.get(DATA_KIND), 0, Kind.values().length - 1)]; }
    public void    setKind(Kind k) { entityData.set(DATA_KIND, k.ordinal()); }

    // ═════════════════════════ BOILERPLATE ═════════════════════════

    @Override public InteractionResult interact(Player player, InteractionHand hand, Vec3 location) {
        if (!level().isClientSide() && getPassengers().isEmpty()) player.startRiding(this);
        return InteractionResult.SUCCESS;
    }
    @Override protected boolean canAddPassenger(Entity p) { return getPassengers().isEmpty(); }
    @Override protected void addPassenger(Entity p) {
        super.addPassenger(p);
        p.setInvisible(true);
        predictor = null;                                // nueva sesión de conducción: seq vuelve a 0
        inputQueue.clear();
        lastEnqueuedSeq = -1;
        lastProcessedSeq = -1;
    }
    @Override protected void removePassenger(Entity p) {
        super.removePassenger(p);
        p.setInvisible(false);
        predictor = null;
    }
    @Override public boolean isPickable() { return !isRemoved(); }
    @Override public boolean hurtServer(ServerLevel level, DamageSource source, float amount) { return false; }

    @Override protected void readAdditionalSaveData(ValueInput in) {
        setTeam(in.getInt("Team").orElse(0));
        entityData.set(DATA_KIND, in.getInt("Kind").orElse(0));
    }
    @Override protected void addAdditionalSaveData(ValueOutput out) {
        out.putInt("Team", getArenaTeamId());
        out.putInt("Kind", entityData.get(DATA_KIND));
    }
}
