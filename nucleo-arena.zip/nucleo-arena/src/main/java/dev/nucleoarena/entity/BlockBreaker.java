package dev.nucleoarena.entity;

import dev.nucleoarena.arena.MatchManager;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

import java.util.HashMap;
import java.util.Map;

import static dev.nucleoarena.physics.PhysicsConstants.BALL_BREAK_MIN_MS;

/**
 * Romper bloques por impacto (balón y coche). Nunca: cristal / cristal teñido, barrier, obsidiana, bedrock, luces,
 * rampas ni nada de la cancha. El resto necesita de 1 a 3 impactos según su dureza y la fuerza del golpe.
 */
public final class BlockBreaker {
    private final Map<Long, int[]> hits = new HashMap<>();       // pos → {impactos, tick}

    /** @param ms velocidad del impacto en m/s · @return true si rompió algún bloque. */
    public boolean hit(ServerLevel sl, AABB box, double ms) {
        if (ms < BALL_BREAK_MIN_MS) return false;
        long now = sl.getGameTime();
        boolean broke = false;
        for (BlockPos pos : BlockPos.betweenClosed(
                Mth.floor(box.minX), Mth.floor(box.minY), Mth.floor(box.minZ),
                Mth.floor(box.maxX), Mth.floor(box.maxY), Mth.floor(box.maxZ))) {
            BlockState st = sl.getBlockState(pos);
            if (st.isAir() || MatchManager.isArenaBlock(sl, pos)) continue;
            String id = BuiltInRegistries.BLOCK.getKey(st.getBlock()).getPath();
            if (id.contains("obsidian") || id.equals("bedrock")) continue;
            float hardness = st.getDestroySpeed(sl, pos);
            if (hardness < 0f) continue;                                           // indestructibles
            int needed = (int) Mth.clamp(Math.ceil(hardness / (ms * 0.1)), 1.0, 3.0);
            int[] h = hits.computeIfAbsent(pos.asLong(), k -> new int[] { 0, 0 });
            if (now - h[1] > 200) h[0] = 0;                                        // los impactos se olvidan tras 10 s
            h[0]++; h[1] = (int) now;
            if (h[0] >= needed) {
                sl.destroyBlock(pos.immutable(), true);
                hits.remove(pos.asLong());
                broke = true;
            }
        }
        return broke;
    }
}
