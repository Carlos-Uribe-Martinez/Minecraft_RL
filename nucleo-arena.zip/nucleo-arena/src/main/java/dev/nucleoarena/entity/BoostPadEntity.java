package dev.nucleoarena.entity;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.List;

import static dev.nucleoarena.physics.PhysicsConstants.*;

/**
 * Célula de carga (BoostPad).
 *  - Pequeña: +12 de boost al pasar a menos de 1.5 bloques.
 *  - Grande:  recarga a 100 y entra en enfriamiento (10 s) antes de reactivarse.
 * Un pad NO se consume si el coche ya tiene el boost lleno.
 * Posición de la entidad = punto sobre el suelo donde se dibuja el pad.
 */
public class BoostPadEntity extends Entity {

    private static final EntityDataAccessor<Boolean> DATA_LARGE    = SynchedEntityData.defineId(BoostPadEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Integer> DATA_COOLDOWN = SynchedEntityData.defineId(BoostPadEntity.class, EntityDataSerializers.INT);

    private int cooldownTicks;   // verdad en servidor; DATA_COOLDOWN solo para el render del cliente

    public BoostPadEntity(EntityType<? extends BoostPadEntity> type, Level level) {
        super(type, level);
        this.noPhysics = true;
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder b) {
        b.define(DATA_LARGE, false);
        b.define(DATA_COOLDOWN, 0);
    }

    // ═════════════════════════════ TICK ═════════════════════════════

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide()) clientTick();
        else serverTick();
    }

    private void serverTick() {
        // ── Enfriamiento ──
        if (cooldownTicks > 0) {
            if (--cooldownTicks == 0) {
                entityData.set(DATA_COOLDOWN, 0);                       // ¡reactivado!
                ((ServerLevel) level()).sendParticles(ParticleTypes.END_ROD, getX(), getY() + 0.2, getZ(), 12, 0.5, 0.1, 0.5, 0.03);
            }
            return;
        }

        // ── Detección: coches a < 1.5 bloques ──
        Vec3 c = position();
        AABB area = new AABB(c, c).inflate(PAD_RADIUS + 1.0);
        List<VehicleEntity> cars = level().getEntitiesOfClass(VehicleEntity.class, area, VehicleEntity::isActiveCar);

        for (VehicleEntity car : cars) {
            if (car.position().distanceToSqr(c) > PAD_RADIUS * PAD_RADIUS) continue;   // car.position() = base del coche
            if (car.getBoost() >= BOOST_CAPACITY) continue;                             // lleno: no se consume

            if (isLarge()) {
                car.setBoost(BOOST_CAPACITY);                                           // recarga completa
                startCooldown(PAD_LARGE_COOLDOWN);
            } else {
                car.addBoost(PAD_SMALL_AMOUNT);                                         // +12 instantáneos
                startCooldown(PAD_SMALL_COOLDOWN);
            }
            ServerLevel sl = (ServerLevel) level();
            sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, c.x, c.y + 0.3, c.z, isLarge() ? 30 : 10, 0.4, 0.3, 0.4, 0.2);
            sl.playSound(null, c.x, c.y, c.z, SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.BLOCKS, 0.8f, isLarge() ? 0.8f : 1.4f);
            break;                                                                      // un pad, un coche por activación
        }
    }

    private void startCooldown(int ticks) {
        cooldownTicks = ticks;
        entityData.set(DATA_COOLDOWN, ticks);
    }

    private void clientTick() {
        if (!isReady()) return;
        // Pilar de partículas mientras está activo (el renderer dibuja el disco/orbe)
        if (tickCount % (isLarge() ? 2 : 6) == 0) {
            level().addParticle(ParticleTypes.END_ROD,
                    getX() + (random.nextDouble() - 0.5) * 0.8, getY() + 0.1, getZ() + (random.nextDouble() - 0.5) * 0.8,
                    0.0, isLarge() ? 0.08 : 0.04, 0.0);
        }
    }

    // ═════════════════════════════ API ═════════════════════════════

    public boolean isLarge()  { return entityData.get(DATA_LARGE); }
    public void setLarge(boolean large) { entityData.set(DATA_LARGE, large); }
    public boolean isReady()  { return entityData.get(DATA_COOLDOWN) == 0; }

    // ═════════════════════════ BOILERPLATE ═════════════════════════

    @Override public boolean isPickable() { return false; }
    @Override public boolean isNoGravity() { return true; }
    @Override public boolean hurtServer(ServerLevel level, DamageSource source, float amount) { return false; }
    @Override protected void readAdditionalSaveData(ValueInput in) { setLarge(in.getBoolean("Large").orElse(false)); }
    @Override protected void addAdditionalSaveData(ValueOutput out) { out.putBoolean("Large", isLarge()); }
}
