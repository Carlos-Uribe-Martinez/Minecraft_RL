package dev.nucleoarena.entity;

import dev.nucleoarena.physics.VecUtil;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import static dev.nucleoarena.physics.PhysicsConstants.*;

/**
 * Colisión esfera ↔ OBB del coche con las MISMAS zonas y reglas que el balón del mod (abajo → lo manda hacia arriba,
 * defensa/techo, lados…), pero sin estado: sirve para cualquier esfera (p. ej. el cubo de azufre "football").
 */
public final class SphereCarCollision {
    private SphereCarCollision() {}

    /** @param v nueva velocidad de la esfera · @param shift desplazamiento para sacarla de la caja del coche */
    public record Result(Vec3 v, Vec3 shift) {}

    private enum Zone {
        FRONT_TOP(ZONE_TRANSFER_FRONT_TOP), SIDE_REAR(ZONE_TRANSFER_SIDE_REAR), BOTTOM(ZONE_TRANSFER_BOTTOM);
        final double transfer;
        Zone(double t) { transfer = t; }
    }

    /** @return null si no hay contacto */
    public static Result collide(Vec3 center, double radius, Vec3 v, VehicleEntity car) {
        Quaternionf q = car.getOrientation();
        Quaternionf inv = new Quaternionf(q).conjugate();
        Vector3f local = inv.transform(VecUtil.vec3f(center.subtract(car.obbCenter())), new Vector3f());
        final float hx = car.getKind().halfX, hy = car.getKind().halfY, hz = car.getKind().halfZ;
        Vector3f closest = new Vector3f(Mth.clamp(local.x, -hx, hx), Mth.clamp(local.y, -hy, hy), Mth.clamp(local.z, -hz, hz));
        Vector3f diff = new Vector3f(local).sub(closest);
        float dist = diff.length();

        Vector3f nLocal = new Vector3f();
        if (dist > 1.0E-5f) {
            if (dist >= radius) return null;
            nLocal.set(diff).div(dist);
        } else {
            float px = hx - Math.abs(local.x), py = hy - Math.abs(local.y), pz = hz - Math.abs(local.z);
            if (py <= px && py <= pz) nLocal.set(0, local.y >= 0 ? 1 : -1, 0);
            else if (px <= pz)        nLocal.set(local.x >= 0 ? 1 : -1, 0, 0);
            else                      nLocal.set(0, 0, local.z >= 0 ? 1 : -1);
            dist = 0f;
        }
        Vec3 n = VecUtil.rotate(q, VecUtil.vec(nLocal)).normalize();       // del coche hacia la esfera
        Vec3 shift = n.scale(radius - dist);

        Vec3 carV = car.getVelocity();
        Vec3 rel = v.subtract(carV);
        double vn = rel.dot(n);
        if (vn >= 0.0) return new Result(v, shift);                        // ya se separan

        Zone zone;
        if (nLocal.y < -0.5f)                         zone = Zone.BOTTOM;
        else if (nLocal.z > 0.5f || nLocal.y > 0.5f)  zone = Zone.FRONT_TOP;
        else                                          zone = Zone.SIDE_REAR;

        Vec3 out = v;
        boolean roofContact = zone == Zone.FRONT_TOP && nLocal.y > 0.7f;
        if (roofContact && -vn < DRIBBLE_REST_VN) {
            out = out.add(n.scale(-vn));
            out = out.subtract(VecUtil.tangent(rel, n).scale(DRIBBLE_FRICTION));
        } else {
            double eEff = BALL_RESTITUTION * zone.transfer;
            double j = -(1.0 + eEff) * vn;
            out = out.add(n.scale(j));
            if (zone == Zone.BOTTOM) out = out.subtract(VecUtil.tangent(out.subtract(carV), n).scale(BOTTOM_TANGENT_DAMP));
            car.addVelocity(n.scale(-j * CAR_RECOIL));
        }
        return new Result(out, shift);
    }
}
