package dev.nucleoarena.entity;

import dev.nucleoarena.physics.VecUtil;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import net.minecraft.world.phys.Vec3;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.List;

import static dev.nucleoarena.physics.PhysicsConstants.*;

/**
 * Núcleo energético (balón).
 *  - Física propia: gravedad 6.5 m/s², tope 60 m/s, rebote 60 %, sub-pasos anti-tunneling.
 *  - Colisión esfera-vs-OBB con los coches, con modificadores por zona de impacto.
 *  - Estela de partículas en cliente proporcional a la velocidad (>20 m/s).
 */
public class CustomBallEntity extends Entity {

    private static final EntityDataAccessor<Float>   DATA_SPEED = SynchedEntityData.defineId(CustomBallEntity.class, EntityDataSerializers.FLOAT);   // b/t
    private static final EntityDataAccessor<Integer> DATA_TRAIL = SynchedEntityData.defineId(CustomBallEntity.class, EntityDataSerializers.INT);

    /** Estelas personalizables (índice sincronizado). */
    private static final ParticleOptions[] TRAILS = {
            ParticleTypes.SOUL_FIRE_FLAME,   // 0 fuego azul
            ParticleTypes.ELECTRIC_SPARK,    // 1 energía
            ParticleTypes.END_ROD,           // 2 plasma blanco
            ParticleTypes.FLAME              // 3 magma
    };

    private enum Zone {
        FRONT_TOP(ZONE_TRANSFER_FRONT_TOP), SIDE_REAR(ZONE_TRANSFER_SIDE_REAR), BOTTOM(ZONE_TRANSFER_BOTTOM);
        final double transfer;
        Zone(double t) { transfer = t; }
    }

    // servidor
    private boolean frozen;
    private int lastTouchTeam = -1;
    private long lastTouchTick;
    // cliente
    private boolean clientXray;

    public CustomBallEntity(EntityType<? extends CustomBallEntity> type, Level level) {
        super(type, level);
        this.noCulling = true;
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder b) {
        b.define(DATA_SPEED, 0f);
        b.define(DATA_TRAIL, 0);
    }

    // ═════════════════════════════ TICK ═════════════════════════════

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide()) clientTick();
        else serverTick();
    }

    private void serverTick() {
        if (frozen) { setDeltaMovement(Vec3.ZERO); entityData.set(DATA_SPEED, 0f); return; }
        Vec3 v = getDeltaMovement();

        // Gravedad del mod + tope estricto de velocidad
        v = v.add(0.0, -GRAVITY, 0.0);
        v = VecUtil.clampLength(v, BALL_MAX_SPEED);

        // Coches cercanos (una consulta por tick; el barrido se hace por sub-pasos)
        List<VehicleEntity> cars = level().getEntitiesOfClass(VehicleEntity.class,
                getBoundingBox().inflate(v.length() + 2.5), VehicleEntity::isActiveCar);

        boolean groundContact = false;

        for (int i = 0; i < BALL_SUBSTEPS; i++) {
            Vec3 step = v.scale(1.0 / BALL_SUBSTEPS);
            Vec3 before = position();
            move(MoverType.SELF, step);
            Vec3 blocked = step.subtract(position().subtract(before));

            // Rebote por eje contra bloques: v' = -v · 0.6
            if (Math.abs(blocked.x) > 1.0E-5) v = new Vec3(-v.x * BALL_RESTITUTION, v.y, v.z);
            if (Math.abs(blocked.z) > 1.0E-5) v = new Vec3(v.x, v.y, -v.z * BALL_RESTITUTION);
            if (Math.abs(blocked.y) > 1.0E-5) {
                if (Math.abs(v.y) < BALL_REST_VN) v = new Vec3(v.x, 0.0, v.z);          // reposo: sin jitter
                else                              v = new Vec3(v.x, -v.y * BALL_RESTITUTION, v.z);
                if (blocked.y < 0) groundContact = true;                                  // intentaba bajar y chocó
            }

            for (VehicleEntity car : cars) v = collideWithCar(car, v);
            v = VecUtil.clampLength(v, BALL_MAX_SPEED);
        }

        if (groundContact) v = new Vec3(v.x * BALL_ROLL_FRICTION, v.y, v.z * BALL_ROLL_FRICTION);

        setDeltaMovement(v);
        entityData.set(DATA_SPEED, (float) v.length());
    }

    // ═════════════════════ COLISIÓN ESFERA ↔ OBB (COCHE) ═════════════════════

    private Vec3 ballCenter() { return getBoundingBox().getCenter(); }

    private Vec3 collideWithCar(VehicleEntity car, Vec3 v) {
        Quaternionf q = car.getOrientation();
        Quaternionf inv = new Quaternionf(q).conjugate();

        // Centro del balón en el espacio local de la OBB
        Vector3f local = inv.transform(VecUtil.vec3f(ballCenter().subtract(car.obbCenter())), new Vector3f());
        Vector3f closest = new Vector3f(
                Mth.clamp(local.x, -OBB_HALF_X, OBB_HALF_X),
                Mth.clamp(local.y, -OBB_HALF_Y, OBB_HALF_Y),
                Mth.clamp(local.z, -OBB_HALF_Z, OBB_HALF_Z));
        Vector3f diff = new Vector3f(local).sub(closest);
        float dist = diff.length();

        Vector3f nLocal = new Vector3f();
        if (dist > 1.0E-5f) {
            if (dist >= BALL_RADIUS) return v;                              // sin contacto
            nLocal.set(diff).div(dist);
        } else {                                                            // centro dentro de la caja
            float px = OBB_HALF_X - Math.abs(local.x);
            float py = OBB_HALF_Y - Math.abs(local.y);
            float pz = OBB_HALF_Z - Math.abs(local.z);
            if (py <= px && py <= pz) nLocal.set(0, local.y >= 0 ? 1 : -1, 0);
            else if (px <= pz)        nLocal.set(local.x >= 0 ? 1 : -1, 0, 0);
            else                      nLocal.set(0, 0, local.z >= 0 ? 1 : -1);
            dist = 0f;
        }
        double penetration = BALL_RADIUS - dist;

        Vec3 n = VecUtil.rotate(q, VecUtil.vec(nLocal)).normalize();       // del coche hacia el balón
        setPos(position().add(n.scale(penetration)));                      // des-penetrar

        Vec3 carV = car.getVelocity();
        Vec3 rel = v.subtract(carV);
        double vn = rel.dot(n);
        if (vn >= 0.0) return v;                                           // ya se separan

        // Zona de impacto (en el espacio local del coche)
        Zone zone;
        if (nLocal.y < -0.5f)                         zone = Zone.BOTTOM;     // ruedas / bajos
        else if (nLocal.z > 0.5f || nLocal.y > 0.5f)  zone = Zone.FRONT_TOP;  // defensa o techo
        else                                          zone = Zone.SIDE_REAR;

        // FLIP RESET: contacto plano con el centro inferior (las 4 ruedas) del coche
        if (nLocal.y < -0.85f) car.grantFlipReset();

        Vec3 out = v;
        boolean roofContact = zone == Zone.FRONT_TOP && nLocal.y > 0.7f;

        if (roofContact && -vn < DRIBBLE_REST_VN) {
            // DRIBBLING: contacto casi en reposo sobre el techo → sin rebote + fricción que iguala velocidades
            out = out.add(n.scale(-vn));
            Vec3 tangentRel = VecUtil.tangent(rel, n);
            out = out.subtract(tangentRel.scale(DRIBBLE_FRICTION));
        } else {
            // Impulso: j = -(1 + e_eff)·vn,  e_eff = 0.6 · transfer(zona)
            double eEff = BALL_RESTITUTION * zone.transfer;
            double j = -(1.0 + eEff) * vn;
            out = out.add(n.scale(j));
            if (zone == Zone.BOTTOM) {                                      // amortigua también lo tangencial
                out = out.subtract(VecUtil.tangent(out.subtract(carV), n).scale(BOTTOM_TANGENT_DAMP));
            }
            car.addVelocity(n.scale(-j * CAR_RECOIL));
        }

        lastTouchTeam = car.getTeam();
        lastTouchTick = level().getGameTime();
        return out;
    }

    // ═════════════════════ ESTELA (CLIENTE) ═════════════════════

    private final Quaternionf roll = new Quaternionf();
    private final Quaternionf prevRoll = new Quaternionf();

    /** Orientación visual (rodadura) interpolada, para el renderer. */
    public Quaternionf getRoll(float pt) { return new Quaternionf(prevRoll).slerp(roll, pt); }
    public boolean isClientXray() { return clientXray; }

    private void clientTick() {
        prevRoll.set(roll);
        Vec3 m = new Vec3(getX() - xo, getY() - yo, getZ() - zo);
        double len = m.length();
        if (len > 1.0E-4) {                               // rueda sobre el eje (UP × movimiento)
            Vec3 axis = new Vec3(0, 1, 0).cross(m).normalize();
            roll.premul(new Quaternionf().rotateAxis((float) (len / BALL_RADIUS),
                    (float) axis.x, (float) axis.y, (float) axis.z)).normalize();
        }
        double ms = entityData.get(DATA_SPEED) * TPS;
        if (ms <= BALL_TRAIL_MIN_MS) return;

        // t∈[0,1]: 0 a 20 m/s, 1 a 60 m/s → densidad y longitud crecen con la velocidad
        double t = Mth.clamp((ms - BALL_TRAIL_MIN_MS) / (BALL_TRAIL_FULL_MS - BALL_TRAIL_MIN_MS), 0.0, 1.0);
        Vec3 motion = new Vec3(getX() - xo, getY() - yo, getZ() - zo);
        if (motion.lengthSqr() < 1.0E-8) return;

        Vec3 back = motion.normalize().reverse();
        double length = Mth.lerp(t, 2.0, 14.0);                  // largo de la estela en bloques
        int samples = 2 + (int) (t * 8);                          // puntos a lo largo de la estela
        int perSample = 1 + (int) (t * 2);                        // densidad por punto
        ParticleOptions p = TRAILS[Mth.clamp(entityData.get(DATA_TRAIL), 0, TRAILS.length - 1)];
        Vec3 c = ballCenter();

        for (int s = 0; s < samples; s++) {
            double d = length * s / samples;
            for (int k = 0; k < perSample; k++) {
                double spread = 0.12 + 0.25 * (d / length);       // la estela se ensancha hacia atrás
                level().addParticle(p,
                        c.x + back.x * d + (random.nextDouble() - 0.5) * spread,
                        c.y + back.y * d + (random.nextDouble() - 0.5) * spread,
                        c.z + back.z * d + (random.nextDouble() - 0.5) * spread,
                        0.0, 0.0, 0.0);
            }
        }
    }

    // ═════════════════════ API / X-RAY ═════════════════════

    public void setFrozen(boolean f) { frozen = f; if (f) setDeltaMovement(Vec3.ZERO); }
    public boolean isFrozen() { return frozen; }

    /** Centro de la esfera → posición de la entidad (la AABB 1.8³ se apoya en su base). */
    public void placeCenterAt(Vec3 center) {
        setPos(center.x, center.y - BALL_RADIUS, center.z);
        setDeltaMovement(Vec3.ZERO);
        lastTouchTeam = -1;
    }
    public Vec3 getCenter() { return getBoundingBox().getCenter(); }

    public int  getLastTouchTeam() { return lastTouchTeam; }
    public long getLastTouchTick() { return lastTouchTick; }
    public void setTrail(int idx)  { entityData.set(DATA_TRAIL, idx); }

    /** La cámara de balón activa esto cuando el coche/un bloque tapa el balón. */
    public void setClientXray(boolean on) { this.clientXray = on; }

    /** Contorno "rayos X": el outline de glowing se dibuja a través de bloques y entidades. */
    @Override
    public boolean isCurrentlyGlowing() {
        return level().isClientSide() ? clientXray || super.isCurrentlyGlowing() : super.isCurrentlyGlowing();
    }

    @Override public boolean isPickable() { return false; }
    @Override public boolean hurtServer(ServerLevel level, DamageSource source, float amount) { return false; }
    @Override protected void readAdditionalSaveData(ValueInput in) { entityData.set(DATA_TRAIL, in.getInt("Trail").orElse(0)); }
    @Override protected void addAdditionalSaveData(ValueOutput out) { out.putInt("Trail", entityData.get(DATA_TRAIL)); }
}
