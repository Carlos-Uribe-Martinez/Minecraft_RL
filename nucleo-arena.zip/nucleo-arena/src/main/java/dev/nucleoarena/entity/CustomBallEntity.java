package dev.nucleoarena.entity;

import dev.nucleoarena.Football;
import dev.nucleoarena.arena.MatchManager;
import dev.nucleoarena.physics.VecUtil;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import net.minecraft.world.phys.Vec3;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.List;

import static dev.nucleoarena.physics.PhysicsConstants.*;

/**
 * Núcleo energético (balón).
 *  - Física propia: gravedad 6.5 m/s², tope 60 m/s, rebote 60 %, sub-pasos anti-tunneling.
 *  - Colisión esfera-vs-OBB con los coches, con modificadores por zona de impacto.
 *  - Estela de partículas en cliente proporcional a la velocidad (>20 m/s).
 */
public class CustomBallEntity extends Entity {

    private static final EntityDataAccessor<Float>   DATA_SPEED = SynchedEntityData.defineId(CustomBallEntity.class, EntityDataSerializers.FLOAT);   // b/t
    private static final EntityDataAccessor<Integer> DATA_TRAIL = SynchedEntityData.defineId(CustomBallEntity.class, EntityDataSerializers.INT);

    /** Estelas personalizables (índice sincronizado). */
    private static final ParticleOptions[] TRAILS = {
            ParticleTypes.SOUL_FIRE_FLAME,   // 0 fuego azul
            ParticleTypes.ELECTRIC_SPARK,    // 1 energía
            ParticleTypes.END_ROD,           // 2 plasma blanco
            ParticleTypes.FLAME              // 3 magma
    };

    private enum Zone {
        FRONT_TOP(ZONE_TRANSFER_FRONT_TOP), SIDE_REAR(ZONE_TRANSFER_SIDE_REAR), BOTTOM(ZONE_TRANSFER_BOTTOM);
        final double transfer;
        Zone(double t) { transfer = t; }
    }

    // servidor
    private boolean frozen;
    private java.util.UUID lastToucherId;
    private String lastToucherName = "";
    private static final EntityDataAccessor<Boolean> DATA_PUPPET = SynchedEntityData.defineId(CustomBallEntity.class, EntityDataSerializers.BOOLEAN);
    private java.util.UUID puppetCube;                                        // cubo de azufre que hace de "cuerpo" visual
    private final java.util.Map<Long, int[]> blockHits = new java.util.HashMap<>();   // pos → {impactos, tick}
    private int groundTicks, climbTicks, ceilTicks;
    private Vec3 climbDir = Vec3.ZERO;               // horizontal, hacia la pared por la que trepa
    private int lastTouchTeam = -1;
    private long lastTouchTick;
    // cliente
    private boolean clientXray;

    public CustomBallEntity(EntityType<? extends CustomBallEntity> type, Level level) {
        super(type, level);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder b) {
        b.define(DATA_SPEED, 0f);
        b.define(DATA_TRAIL, 0);
        b.define(DATA_PUPPET, false);
    }

    // ═════════════════════════════ TICK ═════════════════════════════

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide()) clientTick();
        else serverTick();
    }

    private void serverTick() {
        if (frozen) { setDeltaMovement(Vec3.ZERO); entityData.set(DATA_SPEED, 0f); return; }
        Vec3 v = getDeltaMovement();

        // Gravedad del mod + tope estricto de velocidad
        v = v.add(0.0, -GRAVITY, 0.0);
        v = VecUtil.clampLength(v, BALL_MAX_SPEED);

        // Coches cercanos (una consulta por tick; el barrido se hace por sub-pasos)
        List<VehicleEntity> cars = level().getEntitiesOfClass(VehicleEntity.class,
                getBoundingBox().inflate(v.length() + 2.5), VehicleEntity::isActiveCar);

        boolean groundContact = false;

        for (int i = 0; i < BALL_SUBSTEPS; i++) {
            Vec3 step = v.scale(1.0 / BALL_SUBSTEPS);
            Vec3 before = position();
            move(MoverType.SELF, step);
            Vec3 blocked = step.subtract(position().subtract(before));

            // A gran velocidad el balón rompe bloques blandos (nunca bedrock ni la cancha) y pierde energía
            if (blocked.lengthSqr() > 1.0E-9 && breakBlocks(v, blocked)) {
                v = v.scale(0.8);
                continue;
            }

            // Pared: cerca del suelo y con velocidad SUBE por ella; en el aire alto rebota; con poca fuerza cae pegada.
            boolean xHit = Math.abs(blocked.x) > 1.0E-5, zHit = Math.abs(blocked.z) > 1.0E-5;
            boolean wallHit = xHit || zHit;
            if (wallHit) {
                double into = Math.hypot(xHit ? v.x : 0.0, zHit ? v.z : 0.0);        // velocidad contra la pared
                double hs = Math.hypot(v.x, v.z);
                Vec3 wallDir = new Vec3(xHit ? Math.signum(blocked.x) : 0.0, 0.0, zHit ? Math.signum(blocked.z) : 0.0).normalize();
                Vec3 along = new Vec3(xHit ? 0.0 : v.x, v.y, zHit ? 0.0 : v.z);       // sin la componente contra la pared
                if (climbTicks > 0 && v.length() >= BALL_CLIMB_MIN * 0.6) {         // ya trepando: sigue pegada
                    v = into > 0.1 ? along.add(0.0, into * 0.95, 0.0) : along;
                    climbDir = wallDir;
                    continue;
                }
                if (climbTicks == 0 && (groundContact || groundTicks > 0 || nearFloor()) && hs >= BALL_CLIMB_MIN) {
                    v = along.add(0.0, Math.max(v.y, 0.0) * 0.0 + into * 0.95, 0.0); // convierte la fuerza horizontal en subida
                    climbTicks = 40;
                    climbDir = wallDir;
                    continue;
                }
            }

            // Techo a buena velocidad: resbala por él (como otra pared) y cae al perder velocidad
            if (blocked.y > 1.0E-5 && v.y >= BALL_CEIL_MIN && Math.hypot(v.x, v.z) > speed(1.5)) {
                v = new Vec3(v.x, 0.0, v.z);
                ceilTicks = 40;
                continue;
            }

            // Rodando despacio contra un escalón de ≤ 1 bloque: lo sube en vez de rebotar
            if (wallHit && (groundContact || groundTicks > 0)) {
                Vec3 hdir = new Vec3(v.x, 0, v.z);
                if (hdir.lengthSqr() > 1.0E-6) {
                    hdir = hdir.normalize();
                    var up = getBoundingBox().move(hdir.x * 0.35, STEP_HEIGHT, hdir.z * 0.35);
                    if (level().noCollision(this, up)) {
                        setPos(position().add(0.0, STEP_HEIGHT * 0.98, 0.0));
                        continue;
                    }
                }
            }

            // Rebote por eje contra bloques: v' = -v · 0.6
            if (Math.abs(blocked.x) > 1.0E-5) v = new Vec3(-v.x * BALL_RESTITUTION, v.y, v.z);
            if (Math.abs(blocked.z) > 1.0E-5) v = new Vec3(v.x, v.y, -v.z * BALL_RESTITUTION);
            if (Math.abs(blocked.y) > 1.0E-5) {
                if (Math.abs(v.y) < BALL_REST_VN) v = new Vec3(v.x, 0.0, v.z);          // reposo: sin jitter
                else                              v = new Vec3(v.x, -v.y * BALL_RESTITUTION, v.z);
                if (blocked.y < 0) groundContact = true;                                  // intentaba bajar y chocó
            }

            for (VehicleEntity car : cars) v = collideWithCar(car, v);
            v = collideWithMobs(v);
            v = VecUtil.clampLength(v, BALL_MAX_SPEED);
        }

        if (groundContact) v = new Vec3(v.x * BALL_ROLL_FRICTION, v.y, v.z * BALL_ROLL_FRICTION);
        groundTicks = groundContact ? 3 : Math.max(0, groundTicks - 1);
        if (climbTicks > 0) {                         // trepando: casi sin gravedad mientras lleve velocidad; la fricción la frena
            climbTicks--;
            double sp = v.length();
            if (sp >= BALL_CLIMB_MIN * 0.6) {
                v = v.add(0.0, GRAVITY * (1.0 - BALL_CLIMB_GRAVITY), 0.0);        // compensa casi toda la gravedad
                v = v.scale(BALL_CLIMB_FRICTION);
                v = v.add(climbDir.scale(BALL_CLIMB_ADHESION));                   // se mantiene contra la pared
                climbTicks = Math.max(climbTicks, 2);
            } else climbTicks = 0;                    // sin velocidad: vuelve la gravedad normal
        }
        if (ceilTicks > 0) {                          // resbalando por el techo mientras lleve velocidad horizontal
            ceilTicks--;
            if (Math.hypot(v.x, v.z) >= BALL_CLIMB_MIN * 0.4) {
                v = v.add(0.0, GRAVITY * (1.0 - BALL_CLIMB_GRAVITY) + 0.005, 0.0);
                v = new Vec3(v.x * 0.985, v.y, v.z * 0.985);
                ceilTicks = Math.max(ceilTicks, 2);
            } else ceilTicks = 0;
        }

        v = containInArena(v);
        setDeltaMovement(v);
        entityData.set(DATA_SPEED, (float) v.length());
        syncPuppet();

        // Estela de luz (no llamas) cuando lleva la mitad de la velocidad máxima o más
        if (v.length() >= BALL_MAX_SPEED * 0.5 && level() instanceof ServerLevel sl) {
            Vec3 c = ballCenter(), back = v.normalize().scale(-BALL_RADIUS);
            sl.sendParticles(ParticleTypes.END_ROD, c.x + back.x, c.y + back.y, c.z + back.z, 3, 0.2, 0.2, 0.2, 0.0);
        }
    }

    // ───────────────────────── Cubo de azufre como cuerpo del balón ─────────────────────────

    public boolean isPuppet() { return entityData.get(DATA_PUPPET); }

    /** El balón (física, colisiones, goles) se vuelve invisible y el cubo de azufre lo sigue como su cuerpo. */
    public void setPuppet(java.util.UUID cubeId) {
        puppetCube = cubeId;
        entityData.set(DATA_PUPPET, cubeId != null);
    }

    private void syncPuppet() {
        if (puppetCube == null || !(level() instanceof ServerLevel sl)) return;
        Entity cube = sl.getEntity(puppetCube);
        if (cube == null || cube.isRemoved()) {                                // matan al cubo: vuelve el balón del mod
            Football.unlink(puppetCube);
            setPuppet(null);
            return;
        }
        Vec3 c = ballCenter(), v = getDeltaMovement();
        cube.setPos(c.x, c.y - cube.getBbHeight() / 2.0, c.z);
        cube.setDeltaMovement(Vec3.ZERO);
        if (v.horizontalDistanceSqr() > 1.0E-4) cube.setYRot((float) (Mth.atan2(-v.x, v.z) * Mth.RAD_TO_DEG));
    }

    /**
     * El balón del partido nunca sale de la cancha: se corrige su posición dentro del interior (paredes, techo,
     * portería) por si un empujón de coche o un golpe lo atraviesa; si aun así se escapa, vuelve al centro.
     */
    private Vec3 respawnNearPlayer(Vec3 from, Vec3 arenaCenter) {
        VehicleEntity best = null;
        double bd = Double.MAX_VALUE;
        for (VehicleEntity car : level().getEntitiesOfClass(VehicleEntity.class, getBoundingBox().inflate(400.0),
                c -> c.isActiveCar() && c.getFirstPassenger() != null)) {
            double d = car.position().distanceToSqr(from);
            if (d < bd) { bd = d; best = car; }
        }
        if (best == null) return new Vec3(arenaCenter.x, arenaCenter.y + BALL_CENTER_Y_REST, arenaCenter.z);
        float yaw = (float) Math.toRadians(best.getYRot());
        Vec3 fwd = new Vec3(-Math.sin(yaw), 0, Math.cos(yaw));
        return best.position().add(fwd.scale(2.0)).add(0.0, 1.5 + BALL_CENTER_Y_REST * 0.0, 0.0);
    }

    private Vec3 containInArena(Vec3 v) {
        var a = MatchManager.arena();
        if (a == null || MatchManager.matchBall() != this || !(level() instanceof ServerLevel)) return v;
        Vec3 c = a.center(), p = ballCenter();
        double r = BALL_RADIUS;

        if (!a.bounds().inflate(6.0).contains(p)) {                      // escapó: vuelve frente al jugador más cercano (^ ^1.5 ^2)
            placeCenterAt(respawnNearPlayer(p, c));
            return Vec3.ZERO;
        }

        double dx = p.x - c.x, dz = p.z - c.z;
        boolean pastGoalLine = Math.abs(dz) > a.halfL();
        boolean mouth = Math.abs(dx) < a.goalHalfW() - r && p.y < c.y + a.goalHeight();
        double xLim = (pastGoalLine ? a.goalHalfW() : a.halfW()) - r;
        double zLim = (pastGoalLine || mouth ? a.halfL() + a.goalDepth() : a.halfL()) - r;
        double yMax = c.y + (pastGoalLine ? a.goalHeight() : a.height()) - r;

        double nx = Mth.clamp(dx, -xLim, xLim), nz = Mth.clamp(dz, -zLim, zLim), ny = Math.min(p.y, yMax);
        if (nx == dx && nz == dz && ny == p.y) return v;

        setPos(position().add(nx - dx, ny - p.y, nz - dz));
        double vx = v.x, vy = v.y, vz = v.z;
        if (nx != dx && vx * dx > 0) vx = -vx * BALL_RESTITUTION;        // rebota hacia dentro
        if (nz != dz && vz * dz > 0) vz = -vz * BALL_RESTITUTION;
        if (ny != p.y && vy > 0)     vy = -vy * BALL_RESTITUTION;
        return new Vec3(vx, vy, vz);
    }

    // ═════════════════════ MOBS Y BLOQUES ═════════════════════

    /** El balón golpea mobs: daño según la velocidad relativa (mata a gran velocidad) y rebota. */
    private Vec3 collideWithMobs(Vec3 v) {
        if (!(level() instanceof ServerLevel sl)) return v;
        List<LivingEntity> mobs = sl.getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(BALL_MOB_REACH),
                e -> e.isAlive() && !(e instanceof Player) && !Football.isSulfur(e) && !(e.getVehicle() instanceof VehicleEntity));
        for (LivingEntity m : mobs) {
            Vec3 toBall = ballCenter().subtract(m.getBoundingBox().getCenter());
            if (toBall.lengthSqr() < 1.0E-6) toBall = new Vec3(0, 1, 0);
            Vec3 n = toBall.normalize();                                  // del mob hacia el balón
            Vec3 rel = v.subtract(m.getDeltaMovement());
            double closing = -rel.dot(n);                                 // >0: el balón va hacia el mob
            if (closing <= 0.0) continue;
            double ms = closing * TPS;
            if (ms >= BALL_HURT_MIN_MS) {
                float dmg = (float) ((ms - BALL_HURT_MIN_MS) * BALL_HURT_PER_MS + 3.0);
                if (m.hurtServer(sl, sl.damageSources().generic(), dmg)) {
                    m.push(-n.x * closing * 0.8, 0.25, -n.z * closing * 0.8);
                }
            }
            v = v.add(n.scale(closing * (1.0 + BALL_RESTITUTION)));       // rebote
        }
        return v;
    }

    /** Rompe los bloques con los que acaba de chocar si va lo bastante rápido. @return true si rompió alguno. */
    private boolean breakBlocks(Vec3 v, Vec3 blocked) {
        double ms = v.length() * TPS;
        if (ms < BALL_BREAK_MIN_MS || !(level() instanceof ServerLevel sl)) return false;
        long now = sl.getGameTime();
        var arena = MatchManager.arena();

        Vec3 dir = new Vec3(Math.signum(blocked.x), Math.signum(blocked.y), Math.signum(blocked.z));
        var box = getBoundingBox().inflate(0.05).expandTowards(dir.scale(0.3));
        boolean broke = false;
        for (BlockPos pos : BlockPos.betweenClosed(
                net.minecraft.util.Mth.floor(box.minX), net.minecraft.util.Mth.floor(box.minY), net.minecraft.util.Mth.floor(box.minZ),
                net.minecraft.util.Mth.floor(box.maxX), net.minecraft.util.Mth.floor(box.maxY), net.minecraft.util.Mth.floor(box.maxZ))) {
            BlockState st = sl.getBlockState(pos);
            if (st.isAir() || st.is(Blocks.BEDROCK)) continue;
            if (MatchManager.isArenaBlock(sl, pos)) continue;                              // cristal, barrier, luces, rampas, marco…
            if (arena != null && arena.bounds().contains(Vec3.atCenterOf(pos))) continue;   // la cancha es intocable
            String bid = BuiltInRegistries.BLOCK.getKey(st.getBlock()).getPath();
            if (bid.contains("obsidian") || bid.equals("bedrock")) continue;                // intocables (ademas del cristal y barrier)
            float hardness = st.getDestroySpeed(sl, pos);
            if (hardness < 0f) continue;                                                    // indestructibles
            int needed = (int) Mth.clamp(Math.ceil(hardness / (ms * 0.1)), 1.0, 3.0);       // 1 a 3 impactos según la fuerza
            int[] hit = blockHits.computeIfAbsent(pos.asLong(), k -> new int[] { 0, 0 });
            if (now - hit[1] > 200) hit[0] = 0;                                             // los impactos se olvidan tras 10 s
            hit[0]++; hit[1] = (int) now;
            if (hit[0] >= needed) {
                sl.destroyBlock(pos.immutable(), true);
                blockHits.remove(pos.asLong());
                broke = true;
            }
        }
        return broke;
    }

    // ═════════════════════ COLISIÓN ESFERA ↔ OBB (COCHE) ═════════════════════

    private Vec3 ballCenter() { return getBoundingBox().getCenter(); }

    /** ¿La base del balón está cerca del suelo de la cancha (< BALL_CLIMB_NEAR_FLOOR bloques)? */
    private boolean nearFloor() {
        var a = MatchManager.arena();
        if (a == null || !a.bounds().contains(ballCenter())) return false;
        return ballCenter().y - BALL_RADIUS - a.center().y < BALL_CLIMB_NEAR_FLOOR;
    }

    /**
     * Impulso de un coche sobre una esfera (balón o cubo de azufre): mismas zonas de impacto (bajos → hacia arriba,
     * defensa/techo, lados), des-penetración y dribbling. @return la nueva velocidad, o {@code v} (misma referencia) si no hubo impulso.
     */
    public static Vec3 contactImpulse(Entity target, Vec3 center, double radius, Vec3 v, VehicleEntity car) {
        Quaternionf q = car.getOrientation();
        Quaternionf inv = new Quaternionf(q).conjugate();

        // Centro del balón en el espacio local de la OBB
        Vector3f local = inv.transform(VecUtil.vec3f(center.subtract(car.obbCenter())), new Vector3f());
        final float hx = car.getKind().halfX, hy = car.getKind().halfY, hz = car.getKind().halfZ;
        Vector3f closest = new Vector3f(
                Mth.clamp(local.x, -hx, hx),
                Mth.clamp(local.y, -hy, hy),
                Mth.clamp(local.z, -hz, hz));
        Vector3f diff = new Vector3f(local).sub(closest);
        float dist = diff.length();

        Vector3f nLocal = new Vector3f();
        if (dist > 1.0E-5f) {
            if (dist >= radius) return v;                              // sin contacto
            nLocal.set(diff).div(dist);
        } else {                                                            // centro dentro de la caja
            float px = hx - Math.abs(local.x);
            float py = hy - Math.abs(local.y);
            float pz = hz - Math.abs(local.z);
            if (py <= px && py <= pz) nLocal.set(0, local.y >= 0 ? 1 : -1, 0);
            else if (px <= pz)        nLocal.set(local.x >= 0 ? 1 : -1, 0, 0);
            else                      nLocal.set(0, 0, local.z >= 0 ? 1 : -1);
            dist = 0f;
        }
        double penetration = radius - dist;

        Vec3 n = VecUtil.rotate(q, VecUtil.vec(nLocal)).normalize();       // del coche hacia el balón
        target.setPos(target.position().add(n.scale(penetration)));                      // des-penetrar

        Vec3 carV = car.getVelocity();
        Vec3 rel = v.subtract(carV);
        double vn = rel.dot(n);
        if (vn >= 0.0) return v;                                           // ya se separan

        // Zona de impacto (en el espacio local del coche)
        Zone zone;
        if (nLocal.y < -0.5f)                         zone = Zone.BOTTOM;     // ruedas / bajos
        else if (nLocal.z > 0.5f || nLocal.y > 0.5f)  zone = Zone.FRONT_TOP;  // defensa o techo
        else                                          zone = Zone.SIDE_REAR;

        // FLIP RESET: contacto plano con el centro inferior (las 4 ruedas) del coche
        if (nLocal.y < -0.85f) car.grantFlipReset();

        Vec3 out = v;
        boolean roofContact = zone == Zone.FRONT_TOP && nLocal.y > 0.7f;

        if (roofContact && -vn < DRIBBLE_REST_VN) {
            // DRIBBLING: contacto casi en reposo sobre el techo → sin rebote + fricción que iguala velocidades
            out = out.add(n.scale(-vn));
            Vec3 tangentRel = VecUtil.tangent(rel, n);
            out = out.subtract(tangentRel.scale(DRIBBLE_FRICTION));
        } else {
            // Impulso: j = -(1 + e_eff)·vn,  e_eff = 0.6 · transfer(zona)
            double eEff = BALL_RESTITUTION * zone.transfer;
            double j = -(1.0 + eEff) * vn;
            out = out.add(n.scale(j));
            if (zone == Zone.BOTTOM) {                                      // amortigua también lo tangencial
                out = out.subtract(VecUtil.tangent(out.subtract(carV), n).scale(BOTTOM_TANGENT_DAMP));
            }
            car.addVelocity(n.scale(-j * CAR_RECOIL));
        }
        return out;
    }

    private Vec3 collideWithCar(VehicleEntity car, Vec3 v) {
        Vec3 out = contactImpulse(this, ballCenter(), BALL_RADIUS, v, car);
        if (out == v) return v;                                            // sin contacto / ya se separan
        lastTouchTeam = car.getArenaTeamId();
        lastTouchTick = level().getGameTime();
        if (car.getFirstPassenger() instanceof Player p) { lastToucherId = p.getUUID(); lastToucherName = p.getName().getString(); }
        MatchManager.onBallTouch(car, v, out);
        return out;
    }

    // ═════════════════════ ESTELA (CLIENTE) ═════════════════════

    private final Quaternionf roll = new Quaternionf();
    private final Quaternionf prevRoll = new Quaternionf();

    /** Orientación visual (rodadura) interpolada, para el renderer. */
    public Quaternionf getRoll(float pt) { return new Quaternionf(prevRoll).slerp(roll, pt); }
    public boolean isClientXray() { return clientXray; }

    private void clientTick() {
        prevRoll.set(roll);
        Vec3 m = new Vec3(getX() - xo, getY() - yo, getZ() - zo);
        double len = m.length();
        if (len > 1.0E-4) {                               // rueda sobre el eje (UP × movimiento)
            Vec3 axis = new Vec3(0, 1, 0).cross(m).normalize();
            roll.premul(new Quaternionf().rotateAxis((float) (len / BALL_RADIUS),
                    (float) axis.x, (float) axis.y, (float) axis.z)).normalize();
        }
        double ms = entityData.get(DATA_SPEED) * TPS;
        if (ms <= BALL_TRAIL_MIN_MS) return;

        // t∈[0,1]: 0 a 20 m/s, 1 a 60 m/s → densidad y longitud crecen con la velocidad
        double t = Mth.clamp((ms - BALL_TRAIL_MIN_MS) / (BALL_TRAIL_FULL_MS - BALL_TRAIL_MIN_MS), 0.0, 1.0);
        Vec3 motion = new Vec3(getX() - xo, getY() - yo, getZ() - zo);
        if (motion.lengthSqr() < 1.0E-8) return;

        Vec3 back = motion.normalize().reverse();
        double length = Mth.lerp(t, 2.0, 14.0);                  // largo de la estela en bloques
        int samples = 2 + (int) (t * 8);                          // puntos a lo largo de la estela
        int perSample = 1 + (int) (t * 2);                        // densidad por punto
        ParticleOptions p = TRAILS[Mth.clamp(entityData.get(DATA_TRAIL), 0, TRAILS.length - 1)];
        Vec3 c = ballCenter();

        for (int s = 0; s < samples; s++) {
            double d = length * s / samples;
            for (int k = 0; k < perSample; k++) {
                double spread = 0.12 + 0.25 * (d / length);       // la estela se ensancha hacia atrás
                level().addParticle(p,
                        c.x + back.x * d + (random.nextDouble() - 0.5) * spread,
                        c.y + back.y * d + (random.nextDouble() - 0.5) * spread,
                        c.z + back.z * d + (random.nextDouble() - 0.5) * spread,
                        0.0, 0.0, 0.0);
            }
        }
    }

    // ═════════════════════ API / X-RAY ═════════════════════

    public void setFrozen(boolean f) { frozen = f; if (f) setDeltaMovement(Vec3.ZERO); }
    public boolean isFrozen() { return frozen; }

    /** Centro de la esfera → posición de la entidad (la AABB 1.8³ se apoya en su base). */
    public void placeCenterAt(Vec3 center) {
        setPos(center.x, center.y - BALL_RADIUS, center.z);
        setDeltaMovement(Vec3.ZERO);
        lastTouchTeam = -1;
    }
    public Vec3 getCenter() { return getBoundingBox().getCenter(); }

    public java.util.UUID getLastToucherId() { return lastToucherId; }
    public String getLastToucherName() { return lastToucherName; }
    public int  getLastTouchTeam() { return lastTouchTeam; }
    public long getLastTouchTick() { return lastTouchTick; }
    public void setTrail(int idx)  { entityData.set(DATA_TRAIL, idx); }

    /** La cámara de balón activa esto cuando el coche/un bloque tapa el balón. */
    public void setClientXray(boolean on) { this.clientXray = on; }

    /** Contorno "rayos X": el outline de glowing se dibuja a través de bloques y entidades. */
    @Override
    public boolean isCurrentlyGlowing() {
        return level().isClientSide() ? clientXray || super.isCurrentlyGlowing() : super.isCurrentlyGlowing();
    }

    @Override public boolean isPickable() { return true; }
    @Override public float getPickRadius() { return (float) BALL_PICK_RADIUS; }   // hitbox ampliada al golpear      // se puede golpear con el brazo/armas

    /** Golpes de jugadores, flechas, mobs y explosiones empujan el balón (no se "destruye"). */
    @Override
    public boolean hurtServer(ServerLevel level, DamageSource source, float amount) {
        if (frozen) return false;
        Vec3 push = Vec3.ZERO;
        Entity direct = source.getDirectEntity();
        Entity attacker = source.getEntity();
        if (source.is(DamageTypeTags.IS_EXPLOSION) && source.getSourcePosition() != null) {
            push = ballCenter().subtract(source.getSourcePosition());
            push = new Vec3(push.x, Math.max(push.y, 0.2), push.z);
        } else if (direct != null && !(direct instanceof LivingEntity) && direct.getDeltaMovement().lengthSqr() > 1.0E-4) {
            push = direct.getDeltaMovement();                         // proyectil: sigue su trayectoria
        } else if (attacker != null) {
            push = attacker.getLookAngle();                           // golpe cuerpo a cuerpo: hacia donde mira
        }
        if (push.lengthSqr() < 1.0E-8) return false;
        double power = BALL_HIT_BASE + amount * BALL_HIT_PER_DAMAGE;
        setDeltaMovement(getDeltaMovement().add(push.normalize().scale(power)));
        return true;
    }
    @Override protected void readAdditionalSaveData(ValueInput in) { entityData.set(DATA_TRAIL, in.getInt("Trail").orElse(0)); }
    @Override protected void addAdditionalSaveData(ValueOutput out) { out.putInt("Trail", entityData.get(DATA_TRAIL)); }
}
