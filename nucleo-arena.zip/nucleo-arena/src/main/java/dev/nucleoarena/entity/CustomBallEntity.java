package dev.nucleoarena.entity;

import dev.nucleoarena.arena.MatchManager;
import dev.nucleoarena.physics.VecUtil;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import net.minecraft.world.phys.Vec3;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.List;

import static dev.nucleoarena.physics.PhysicsConstants.*;

/**
 * Núcleo energético (balón).
 *  - Física propia: gravedad 6.5 m/s², tope 60 m/s, rebote 60 %, sub-pasos anti-tunneling.
 *  - Colisión esfera-vs-OBB con los coches, con modificadores por zona de impacto.
 *  - Estela de partículas en cliente proporcional a la velocidad (>20 m/s).
 */
public class CustomBallEntity extends Entity {

    private static final EntityDataAccessor<Float>   DATA_SPEED = SynchedEntityData.defineId(CustomBallEntity.class, EntityDataSerializers.FLOAT);   // b/t
    private static final EntityDataAccessor<Integer> DATA_TRAIL = SynchedEntityData.defineId(CustomBallEntity.class, EntityDataSerializers.INT);

    /** Estelas personalizables (índice sincronizado). */
    private static final ParticleOptions[] TRAILS = {
            ParticleTypes.SOUL_FIRE_FLAME,   // 0 fuego azul
            ParticleTypes.ELECTRIC_SPARK,    // 1 energía
            ParticleTypes.END_ROD,           // 2 plasma blanco
            ParticleTypes.FLAME              // 3 magma
    };

    private enum Zone {
        FRONT_TOP(ZONE_TRANSFER_FRONT_TOP), SIDE_REAR(ZONE_TRANSFER_SIDE_REAR), BOTTOM(ZONE_TRANSFER_BOTTOM);
        final double transfer;
        Zone(double t) { transfer = t; }
    }

    // servidor
    private boolean frozen;
    private java.util.UUID lastToucherId;
    private String lastToucherName = "";
    private int groundTicks, climbTicks;
    private int lastTouchTeam = -1;
    private long lastTouchTick;
    // cliente
    private boolean clientXray;

    public CustomBallEntity(EntityType<? extends CustomBallEntity> type, Level level) {
        super(type, level);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder b) {
        b.define(DATA_SPEED, 0f);
        b.define(DATA_TRAIL, 0);
    }

    // ═════════════════════════════ TICK ═════════════════════════════

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide()) clientTick();
        else serverTick();
    }

    private void serverTick() {
        if (frozen) { setDeltaMovement(Vec3.ZERO); entityData.set(DATA_SPEED, 0f); return; }
        Vec3 v = getDeltaMovement();

        // Gravedad del mod + tope estricto de velocidad
        v = v.add(0.0, -GRAVITY, 0.0);
        v = VecUtil.clampLength(v, BALL_MAX_SPEED);

        // Coches cercanos (una consulta por tick; el barrido se hace por sub-pasos)
        List<VehicleEntity> cars = level().getEntitiesOfClass(VehicleEntity.class,
                getBoundingBox().inflate(v.length() + 2.5), VehicleEntity::isActiveCar);

        boolean groundContact = false;

        for (int i = 0; i < BALL_SUBSTEPS; i++) {
            Vec3 step = v.scale(1.0 / BALL_SUBSTEPS);
            Vec3 before = position();
            move(MoverType.SELF, step);
            Vec3 blocked = step.subtract(position().subtract(before));

            // A gran velocidad el balón rompe bloques blandos (nunca bedrock ni la cancha) y pierde energía
            if (blocked.lengthSqr() > 1.0E-9 && breakBlocks(v, blocked)) {
                v = v.scale(0.8);
                continue;
            }

            // Rodando por el suelo a buena velocidad: al llegar a una pared SUBE por ella en vez de rebotar
            boolean wallHit = Math.abs(blocked.x) > 1.0E-5 || Math.abs(blocked.z) > 1.0E-5;
            if (wallHit && (groundContact || groundTicks > 0)) {
                double hs = Math.hypot(v.x, v.z);
                if (hs >= BALL_CLIMB_MIN) {
                    double intoWall = Math.abs(Math.abs(blocked.x) > 1.0E-5 ? v.x : v.z);
                    v = new Vec3(Math.abs(blocked.x) > 1.0E-5 ? 0.0 : v.x, Math.max(v.y, 0.0) + intoWall * 0.95,
                                 Math.abs(blocked.z) > 1.0E-5 ? 0.0 : v.z);
                    climbTicks = 12;
                    continue;
                }
            }

            // Rebote por eje contra bloques: v' = -v · 0.6
            if (Math.abs(blocked.x) > 1.0E-5) v = new Vec3(-v.x * BALL_RESTITUTION, v.y, v.z);
            if (Math.abs(blocked.z) > 1.0E-5) v = new Vec3(v.x, v.y, -v.z * BALL_RESTITUTION);
            if (Math.abs(blocked.y) > 1.0E-5) {
                if (Math.abs(v.y) < BALL_REST_VN) v = new Vec3(v.x, 0.0, v.z);          // reposo: sin jitter
                else                              v = new Vec3(v.x, -v.y * BALL_RESTITUTION, v.z);
                if (blocked.y < 0) groundContact = true;                                  // intentaba bajar y chocó
            }

            for (VehicleEntity car : cars) v = collideWithCar(car, v);
            v = collideWithMobs(v);
            v = VecUtil.clampLength(v, BALL_MAX_SPEED);
        }

        if (groundContact) v = new Vec3(v.x * BALL_ROLL_FRICTION, v.y, v.z * BALL_ROLL_FRICTION);
        groundTicks = groundContact ? 3 : Math.max(0, groundTicks - 1);
        if (climbTicks > 0) {                         // trepando: casi sin gravedad mientras lleve velocidad; la fricción la frena
            climbTicks--;
            double sp = v.length();
            if (sp >= BALL_CLIMB_MIN * 0.6) {
                v = v.add(0.0, GRAVITY * (1.0 - BALL_CLIMB_GRAVITY), 0.0);        // compensa casi toda la gravedad
                v = v.scale(BALL_CLIMB_FRICTION);
                climbTicks = Math.max(climbTicks, 2);
            } else climbTicks = 0;                    // sin velocidad: vuelve la gravedad normal
        }

        setDeltaMovement(v);
        entityData.set(DATA_SPEED, (float) v.length());
    }

    // ═════════════════════ MOBS Y BLOQUES ═════════════════════

    /** El balón golpea mobs: daño según la velocidad relativa (mata a gran velocidad) y rebota. */
    private Vec3 collideWithMobs(Vec3 v) {
        if (!(level() instanceof ServerLevel sl)) return v;
        List<LivingEntity> mobs = sl.getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(BALL_MOB_REACH),
                e -> e.isAlive() && !(e instanceof Player) && !(e.getVehicle() instanceof VehicleEntity));
        for (LivingEntity m : mobs) {
            Vec3 toBall = ballCenter().subtract(m.getBoundingBox().getCenter());
            if (toBall.lengthSqr() < 1.0E-6) toBall = new Vec3(0, 1, 0);
            Vec3 n = toBall.normalize();                                  // del mob hacia el balón
            Vec3 rel = v.subtract(m.getDeltaMovement());
            double closing = -rel.dot(n);                                 // >0: el balón va hacia el mob
            if (closing <= 0.0) continue;
            double ms = closing * TPS;
            if (ms >= BALL_HURT_MIN_MS) {
                float dmg = (float) ((ms - BALL_HURT_MIN_MS) * BALL_HURT_PER_MS + 3.0);
                if (m.hurtServer(sl, sl.damageSources().generic(), dmg)) {
                    m.push(-n.x * closing * 0.8, 0.25, -n.z * closing * 0.8);
                }
            }
            v = v.add(n.scale(closing * (1.0 + BALL_RESTITUTION)));       // rebote
        }
        return v;
    }

    /** Rompe los bloques con los que acaba de chocar si va lo bastante rápido. @return true si rompió alguno. */
    private boolean breakBlocks(Vec3 v, Vec3 blocked) {
        double ms = v.length() * TPS;
        if (ms < BALL_BREAK_MIN_MS || !(level() instanceof ServerLevel sl)) return false;
        double maxHardness = (ms - 10.0) * BALL_BREAK_HARDNESS_PER_MS;
        var arena = MatchManager.arena();

        Vec3 dir = new Vec3(Math.signum(blocked.x), Math.signum(blocked.y), Math.signum(blocked.z));
        var box = getBoundingBox().inflate(0.05).expandTowards(dir.scale(0.3));
        boolean broke = false;
        for (BlockPos pos : BlockPos.betweenClosed(
                net.minecraft.util.Mth.floor(box.minX), net.minecraft.util.Mth.floor(box.minY), net.minecraft.util.Mth.floor(box.minZ),
                net.minecraft.util.Mth.floor(box.maxX), net.minecraft.util.Mth.floor(box.maxY), net.minecraft.util.Mth.floor(box.maxZ))) {
            BlockState st = sl.getBlockState(pos);
            if (st.isAir() || st.is(Blocks.BEDROCK)) continue;
            if (arena != null && arena.bounds().contains(Vec3.atCenterOf(pos))) continue;   // la cancha es intocable
            float hardness = st.getDestroySpeed(sl, pos);
            if (hardness < 0f || hardness > maxHardness) continue;                          // indestructibles / muy duros
            sl.destroyBlock(pos.immutable(), true);
            broke = true;
        }
        return broke;
    }

    // ═════════════════════ COLISIÓN ESFERA ↔ OBB (COCHE) ═════════════════════

    private Vec3 ballCenter() { return getBoundingBox().getCenter(); }

    private Vec3 collideWithCar(VehicleEntity car, Vec3 v) {
        Quaternionf q = car.getOrientation();
        Quaternionf inv = new Quaternionf(q).conjugate();

        // Centro del balón en el espacio local de la OBB
        Vector3f local = inv.transform(VecUtil.vec3f(ballCenter().subtract(car.obbCenter())), new Vector3f());
        Vector3f closest = new Vector3f(
                Mth.clamp(local.x, -OBB_HALF_X, OBB_HALF_X),
                Mth.clamp(local.y, -OBB_HALF_Y, OBB_HALF_Y),
                Mth.clamp(local.z, -OBB_HALF_Z, OBB_HALF_Z));
        Vector3f diff = new Vector3f(local).sub(closest);
        float dist = diff.length();

        Vector3f nLocal = new Vector3f();
        if (dist > 1.0E-5f) {
            if (dist >= BALL_RADIUS) return v;                              // sin contacto
            nLocal.set(diff).div(dist);
        } else {                                                            // centro dentro de la caja
            float px = OBB_HALF_X - Math.abs(local.x);
            float py = OBB_HALF_Y - Math.abs(local.y);
            float pz = OBB_HALF_Z - Math.abs(local.z);
            if (py <= px && py <= pz) nLocal.set(0, local.y >= 0 ? 1 : -1, 0);
            else if (px <= pz)        nLocal.set(local.x >= 0 ? 1 : -1, 0, 0);
            else                      nLocal.set(0, 0, local.z >= 0 ? 1 : -1);
            dist = 0f;
        }
        double penetration = BALL_RADIUS - dist;

        Vec3 n = VecUtil.rotate(q, VecUtil.vec(nLocal)).normalize();       // del coche hacia el balón
        setPos(position().add(n.scale(penetration)));                      // des-penetrar

        Vec3 carV = car.getVelocity();
        Vec3 rel = v.subtract(carV);
        double vn = rel.dot(n);
        if (vn >= 0.0) return v;                                           // ya se separan

        // Zona de impacto (en el espacio local del coche)
        Zone zone;
        if (nLocal.y < -0.5f)                         zone = Zone.BOTTOM;     // ruedas / bajos
        else if (nLocal.z > 0.5f || nLocal.y > 0.5f)  zone = Zone.FRONT_TOP;  // defensa o techo
        else                                          zone = Zone.SIDE_REAR;

        // FLIP RESET: contacto plano con el centro inferior (las 4 ruedas) del coche
        if (nLocal.y < -0.85f) car.grantFlipReset();

        Vec3 out = v;
        boolean roofContact = zone == Zone.FRONT_TOP && nLocal.y > 0.7f;

        if (roofContact && -vn < DRIBBLE_REST_VN) {
            // DRIBBLING: contacto casi en reposo sobre el techo → sin rebote + fricción que iguala velocidades
            out = out.add(n.scale(-vn));
            Vec3 tangentRel = VecUtil.tangent(rel, n);
            out = out.subtract(tangentRel.scale(DRIBBLE_FRICTION));
        } else {
            // Impulso: j = -(1 + e_eff)·vn,  e_eff = 0.6 · transfer(zona)
            double eEff = BALL_RESTITUTION * zone.transfer;
            double j = -(1.0 + eEff) * vn;
            out = out.add(n.scale(j));
            if (zone == Zone.BOTTOM) {                                      // amortigua también lo tangencial
                out = out.subtract(VecUtil.tangent(out.subtract(carV), n).scale(BOTTOM_TANGENT_DAMP));
            }
            car.addVelocity(n.scale(-j * CAR_RECOIL));
        }

        lastTouchTeam = car.getArenaTeamId();
        lastTouchTick = level().getGameTime();
        if (car.getFirstPassenger() instanceof Player p) { lastToucherId = p.getUUID(); lastToucherName = p.getName().getString(); }
        MatchManager.onBallTouch(car, v, out);
        return out;
    }

    // ═════════════════════ ESTELA (CLIENTE) ═════════════════════

    private final Quaternionf roll = new Quaternionf();
    private final Quaternionf prevRoll = new Quaternionf();

    /** Orientación visual (rodadura) interpolada, para el renderer. */
    public Quaternionf getRoll(float pt) { return new Quaternionf(prevRoll).slerp(roll, pt); }
    public boolean isClientXray() { return clientXray; }

    private void clientTick() {
        prevRoll.set(roll);
        Vec3 m = new Vec3(getX() - xo, getY() - yo, getZ() - zo);
        double len = m.length();
        if (len > 1.0E-4) {                               // rueda sobre el eje (UP × movimiento)
            Vec3 axis = new Vec3(0, 1, 0).cross(m).normalize();
            roll.premul(new Quaternionf().rotateAxis((float) (len / BALL_RADIUS),
                    (float) axis.x, (float) axis.y, (float) axis.z)).normalize();
        }
        double ms = entityData.get(DATA_SPEED) * TPS;
        if (ms <= BALL_TRAIL_MIN_MS) return;

        // t∈[0,1]: 0 a 20 m/s, 1 a 60 m/s → densidad y longitud crecen con la velocidad
        double t = Mth.clamp((ms - BALL_TRAIL_MIN_MS) / (BALL_TRAIL_FULL_MS - BALL_TRAIL_MIN_MS), 0.0, 1.0);
        Vec3 motion = new Vec3(getX() - xo, getY() - yo, getZ() - zo);
        if (motion.lengthSqr() < 1.0E-8) return;

        Vec3 back = motion.normalize().reverse();
        double length = Mth.lerp(t, 2.0, 14.0);                  // largo de la estela en bloques
        int samples = 2 + (int) (t * 8);                          // puntos a lo largo de la estela
        int perSample = 1 + (int) (t * 2);                        // densidad por punto
        ParticleOptions p = TRAILS[Mth.clamp(entityData.get(DATA_TRAIL), 0, TRAILS.length - 1)];
        Vec3 c = ballCenter();

        for (int s = 0; s < samples; s++) {
            double d = length * s / samples;
            for (int k = 0; k < perSample; k++) {
                double spread = 0.12 + 0.25 * (d / length);       // la estela se ensancha hacia atrás
                level().addParticle(p,
                        c.x + back.x * d + (random.nextDouble() - 0.5) * spread,
                        c.y + back.y * d + (random.nextDouble() - 0.5) * spread,
                        c.z + back.z * d + (random.nextDouble() - 0.5) * spread,
                        0.0, 0.0, 0.0);
            }
        }
    }

    // ═════════════════════ API / X-RAY ═════════════════════

    public void setFrozen(boolean f) { frozen = f; if (f) setDeltaMovement(Vec3.ZERO); }
    public boolean isFrozen() { return frozen; }

    /** Centro de la esfera → posición de la entidad (la AABB 1.8³ se apoya en su base). */
    public void placeCenterAt(Vec3 center) {
        setPos(center.x, center.y - BALL_RADIUS, center.z);
        setDeltaMovement(Vec3.ZERO);
        lastTouchTeam = -1;
    }
    public Vec3 getCenter() { return getBoundingBox().getCenter(); }

    public java.util.UUID getLastToucherId() { return lastToucherId; }
    public String getLastToucherName() { return lastToucherName; }
    public int  getLastTouchTeam() { return lastTouchTeam; }
    public long getLastTouchTick() { return lastTouchTick; }
    public void setTrail(int idx)  { entityData.set(DATA_TRAIL, idx); }

    /** La cámara de balón activa esto cuando el coche/un bloque tapa el balón. */
    public void setClientXray(boolean on) { this.clientXray = on; }

    /** Contorno "rayos X": el outline de glowing se dibuja a través de bloques y entidades. */
    @Override
    public boolean isCurrentlyGlowing() {
        return level().isClientSide() ? clientXray || super.isCurrentlyGlowing() : super.isCurrentlyGlowing();
    }

    @Override public boolean isPickable() { return true; }
    @Override public float getPickRadius() { return (float) BALL_PICK_RADIUS; }   // hitbox ampliada al golpear      // se puede golpear con el brazo/armas

    /** Golpes de jugadores, flechas, mobs y explosiones empujan el balón (no se "destruye"). */
    @Override
    public boolean hurtServer(ServerLevel level, DamageSource source, float amount) {
        if (frozen) return false;
        Vec3 push = Vec3.ZERO;
        Entity direct = source.getDirectEntity();
        Entity attacker = source.getEntity();
        if (source.is(DamageTypeTags.IS_EXPLOSION) && source.getSourcePosition() != null) {
            push = ballCenter().subtract(source.getSourcePosition());
            push = new Vec3(push.x, Math.max(push.y, 0.2), push.z);
        } else if (direct != null && !(direct instanceof LivingEntity) && direct.getDeltaMovement().lengthSqr() > 1.0E-4) {
            push = direct.getDeltaMovement();                         // proyectil: sigue su trayectoria
        } else if (attacker != null) {
            push = attacker.getLookAngle();                           // golpe cuerpo a cuerpo: hacia donde mira
        }
        if (push.lengthSqr() < 1.0E-8) return false;
        double power = BALL_HIT_BASE + amount * BALL_HIT_PER_DAMAGE;
        setDeltaMovement(getDeltaMovement().add(push.normalize().scale(power)));
        return true;
    }
    @Override protected void readAdditionalSaveData(ValueInput in) { entityData.set(DATA_TRAIL, in.getInt("Trail").orElse(0)); }
    @Override protected void addAdditionalSaveData(ValueOutput out) { out.putInt("Trail", entityData.get(DATA_TRAIL)); }
}
