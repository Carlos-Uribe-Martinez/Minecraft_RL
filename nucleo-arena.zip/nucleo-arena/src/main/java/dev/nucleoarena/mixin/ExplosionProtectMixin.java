package dev.nucleoarena.mixin;

import dev.nucleoarena.arena.MatchManager;
import net.minecraft.core.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;

/**
 * Las explosiones (TNT, creeper, ghast…) no destruyen la cancha: se quitan de la lista de bloques a destruir los
 * bloques de la arena. @Pseudo + require = 0: si la clase o el método cambian de nombre en 26.2, no pasa nada
 * (solo se pierde la protección) y el juego arranca igual.
 */
@Pseudo
@Mixin(targets = "net.minecraft.server.level.ServerExplosion")
public abstract class ExplosionProtectMixin {
    @Inject(method = "calculateExplodedPositions", at = @At("RETURN"), require = 0)
    private void nucleoarena$protectArena(CallbackInfoReturnable<List<BlockPos>> cir) {
        List<BlockPos> list = cir.getReturnValue();
        if (list != null) list.removeIf(MatchManager::isArenaBlock);
    }
}
