package dev.nucleoarena.input;

import dev.nucleoarena.NucleoArena;
import dev.nucleoarena.entity.VehicleEntity;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;

/**
 * Controles del jugador en UN tick de cliente.
 *
 * seq        número de secuencia creciente (lo usa la predicción para saber qué entrada ya procesó el servidor)
 * jumpPressed flanco latcheado en el cliente (KeyMapping.consumeClick): no se pierden taps < 50 ms
 * steer      +1 = izquierda, -1 = derecha
 * throttle   +1 = adelante,  -1 = reversa / freno
 */
public record VehicleInput(int seq, float throttle, float steer,
                           boolean jumpHeld, boolean jumpPressed,
                           boolean boost, boolean handbrake, boolean airRoll) {

    public static final VehicleInput NONE = new VehicleInput(-1, 0, 0, false, false, false, false, false);

    public VehicleInput sanitized() {
        return new VehicleInput(seq, Mth.clamp(throttle, -1f, 1f), Mth.clamp(steer, -1f, 1f),
                jumpHeld, jumpPressed, boost, handbrake, airRoll);
    }

    /** Misma entrada sin el flanco de salto (cuando el servidor repite la última entrada por falta de paquetes). */
    public VehicleInput withoutPress() {
        return jumpPressed ? new VehicleInput(seq, throttle, steer, jumpHeld, false, boost, handbrake, airRoll) : this;
    }

    public VehicleInput withPress() {
        return jumpPressed ? this : new VehicleInput(seq, throttle, steer, jumpHeld, true, boost, handbrake, airRoll);
    }

    // ───────────────────────── Red ─────────────────────────

    public record Payload(VehicleInput input) implements CustomPacketPayload {
        public static final Type<Payload> TYPE =
                new Type<>(Identifier.fromNamespaceAndPath(NucleoArena.MOD_ID, "vehicle_input"));

        public static final StreamCodec<RegistryFriendlyByteBuf, Payload> CODEC =
                StreamCodec.of(Payload::write, Payload::read);

        private static void write(RegistryFriendlyByteBuf buf, Payload p) {
            VehicleInput i = p.input;
            buf.writeInt(i.seq);
            buf.writeFloat(i.throttle);
            buf.writeFloat(i.steer);
            int flags = (i.jumpHeld ? 1 : 0) | (i.jumpPressed ? 2 : 0) | (i.boost ? 4 : 0)
                    | (i.handbrake ? 8 : 0) | (i.airRoll ? 16 : 0);
            buf.writeByte(flags);
        }

        private static Payload read(RegistryFriendlyByteBuf buf) {
            int seq = buf.readInt();
            float t = buf.readFloat();
            float s = buf.readFloat();
            int f = buf.readByte();
            return new Payload(new VehicleInput(seq, t, s,
                    (f & 1) != 0, (f & 2) != 0, (f & 4) != 0, (f & 8) != 0, (f & 16) != 0));
        }

        @Override public Type<? extends CustomPacketPayload> type() { return TYPE; }
    }

    /** Llamar desde el ModInitializer común (registra los dos sentidos de red). */
    public static void registerNetworking() {
        // 26.1+: playC2S() → serverboundPlay(), playS2C() → clientboundPlay()
        PayloadTypeRegistry.serverboundPlay().register(Payload.TYPE, Payload.CODEC);
        PayloadTypeRegistry.clientboundPlay().register(dev.nucleoarena.net.CarSnapshotPayload.TYPE,
                dev.nucleoarena.net.CarSnapshotPayload.CODEC);

        ServerPlayNetworking.registerGlobalReceiver(Payload.TYPE, (payload, ctx) -> {
            // Se ejecuta en el hilo del servidor.
            if (ctx.player().getVehicle() instanceof VehicleEntity car) {
                car.enqueueInput(payload.input().sanitized());
            }
        });
    }
}
