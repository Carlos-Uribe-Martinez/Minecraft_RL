package dev.nucleoarena;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

/**
 * Pruebas con el cubo de azufre como balón (aparte del balón del mod) y protección de armor stands:
 *  - golpes (puño, armas), flechas y explosiones EMPUJAN al cubo de azufre en vez de dañarlo (el fuego sí lo daña);
 *  - las explosiones no dañan a armor stands ni a cubos de azufre.
 * Los ids se comparan por texto para no depender de las clases de entidad de 26.2.
 */
public final class Football {
    private Football() {}

    private static final java.util.Map<java.util.UUID, java.util.UUID> CUBE_TO_BALL = new java.util.HashMap<>();

    public static void link(java.util.UUID cube, java.util.UUID ball) { CUBE_TO_BALL.put(cube, ball); }
    public static void unlink(java.util.UUID cube) { CUBE_TO_BALL.remove(cube); }

    private static String id(Entity e) {
        return BuiltInRegistries.ENTITY_TYPE.getKey(e.getType()).getPath();
    }

    public static boolean isSulfur(Entity e) { return id(e).equals("sulfur_cube"); }
    public static boolean isArmorStand(Entity e) { return id(e).equals("armor_stand"); }

    /** Empuje de un golpe, proyectil o explosión: misma regla que el balón del mod. */
    public static void push(LivingEntity e, DamageSource source, float amount) {
        Vec3 dir = Vec3.ZERO;
        Entity direct = source.getDirectEntity(), attacker = source.getEntity();
        if (source.is(DamageTypeTags.IS_EXPLOSION) && source.getSourcePosition() != null) {
            Vec3 d = e.getBoundingBox().getCenter().subtract(source.getSourcePosition());
            dir = new Vec3(d.x, Math.max(d.y, 0.25), d.z);
        } else if (direct != null && !(direct instanceof LivingEntity) && direct.getDeltaMovement().lengthSqr() > 1.0E-4) {
            dir = direct.getDeltaMovement();
        } else if (attacker != null) {
            dir = attacker.getLookAngle().add(0.0, 0.15, 0.0);
        }
        if (dir.lengthSqr() < 1.0E-8) return;
        double power = Math.min(2.6, 0.45 + amount * 0.10);
        Vec3 p = dir.normalize().scale(power);
        e.push(p.x, p.y, p.z);
    }

    public static void register() {
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
            if (source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) return true;   // /kill y vacío siempre funcionan
            boolean explosion = source.is(DamageTypeTags.IS_EXPLOSION);
            if (explosion && isArmorStand(entity)) return false;               // la TNT/creeper/ghast no tocan los armor stands
            if (isSulfur(entity)) {
                if (entity.level() instanceof net.minecraft.server.level.ServerLevel sl) {
                    java.util.UUID bid = CUBE_TO_BALL.get(entity.getUUID());
                    if (bid != null && sl.getEntity(bid) instanceof dev.nucleoarena.entity.CustomBallEntity b) {
                        b.hurtServer(sl, source, amount);                      // golpes al cubo = golpes al balón (física del mod)
                        return false;
                    }
                }
                if (source.is(DamageTypeTags.IS_FIRE)) return true;            // el fuego sí le hace daño
                push(entity, source, amount);                                  // el resto solo lo empuja
                return false;
            }
            return true;
        });
    }
}
