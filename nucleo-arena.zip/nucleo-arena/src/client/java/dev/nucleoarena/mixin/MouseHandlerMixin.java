package dev.nucleoarena.mixin;

import dev.nucleoarena.client.ArenaCamera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.MouseHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Engancha la cámara de arena a CADA FRAME (no solo a cada tick de 20 Hz): así el giro es fluido, sin "saltos".
 * MouseHandler.turnPlayer aplica el ratón a la vista una vez por frame; justo después la reajustamos.
 * Handler sin parámetros y require = 0: no depende de la firma y no puede impedir el arranque
 * (si el método no existe, ArenaCamera sigue funcionando por tick como respaldo).
 */
@Mixin(MouseHandler.class)
public abstract class MouseHandlerMixin {
    @Inject(method = "turnPlayer", at = @At("TAIL"), require = 0)
    private void nucleoarena$afterTurn(CallbackInfo ci) {
        ArenaCamera.frame(Minecraft.getInstance());
    }
}
