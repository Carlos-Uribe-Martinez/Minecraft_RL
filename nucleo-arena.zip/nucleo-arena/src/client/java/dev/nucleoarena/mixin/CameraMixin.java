package dev.nucleoarena.mixin;

import dev.nucleoarena.client.ArenaCamera;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.phys.Vec3;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Sobrescribe posición Y rotación COMPLETA (con roll) de la cámara cuando se conduce un vehículo.
 *
 * ⚠ Los nombres/firma de Camera.setup y de los campos privados varían entre versiones.
 *   Verifica con el mapeo de Mojang de tu versión exacta (en 26.x Camera conserva
 *   `rotation`, `forwards`, `up`, `left` y `setPosition(Vec3)`; si la firma de setup difiere,
 *   ajusta solo la lista de parámetros del inyector).
 */
@Mixin(Camera.class)
public abstract class CameraMixin {

    @Shadow private Quaternionf rotation;
    @Shadow private Vector3f forwards;
    @Shadow private Vector3f up;
    @Shadow private Vector3f left;
    @Shadow protected abstract void setPosition(Vec3 pos);

    @Inject(method = "setup", at = @At("TAIL"))
    private void nucleoarena$overrideCamera(BlockGetter level, Entity entity, boolean detached,
                                            boolean mirrored, float partialTick, CallbackInfo ci) {
        ArenaCamera.Pose pose = ArenaCamera.compute(Minecraft.getInstance(), partialTick);
        if (pose == null) return;

        this.setPosition(pose.pos());
        this.rotation.set(pose.rot());
        // Mantener coherentes los ejes que usa el culling/partículas/sonido
        this.forwards.set(0f, 0f, -1f).rotate(this.rotation);
        this.up.set(0f, 1f, 0f).rotate(this.rotation);
        this.left.set(-1f, 0f, 0f).rotate(this.rotation);
    }
}
