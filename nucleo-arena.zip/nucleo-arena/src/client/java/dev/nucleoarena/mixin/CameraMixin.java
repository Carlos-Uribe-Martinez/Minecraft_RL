package dev.nucleoarena.mixin;

import dev.nucleoarena.client.ArenaCamera;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.world.phys.Vec3;
import org.joml.Quaternionf;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Sobrescribe posición y rotación COMPLETA (con roll) de la cámara al conducir un vehículo.
 *
 * Versión a prueba de cambios de firma:
 *  - el inyector NO declara los parámetros de Camera.setup/update (solo CallbackInfo), así que
 *    funciona aunque Mojang cambie esa firma;
 *  - require = 0: si no encuentra el método, el juego arranca igual (solo se pierde la cámara);
 *  - sin @Shadow de campos: usa los accesores públicos (rotation(), getLookVector()...).
 */
@Mixin(Camera.class)
public abstract class CameraMixin {

    @Shadow protected abstract void setPosition(Vec3 pos);

    @Inject(method = {"setup", "update"}, at = @At("TAIL"), require = 0)
    private void nucleoarena$overrideCamera(CallbackInfo ci) {
        Minecraft mc = Minecraft.getInstance();
        float partialTick = mc.getDeltaTracker().getGameTimeDeltaPartialTick(true);
        ArenaCamera.Pose pose = ArenaCamera.compute(mc, partialTick);
        if (pose == null) return;

        Camera self = (Camera) (Object) this;
        this.setPosition(pose.pos());
        Quaternionf rotation = self.rotation();
        rotation.set(pose.rot());
        // Mantener coherentes los ejes que usa el culling/partículas/sonido
        self.getLookVector().set(0f, 0f, -1f).rotate(rotation);
        self.getUpVector().set(0f, 1f, 0f).rotate(rotation);
        self.getLeftVector().set(-1f, 0f, 0f).rotate(rotation);
    }
}
