package dev.nucleoarena.mixin;

import dev.nucleoarena.entity.VehicleEntity;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Bloquea el ratón mientras el jugador conduce: Entity.turn(yaw, pitch) es lo que aplica el movimiento del ratón
 * a la vista. La cámara la dirige ArenaCamera (detrás del coche o hacia el balón).
 * Sin parámetros en el handler y require = 0: no depende de la firma y no puede impedir el arranque.
 */
@Mixin(Entity.class)
public abstract class MouseLockMixin {
    @Inject(method = "turn", at = @At("HEAD"), cancellable = true, require = 0)
    private void nucleoarena$lockMouse(CallbackInfo ci) {
        if ((Object) this instanceof LocalPlayer p && p.getVehicle() instanceof VehicleEntity) ci.cancel();
    }
}
