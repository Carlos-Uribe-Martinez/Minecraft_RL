package dev.nucleoarena.client.render;

import net.minecraft.client.renderer.entity.state.EntityRenderState;

public class BoostPadRenderState extends EntityRenderState {
    public boolean large, ready;
}
