package dev.nucleoarena.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.nucleoarena.NucleoArena;
import dev.nucleoarena.entity.BoostPadEntity;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.resources.Identifier;

/** Célula de carga: placa oscura + núcleo que gira y brilla; apagado (gris) durante el enfriamiento. */
public class BoostPadRenderer extends EntityRenderer<BoostPadEntity, BoostPadRenderState> {
    private static final Identifier WHITE = Identifier.fromNamespaceAndPath(NucleoArena.MOD_ID, "textures/entity/white.png");

    public BoostPadRenderer(EntityRendererProvider.Context ctx) { super(ctx); }

    @Override public BoostPadRenderState createRenderState() { return new BoostPadRenderState(); }

    @Override
    public void extractRenderState(BoostPadEntity pad, BoostPadRenderState s, float pt) {
        super.extractRenderState(pad, s, pt);
        s.large = pad.isLarge();
        s.ready = pad.isReady();
    }

    @Override
    public void submit(BoostPadRenderState s, PoseStack ps, SubmitNodeCollector collector, CameraRenderState cam) {
        final float size = s.large ? 1.0f : 0.55f;
        final int core = s.ready ? (s.large ? 0xFFFFB020 : 0xFF40E0FF) : 0xFF555560;
        final int light = s.ready ? Boxes.FULL_BRIGHT : s.lightCoords;
        ps.pushPose();
        ps.mulPose(new org.joml.Quaternionf().rotationY(s.ageInTicks * 0.08f));
        collector.submitCustomGeometry(ps, RenderTypes.entityCutout(WHITE), (pose, vc) -> {
            Boxes.box(vc, pose, 0, 0.03f, 0, size * 1.15f, 0.03f, size * 1.15f, 0xFF22222A, s.lightCoords);   // placa
            float h = s.ready ? 0.08f + 0.03f * (float) Math.sin(s.ageInTicks * 0.2f) : 0.03f;
            Boxes.box(vc, pose, 0, 0.06f + h, 0, size * 0.6f, h, size * 0.6f, core, light);                    // núcleo
            if (s.large && s.ready) {
                Boxes.box(vc, pose, 0, 0.55f, 0, 0.08f, 0.5f, 0.08f, core, Boxes.FULL_BRIGHT);                 // pilar
            }
        });
        ps.popPose();
    }
}
