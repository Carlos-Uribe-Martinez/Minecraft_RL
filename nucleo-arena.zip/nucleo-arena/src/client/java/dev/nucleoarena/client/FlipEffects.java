package dev.nucleoarena.client;

import dev.nucleoarena.NucleoArena;
import dev.nucleoarena.entity.VehicleEntity;
import dev.nucleoarena.input.VehicleInput;
import dev.nucleoarena.physics.CarState;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;

/**
 * Efecto de velocidad al hacer un flip rápido en diagonal (o con air roll): el campo de visión se "estira" 1-2 s
 * y aparecen líneas radiales tipo anime (como en Rocket League).
 */
public final class FlipEffects {
    private FlipEffects() {}

    private static final double MIN_SPEED_MS = 14.0;       // m/s mínimos para activar el efecto
    private static final int FOV_EXTRA = 16;               // grados extra en el pico
    private static final float DURATION_TICKS = 32f;       // ≈ 1.6 s

    private static float timeLeft;
    private static boolean wasFlipping;
    private static Integer baseFov;                        // FOV del jugador antes del efecto
    private static long seed;

    public static void init() {
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath(NucleoArena.MOD_ID, "speed_lines"), FlipEffects::extract);
    }

    /** Cada tick conduciendo, tras simular la entrada local. */
    public static void tick(Minecraft mc, VehicleEntity car, VehicleInput in) {
        CarState s = car.clientState();
        boolean flipping = s.flipAnimTicks > 0;
        double ms = s.vel.length() * 20.0;
        boolean diagonal = (Math.abs(in.throttle()) > 0.1f && Math.abs(in.steer()) > 0.1f) || in.airRoll() || in.roll() != 0;
        if (flipping && !wasFlipping && ms >= MIN_SPEED_MS && diagonal) {
            timeLeft = DURATION_TICKS;
            seed = System.nanoTime();
            if (baseFov == null) baseFov = mc.options.fov().get();
        }
        wasFlipping = flipping;
        applyFov(mc);
    }

    public static void onNotDriving(Minecraft mc) {
        timeLeft = 0;
        wasFlipping = false;
        applyFov(mc);
    }

    private static float intensity() {
        float t = timeLeft / DURATION_TICKS;                   // 1 → 0
        return t <= 0 ? 0 : Mth.clamp(Math.min(t * 4f, 1f), 0f, 1f) * (t > 0.2f ? 1f : t / 0.2f);   // sube rápido, baja suave
    }

    private static void applyFov(Minecraft mc) {
        if (timeLeft > 0) timeLeft--;
        if (baseFov == null) return;
        if (timeLeft <= 0) {                                   // restaura el FOV original
            mc.options.fov().set(baseFov);
            baseFov = null;
            return;
        }
        mc.options.fov().set(Mth.clamp(baseFov + Math.round(FOV_EXTRA * intensity()), 30, 110));
    }

    private static void extract(GuiGraphicsExtractor g, DeltaTracker dt) {
        float k = intensity();
        if (k <= 0.01f) return;
        Minecraft mc = Minecraft.getInstance();
        int w = mc.getWindow().getGuiScaledWidth(), h = mc.getWindow().getGuiScaledHeight();
        float cx = w / 2f, cy = h / 2f, diag = (float) Math.hypot(cx, cy);
        int alpha = Math.round(150 * k);
        int color = (alpha << 24) | 0xFFFFFF;
        java.util.Random rnd = new java.util.Random(seed);
        int lines = 34;
        for (int i = 0; i < lines; i++) {
            double ang = (i + rnd.nextDouble() * 0.8) * (Math.PI * 2 / lines);
            float r0 = diag * (0.42f + rnd.nextFloat() * 0.18f);
            float r1 = diag * (0.78f + rnd.nextFloat() * 0.25f);
            int steps = Math.max(6, (int) ((r1 - r0) / 4f));
            for (int s = 0; s < steps; s++) {
                float r = r0 + (r1 - r0) * s / steps;
                int x = Math.round(cx + (float) Math.cos(ang) * r), y = Math.round(cy + (float) Math.sin(ang) * r * 0.62f);
                int sz = 1 + (s * 2 / steps);                  // la línea engorda hacia fuera
                g.fill(x, y, x + sz, y + sz, color);
            }
        }
    }
}
