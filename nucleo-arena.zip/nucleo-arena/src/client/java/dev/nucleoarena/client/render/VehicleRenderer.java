package dev.nucleoarena.client.render;

import dev.nucleoarena.physics.PhysicsConstants;
import com.mojang.blaze3d.vertex.PoseStack;
import dev.nucleoarena.NucleoArena;
import dev.nucleoarena.client.ArenaCamera;
import dev.nucleoarena.entity.VehicleEntity;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.resources.Identifier;
import net.minecraft.world.phys.Vec3;

/**
 * Dos modelos 3D low-poly horneados (CarMesh): NOMAD (Blue Lowpoly Car) y CARIBE (Fiat Uno); respaldo: cajas procedurales.
 * Local: x = izquierda, y = arriba, z = adelante; las ruedas tocan y = −0.8 (base de la caja de 1.6).
 *
 * ⚠ 26.2: SubmitNodeCollector / CameraRenderState / RenderTypes / EntityRenderer.submit son la API nueva de
 *   "submit"; si cambia un import o firma, este fichero y los otros dos renderers son los únicos afectados.
 */
public class VehicleRenderer extends EntityRenderer<VehicleEntity, VehicleRenderState> {
    /** Textura del coche + mapa PBR "_s" (metal liso) para shaders con soporte labPBR. */
    private static final Identifier CAR_METAL = Identifier.fromNamespaceAndPath(NucleoArena.MOD_ID, "textures/entity/car_metal.png");
    private static final Identifier WHITE = Identifier.fromNamespaceAndPath(NucleoArena.MOD_ID, "textures/entity/white.png");

    private static final int[] BODY   = { 0x2F6BFF, 0xFF8A1F };
    private static final int[] ACCENT = { 0xBFD4FF, 0xFFE0B8 };
    private static final int DARK = 0x1B1B22, GLASS = 0x6FB7D6, HUB = 0xCFCFD8;

    public VehicleRenderer(EntityRendererProvider.Context ctx) { super(ctx); }

    @Override public VehicleRenderState createRenderState() { return new VehicleRenderState(); }

    @Override
    public void extractRenderState(VehicleEntity car, VehicleRenderState s, float pt) {
        super.extractRenderState(car, s, pt);
        Vec3 center = car.getRenderCenter(pt);
        s.offX = (float) (center.x - s.x); s.offY = (float) (center.y - s.y); s.offZ = (float) (center.z - s.z);
        s.orientation.set(car.getRenderOrientation(pt));
        s.team = Math.max(0, Math.min(1, car.getArenaTeamId()));
        s.kind = car.getKind().ordinal();
        s.demolished = car.isDemolished();
        s.boosting = car.isBoosting();
        s.supersonic = car.isSupersonic();
        s.flipReady = car.isFlipReady();
        s.alpha = car.isLocalDriver() ? ArenaCamera.vehicleAlpha() : 1f;   // translúcido con la cámara de balón
    }

    @Override
    public void submit(VehicleRenderState s, PoseStack ps, SubmitNodeCollector collector, CameraRenderState cam) {
        if (s.demolished) return;
        ps.pushPose();
        ps.translate(s.offX, s.offY, s.offZ);
        ps.mulPose(s.orientation);
        ps.scale(PhysicsConstants.CAR_SCALE, PhysicsConstants.CAR_SCALE, PhysicsConstants.CAR_SCALE);   // coche al doble

        RenderType type = s.alpha < 0.99f ? RenderTypes.entityTranslucent(CAR_METAL) : RenderTypes.entityCutout(CAR_METAL);
        final int light = s.lightCoords;
        final float a = s.alpha;
        final int body = Boxes.argb(BODY[s.team], a), accent = Boxes.argb(ACCENT[s.team], a);
        final int dark = Boxes.argb(DARK, a), glass = Boxes.argb(GLASS, a), hub = Boxes.argb(HUB, a);
        final boolean nomad = s.kind == 0;
        final float flicker = 0.55f + 0.15f * (float) Math.sin(s.ageInTicks * 2.3f);

        collector.submitCustomGeometry(ps, type, (pose, vc) -> {
            CarMesh mesh = CarMesh.get(nomad ? "nomad" : "caribe");
            if (mesh != null) {                   // modelo 3D low-poly (glTF horneado)
                mesh.draw(vc, pose, BODY[s.team], a, light);
                drawExtras(vc, pose, s, a, flicker, light);
                return;
            }
            // Ruedas (comunes): neumático + buje
            for (int sx = -1; sx <= 1; sx += 2) for (int sz = -1; sz <= 1; sz += 2) {
                Boxes.box(vc, pose, sx * 0.56f, -0.5f, sz * 0.55f, 0.11f, 0.30f, 0.30f, dark, light);
                Boxes.box(vc, pose, sx * 0.64f, -0.5f, sz * 0.55f, 0.03f, 0.14f, 0.14f, hub, light);
            }
            if (nomad) {             // cuña baja con alerón (≈ Octane)
                Boxes.box(vc, pose, 0, -0.50f, 0.00f, 0.50f, 0.12f, 0.78f, body, light);    // chasis
                Boxes.box(vc, pose, 0, -0.42f, 0.66f, 0.46f, 0.06f, 0.16f, body, light);    // morro
                Boxes.box(vc, pose, 0, -0.30f, -0.05f, 0.40f, 0.12f, 0.36f, glass, light);  // cabina
                Boxes.box(vc, pose, 0, -0.17f, -0.05f, 0.36f, 0.02f, 0.30f, body, light);   // techo
                Boxes.box(vc, pose, 0.30f, -0.30f, -0.72f, 0.03f, 0.14f, 0.03f, dark, light);
                Boxes.box(vc, pose, -0.30f, -0.30f, -0.72f, 0.03f, 0.14f, 0.03f, dark, light);
                Boxes.box(vc, pose, 0, -0.15f, -0.76f, 0.52f, 0.02f, 0.10f, accent, light); // alerón
            } else {                 // hatchback cuadrado (≈ Fennec)
                Boxes.box(vc, pose, 0, -0.45f, 0.00f, 0.56f, 0.20f, 0.78f, body, light);    // chasis alto
                Boxes.box(vc, pose, 0, -0.16f, -0.10f, 0.50f, 0.12f, 0.52f, body, light);   // cabina
                Boxes.box(vc, pose, 0, -0.14f, -0.10f, 0.52f, 0.07f, 0.44f, glass, light);  // ventanas
                Boxes.box(vc, pose, 0.34f, -0.40f, 0.79f, 0.10f, 0.05f, 0.01f, accent, light);
                Boxes.box(vc, pose, -0.34f, -0.40f, 0.79f, 0.10f, 0.05f, 0.01f, accent, light);
            }
            drawExtras(vc, pose, s, a, flicker, light);
        });
        ps.popPose();
    }

    /** Llama del boost e indicador de salto (comunes a todos los modelos). */
    private static void drawExtras(com.mojang.blaze3d.vertex.VertexConsumer vc, PoseStack.Pose pose, VehicleRenderState s,
                                   float a, float flicker, int light) {
        if (s.boosting) {        // llama del boost
            Boxes.box(vc, pose, 0, -0.48f, -1.10f - flicker * 0.4f, 0.10f, 0.08f, flicker * 0.4f, Boxes.argb(0xFFB020, a), Boxes.FULL_BRIGHT);
            Boxes.box(vc, pose, 0, -0.48f, -1.05f - flicker * 0.2f, 0.05f, 0.04f, flicker * 0.25f, Boxes.argb(0xFFFFFF, a), Boxes.FULL_BRIGHT);
        }
        if (s.flipReady && !s.boosting) {   // indicador discreto de salto disponible
            Boxes.box(vc, pose, 0, -0.76f, 0, 0.05f, 0.015f, 0.05f, Boxes.argb(0x7CFF7C, a), Boxes.FULL_BRIGHT);
        }
    }
}
