package dev.nucleoarena.client;

import dev.nucleoarena.NucleoArena;
import dev.nucleoarena.net.StatsPayload;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.resources.Identifier;

import java.util.List;

/** Marcador con tecla (alterna mostrar/ocultar): una fila por jugador con goles, tiros, salvadas y demoliciones. */
public final class ScoreboardHud {
    private ScoreboardHud() {}

    private static boolean visible;
    private static StatsPayload data;

    public static void toggle() { visible = !visible; }
    public static void update(StatsPayload p) { data = p; }

    public static void init() {
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath(NucleoArena.MOD_ID, "scoreboard"), ScoreboardHud::extract);
    }

    private static void extract(GuiGraphicsExtractor g, DeltaTracker dt) {
        if (!visible || data == null) return;
        Minecraft mc = Minecraft.getInstance();
        var font = mc.font;
        List<StatsPayload.Row> rows = data.rows();

        int w = 290, rowH = 12;
        int h = 44 + rows.size() * rowH + 8;
        int x0 = mc.getWindow().getGuiScaledWidth() - w - 6, y0 = Math.max(10, (mc.getWindow().getGuiScaledHeight() - h) / 2 - 20);   // lateral derecho (sidebar)

        g.fill(x0, y0, x0 + w, y0 + h, 0xB0000000);
        String time = (data.overtime() ? "EXTRA +" : "") + (data.secondsLeft() / 60) + ":" + String.format("%02d", data.secondsLeft() % 60);
        String head = "AZUL " + data.scoreBlue() + "  -  " + data.scoreOrange() + " NARANJA   " + time;
        g.text(font, head, x0 + (w - font.width(head)) / 2, y0 + 6, 0xFFFFFFFF, true);

        int y = y0 + 24;
        g.text(font, "Jugador", x0 + 8, y, 0xFFAAAAAA, false);
        g.text(font, "G", x0 + 118, y, 0xFFAAAAAA, false);        // goles
        g.text(font, "A", x0 + 148, y, 0xFFAAAAAA, false);        // asistencias
        g.text(font, "S", x0 + 178, y, 0xFFAAAAAA, false);        // salvadas
        g.text(font, "T", x0 + 208, y, 0xFFAAAAAA, false);        // tiros a puerta
        g.text(font, "D", x0 + 238, y, 0xFFAAAAAA, false);        // demoliciones
        y += 14;
        for (StatsPayload.Row r : rows) {
            int c = r.team() == 0 ? 0xFF3C8CFF : 0xFFFF8C1E;
            g.text(font, r.name(), x0 + 8, y, c, false);
            g.text(font, String.valueOf(r.goals()),   x0 + 118, y, 0xFFFFFFFF, false);
            g.text(font, String.valueOf(r.assists()), x0 + 148, y, 0xFFFFFFFF, false);
            g.text(font, String.valueOf(r.saves()),   x0 + 178, y, 0xFFFFFFFF, false);
            g.text(font, String.valueOf(r.shots()),   x0 + 208, y, 0xFFFFFFFF, false);
            g.text(font, String.valueOf(r.demos()),   x0 + 238, y, 0xFFFFFFFF, false);
            y += rowH;
        }
    }
}
