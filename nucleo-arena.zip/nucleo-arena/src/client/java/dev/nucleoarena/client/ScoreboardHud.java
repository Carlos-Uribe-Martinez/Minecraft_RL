package dev.nucleoarena.client;

import dev.nucleoarena.NucleoArena;
import dev.nucleoarena.net.StatsPayload;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.resources.Identifier;

import java.util.List;

/** Marcador con tecla (alterna mostrar/ocultar): una fila por jugador con goles, tiros, salvadas y demoliciones. */
public final class ScoreboardHud {
    private ScoreboardHud() {}

    private static boolean visible;
    private static StatsPayload data;

    public static void toggle() { visible = !visible; }
    public static void update(StatsPayload p) { data = p; }

    public static void init() {
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath(NucleoArena.MOD_ID, "scoreboard"), ScoreboardHud::extract);
    }

    private static void extract(GuiGraphicsExtractor g, DeltaTracker dt) {
        if (!visible || data == null) return;
        Minecraft mc = Minecraft.getInstance();
        var font = mc.font;
        List<StatsPayload.Row> rows = data.rows();

        int w = 260, rowH = 12;
        int h = 44 + rows.size() * rowH + 8;
        int x0 = (mc.getWindow().getGuiScaledWidth() - w) / 2, y0 = 20;

        g.fill(x0, y0, x0 + w, y0 + h, 0xB0000000);
        String time = (data.overtime() ? "EXTRA +" : "") + (data.secondsLeft() / 60) + ":" + String.format("%02d", data.secondsLeft() % 60);
        String head = "AZUL " + data.scoreBlue() + "  -  " + data.scoreOrange() + " NARANJA   " + time;
        g.text(font, head, x0 + (w - font.width(head)) / 2, y0 + 6, 0xFFFFFFFF, true);

        int y = y0 + 24;
        g.text(font, "Jugador", x0 + 8, y, 0xFFAAAAAA, false);
        g.text(font, "Goles", x0 + 120, y, 0xFFAAAAAA, false);
        g.text(font, "Tiros", x0 + 160, y, 0xFFAAAAAA, false);
        g.text(font, "Salv.", x0 + 200, y, 0xFFAAAAAA, false);
        g.text(font, "Dem.", x0 + 234, y, 0xFFAAAAAA, false);
        y += 14;
        for (StatsPayload.Row r : rows) {
            int c = r.team() == 0 ? 0xFF3C8CFF : 0xFFFF8C1E;
            g.text(font, r.name(), x0 + 8, y, c, false);
            g.text(font, String.valueOf(r.goals()), x0 + 128, y, 0xFFFFFFFF, false);
            g.text(font, String.valueOf(r.shots()), x0 + 168, y, 0xFFFFFFFF, false);
            g.text(font, String.valueOf(r.saves()), x0 + 208, y, 0xFFFFFFFF, false);
            g.text(font, String.valueOf(r.demos()), x0 + 240, y, 0xFFFFFFFF, false);
            y += rowH;
        }
    }
}
