package dev.nucleoarena.client;

import dev.nucleoarena.NucleoArena;
import dev.nucleoarena.client.render.BallRenderer;
import dev.nucleoarena.client.render.BoostPadRenderer;
import dev.nucleoarena.client.render.VehicleRenderer;
import dev.nucleoarena.entity.VehicleEntity;
import dev.nucleoarena.net.CarSnapshotPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.renderer.entity.EntityRenderers;     // la guía oficial 26.2 registra así
import net.minecraft.world.entity.Entity;

public class NucleoArenaClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ClientInputHandler.init();

        EntityRenderers.register(NucleoArena.VEHICLE,   VehicleRenderer::new);
        EntityRenderers.register(NucleoArena.BALL,      BallRenderer::new);
        EntityRenderers.register(NucleoArena.BOOST_PAD, BoostPadRenderer::new);

        // Estado autoritativo del servidor → reconciliación de la predicción
        ClientPlayNetworking.registerGlobalReceiver(CarSnapshotPayload.TYPE, (payload, ctx) -> {
            var level = ctx.client().level;
            if (level == null) return;
            Entity e = level.getEntity(payload.entityId());
            if (e instanceof VehicleEntity car && car.isLocalDriver()) {
                car.onServerSnapshot(payload.ackSeq(), payload.state());
            }
        });
    }
}
