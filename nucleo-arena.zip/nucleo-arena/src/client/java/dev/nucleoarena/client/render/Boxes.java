package dev.nucleoarena.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.texture.OverlayTexture;

/**
 * Geometría procedural (cajas y esferas) escrita directo en un VertexConsumer de formato ENTITY.
 * Sombreado falso por cara (la luz es fija). Quads en sentido antihorario visto desde fuera.
 *
 * ⚠ API de vértices (addVertex/setColor/setUv/setOverlay/setLight/setNormal) estable hasta 26.1;
 *   26.2 reescribió VertexFormat: si algún setter falla, es aquí (un único sitio).
 */
public final class Boxes {
    private Boxes() {}

    public static final int FULL_BRIGHT = 0xF000F0;

    public static int argb(int rgb, float alpha) {
        return (Math.round(Math.max(0f, Math.min(1f, alpha)) * 255f) << 24) | (rgb & 0xFFFFFF);
    }

    static int shade(int argb, float f) {
        int a = argb >>> 24, r = (int) (((argb >> 16) & 255) * f), g = (int) (((argb >> 8) & 255) * f), b = (int) ((argb & 255) * f);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    static void v(VertexConsumer vc, PoseStack.Pose p, float x, float y, float z, int c, int light,
                          float nx, float ny, float nz) {
        vc.addVertex(p, x, y, z).setColor(c).setUv(0.5f, 0.5f)
          .setOverlay(OverlayTexture.NO_OVERLAY).setLight(light).setNormal(p, nx, ny, nz);
    }

    /** Caja centrada en (cx,cy,cz) con semiejes (hx,hy,hz). */
    public static void box(VertexConsumer vc, PoseStack.Pose p, float cx, float cy, float cz,
                           float hx, float hy, float hz, int argb, int light) {
        float x0 = cx - hx, x1 = cx + hx, y0 = cy - hy, y1 = cy + hy, z0 = cz - hz, z1 = cz + hz;
        int top = argb, side = shade(argb, 0.82f), fb = shade(argb, 0.72f), bot = shade(argb, 0.5f);
        // +Y
        v(vc,p,x0,y1,z1,top,light,0,1,0); v(vc,p,x1,y1,z1,top,light,0,1,0); v(vc,p,x1,y1,z0,top,light,0,1,0); v(vc,p,x0,y1,z0,top,light,0,1,0);
        // -Y
        v(vc,p,x0,y0,z0,bot,light,0,-1,0); v(vc,p,x1,y0,z0,bot,light,0,-1,0); v(vc,p,x1,y0,z1,bot,light,0,-1,0); v(vc,p,x0,y0,z1,bot,light,0,-1,0);
        // +Z
        v(vc,p,x0,y0,z1,fb,light,0,0,1); v(vc,p,x1,y0,z1,fb,light,0,0,1); v(vc,p,x1,y1,z1,fb,light,0,0,1); v(vc,p,x0,y1,z1,fb,light,0,0,1);
        // -Z
        v(vc,p,x1,y0,z0,fb,light,0,0,-1); v(vc,p,x0,y0,z0,fb,light,0,0,-1); v(vc,p,x0,y1,z0,fb,light,0,0,-1); v(vc,p,x1,y1,z0,fb,light,0,0,-1);
        // +X
        v(vc,p,x1,y0,z1,side,light,1,0,0); v(vc,p,x1,y0,z0,side,light,1,0,0); v(vc,p,x1,y1,z0,side,light,1,0,0); v(vc,p,x1,y1,z1,side,light,1,0,0);
        // -X
        v(vc,p,x0,y0,z0,side,light,-1,0,0); v(vc,p,x0,y0,z1,side,light,-1,0,0); v(vc,p,x0,y1,z1,side,light,-1,0,0); v(vc,p,x0,y1,z0,side,light,-1,0,0);
    }

    /** Esfera UV (lat × lon) con casillas alternas de dos colores. */
    public static void sphere(VertexConsumer vc, PoseStack.Pose p, float r, int lat, int lon,
                              int colorA, int colorB, int light) {
        for (int i = 0; i < lat; i++) {
            double t0 = Math.PI * i / lat - Math.PI / 2, t1 = Math.PI * (i + 1) / lat - Math.PI / 2;
            for (int j = 0; j < lon; j++) {
                double a0 = 2 * Math.PI * j / lon, a1 = 2 * Math.PI * (j + 1) / lon;
                int c = ((i + j) & 1) == 0 ? colorA : colorB;
                sv(vc, p, r, t0, a0, c, light); sv(vc, p, r, t0, a1, c, light);
                sv(vc, p, r, t1, a1, c, light); sv(vc, p, r, t1, a0, c, light);
            }
        }
    }

    private static void sv(VertexConsumer vc, PoseStack.Pose p, float r, double t, double a, int c, int light) {
        float nx = (float) (Math.cos(t) * Math.cos(a)), ny = (float) Math.sin(t), nz = (float) (Math.cos(t) * Math.sin(a));
        v(vc, p, nx * r, ny * r, nz * r, c, light, nx, ny, nz);
    }

    /** Esfera para pasadas de formato "posición + color" (silueta X-Ray). Sin UV/normal/luz. */
    public static void sphereFlat(VertexConsumer vc, PoseStack.Pose p, float r, int lat, int lon, int argb) {
        for (int i = 0; i < lat; i++) {
            double t0 = Math.PI * i / lat - Math.PI / 2, t1 = Math.PI * (i + 1) / lat - Math.PI / 2;
            for (int j = 0; j < lon; j++) {
                double a0 = 2 * Math.PI * j / lon, a1 = 2 * Math.PI * (j + 1) / lon;
                fv(vc, p, r, t0, a0, argb); fv(vc, p, r, t0, a1, argb); fv(vc, p, r, t1, a1, argb); fv(vc, p, r, t1, a0, argb);
            }
        }
    }

    private static void fv(VertexConsumer vc, PoseStack.Pose p, float r, double t, double a, int argb) {
        vc.addVertex(p, (float) (Math.cos(t) * Math.cos(a)) * r, (float) Math.sin(t) * r,
                (float) (Math.cos(t) * Math.sin(a)) * r).setColor(argb);
    }
}
