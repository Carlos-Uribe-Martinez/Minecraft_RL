package dev.nucleoarena.client;

import dev.nucleoarena.entity.CustomBallEntity;
import dev.nucleoarena.entity.VehicleEntity;
import dev.nucleoarena.physics.VecUtil;
import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.joml.Quaternionf;

/**
 * Cámara de arena SIN tocar la clase Camera (su API cambió en 26.x): se dirige la VISTA del jugador cada tick
 * y la cámara vanilla en tercera persona trasera se coloca sola detrás de él.
 *
 *   RIGID: mira exactamente hacia donde apunta el coche → siempre centrada detrás.
 *   BALL : mira del coche hacia el balón (cámara de balón de Rocket League) → el balón queda centrado.
 *
 * El ratón queda bloqueado por MouseLockMixin. F5 (cambiar perspectiva) alterna BALL / RIGID mientras se
 * conduce; la tecla "camera" (C) hace lo mismo.
 */
public final class ArenaCamera {
    private ArenaCamera() {}

    public enum Mode { BALL, RIGID }

    private static final float RIGID_PITCH_BIAS = 10f;     // grados hacia abajo para ver el coche
    private static final float BALL_PITCH_BIAS  = 6f;
    private static final float BALL_FOLLOW      = 0.65f;   // 1 = clavada al balón
    private static final float RIGID_FOLLOW     = 1.0f;    // 1 = rígida al coche

    private static Mode mode = Mode.BALL;
    private static boolean wasDriving;
    private static CustomBallEntity cachedBall;

    public static void toggleMode() { mode = mode == Mode.BALL ? Mode.RIGID : Mode.BALL; }

    /** El coche ya no cambia de transparencia (la cámara no baja bajo el coche). */
    public static float vehicleAlpha() { return 1f; }

    public static void onNotDriving() {
        wasDriving = false;
        if (cachedBall != null) cachedBall.setClientXray(false);
    }

    /** Se llama cada tick de cliente mientras el jugador conduce. */
    public static void tick(Minecraft mc, VehicleEntity car) {
        var player = mc.player;
        if (player == null || mc.level == null) return;

        // F5 cambia la perspectiva de vanilla: lo convertimos en "cambiar cámara de arena".
        if (!wasDriving) {
            wasDriving = true;
        } else if (mc.options.getCameraType() != CameraType.THIRD_PERSON_BACK) {
            toggleMode();
        }
        mc.options.setCameraType(CameraType.THIRD_PERSON_BACK);

        Vec3 carCenter = car.getRenderCenter(1.0f);
        CustomBallEntity ball = findBall(mc, car);

        float targetYaw, targetPitch, follow;
        if (mode == Mode.BALL && ball != null) {
            Vec3 dir = ball.getCenter().subtract(carCenter);
            if (dir.lengthSqr() < 1.0E-4) dir = new Vec3(0, 0, 1);
            double horiz = Math.sqrt(dir.x * dir.x + dir.z * dir.z);
            targetYaw = (float) (Mth.atan2(-dir.x, dir.z) * Mth.RAD_TO_DEG);
            targetPitch = Mth.clamp((float) (-Mth.atan2(dir.y, horiz) * Mth.RAD_TO_DEG) * 0.8f + BALL_PITCH_BIAS, -35f, 70f);
            follow = BALL_FOLLOW;
        } else {
            Quaternionf q = car.getRenderOrientation(1.0f);
            Vec3 f = VecUtil.rotate(q, VecUtil.FORWARD);
            targetYaw = (float) (Mth.atan2(-f.x, f.z) * Mth.RAD_TO_DEG);
            targetPitch = Mth.clamp((float) Math.toDegrees(-Math.asin(Mth.clamp(f.y, -1.0, 1.0))) * 0.6f + RIGID_PITCH_BIAS, -50f, 60f);
            follow = RIGID_FOLLOW;
        }

        // Giro por el camino corto y continuo (sin saltos de ±180°); xRotO/yRotO = interpolación suave entre ticks
        float y = player.getYRot();
        float x = player.getXRot();
        player.yRotO = y;
        player.xRotO = x;
        player.setYRot(y + Mth.wrapDegrees(targetYaw - y) * follow);
        player.setXRot(x + (targetPitch - x) * follow);

        updateXray(mc, car, ball, carCenter);
    }

    /** Contorno "rayos X" del balón si un bloque o el propio coche lo tapan (posición de cámara aproximada). */
    private static void updateXray(Minecraft mc, VehicleEntity car, CustomBallEntity ball, Vec3 carCenter) {
        if (ball == null) return;
        Vec3 look = mc.player.getLookAngle();
        Vec3 camPos = carCenter.subtract(look.scale(4.0)).add(0, 1.0, 0);
        Vec3 ballPos = ball.getCenter();
        boolean blockedByBlock = mc.level.clip(new ClipContext(camPos, ballPos,
                ClipContext.Block.VISUAL, ClipContext.Fluid.NONE, mc.player)).getType() != HitResult.Type.MISS;
        boolean blockedByCar = car.getBoundingBox().inflate(0.15).clip(camPos, ballPos).isPresent();
        ball.setClientXray(blockedByBlock || blockedByCar);
    }

    private static CustomBallEntity findBall(Minecraft mc, VehicleEntity car) {
        if (cachedBall != null && !cachedBall.isRemoved()) return cachedBall;
        var list = mc.level.getEntitiesOfClass(CustomBallEntity.class, car.getBoundingBox().inflate(200));
        cachedBall = list.isEmpty() ? null : list.get(0);
        return cachedBall;
    }
}
