package dev.nucleoarena.client;

import dev.nucleoarena.entity.CustomBallEntity;
import dev.nucleoarena.entity.VehicleEntity;
import dev.nucleoarena.physics.VecUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.joml.Quaternionf;

/**
 * Dos cámaras de arena. Calcula una Pose (posición + orientación cámara→mundo) que el
 * CameraMixin aplica sobre la Camera de Minecraft al final de Camera.setup().
 *
 * RIGID  (cámara estática respecto al coche):
 *     Va rígidamente unida a la orientación COMPLETA del coche (incluye roll): el coche se ve
 *     siempre igual en pantalla, el suelo (del coche) abajo y el techo arriba.
 *
 * BALL   (cámara al balón):
 *     Libre en rotación pero siempre mirando al balón. Cuando el balón está por encima del
 *     coche, la cámara baja por debajo del coche (línea coche→balón prolongada hacia atrás),
 *     el coche se vuelve translúcido (vehicleAlpha()) y el suelo se "ve a través" gracias al
 *     bloque de arena de una sola cara (ver ARQUITECTURA.md). Si algo tapa el balón, este
 *     recibe contorno X-Ray.
 */
public final class ArenaCamera {
    private ArenaCamera() {}

    public enum Mode { BALL, RIGID }
    public record Pose(Vec3 pos, Quaternionf rot) {}

    // Ajustes RIGID
    private static final double RIGID_BACK = 5.5, RIGID_UP = 1.7;
    private static final float  RIGID_TILT = (float) Math.toRadians(8);
    // Ajustes BALL
    private static final double BALL_BACK_LOW = 6.0, BALL_BACK_HIGH = 5.0;
    private static final double BALL_H_LOW = 1.8,  BALL_H_HIGH = -2.2;       // + sobre el coche / − bajo el coche
    private static final double ELEV_LOW = Math.toRadians(25), ELEV_HIGH = Math.toRadians(60);
    private static final float  GHOST_MIN_ALPHA = 0.22f;

    private static Mode mode = Mode.BALL;
    private static Vec3 smoothPos;
    private static float vehicleAlpha = 1f;
    private static CustomBallEntity cachedBall;

    public static void toggleMode() {
        mode = mode == Mode.BALL ? Mode.RIGID : Mode.BALL;
        smoothPos = null;
    }

    /** Alpha (1 = opaco) que el renderer del coche debe aplicar este frame. */
    public static float vehicleAlpha() { return vehicleAlpha; }

    /** @return pose a aplicar, o null si el jugador no conduce (la cámara vanilla manda). */
    public static Pose compute(Minecraft mc, float pt) {
        if (mc.player == null || mc.level == null || !(mc.player.getVehicle() instanceof VehicleEntity car)) {
            vehicleAlpha = 1f;
            if (cachedBall != null) cachedBall.setClientXray(false);
            return null;
        }
        Vec3 carCenter = car.getRenderCenter(pt);
        CustomBallEntity ball = findBall(mc, car);

        Pose pose;
        if (mode == Mode.RIGID || ball == null) {
            pose = rigid(car, carCenter, pt);
            vehicleAlpha = 1f;
        } else {
            pose = ballCam(car, carCenter, ball, pt);
        }
        updateXray(mc, car, ball, pose.pos());
        return pose;
    }

    // ───────────────────────── RIGID ─────────────────────────

    private static Pose rigid(VehicleEntity car, Vec3 center, float pt) {
        Quaternionf q = car.getRenderOrientation(pt);
        Vec3 pos = center.add(VecUtil.rotate(q, new Vec3(0, RIGID_UP, -RIGID_BACK)));
        // Cámara de MC mira a −Z local: rotateY(π) la alinea con el +Z (adelante) del coche
        Quaternionf rot = new Quaternionf(q).rotateY((float) Math.PI).rotateX(-RIGID_TILT);
        smoothPos = null;
        return new Pose(pos, rot);
    }

    // ───────────────────────── BALL ─────────────────────────

    private static Pose ballCam(VehicleEntity car, Vec3 carCenter, CustomBallEntity ball, float pt) {
        Vec3 ballPos = ball.getPosition(pt).add(0, ball.getBbHeight() / 2.0, 0);
        Vec3 dir = ballPos.subtract(carCenter);
        if (dir.lengthSqr() < 1.0E-4) dir = new Vec3(0, 0, 1);
        dir = dir.normalize();

        // k = 0 (balón a nivel) … 1 (balón muy por encima del coche)
        double elev = Math.asin(Mth.clamp(dir.y, -1.0, 1.0));
        double k = smoothstep(ELEV_LOW, ELEV_HIGH, elev);

        double back   = Mth.lerp(k, BALL_BACK_LOW, BALL_BACK_HIGH);
        double height = Mth.lerp(k, BALL_H_LOW, BALL_H_HIGH);
        Vec3 target = carCenter.subtract(dir.scale(back)).add(0, height, 0);   // con k alto queda DEBAJO del coche

        smoothPos = smoothPos == null ? target : smoothPos.lerp(target, 0.35);
        Vec3 pos = smoothPos;

        // Mirar al balón (sin roll)
        Vec3 look = ballPos.subtract(pos);
        double horiz = Math.sqrt(look.x * look.x + look.z * look.z);
        float yaw   = (float) (Mth.atan2(-look.x, look.z) * Mth.RAD_TO_DEG);
        float pitch = (float) (-Mth.atan2(look.y, horiz) * Mth.RAD_TO_DEG);
        Quaternionf rot = new Quaternionf().rotationYXZ(
                (float) Math.PI - yaw * Mth.DEG_TO_RAD, -pitch * Mth.DEG_TO_RAD, 0f);   // igual que Camera.setRotation

        // Coche translúcido cuando la cámara está bajo él / el balón está arriba
        float alpha = (float) Mth.lerp(k, 1.0, GHOST_MIN_ALPHA);
        if (pos.distanceTo(carCenter) < 2.2) alpha = Math.min(alpha, 0.35f);
        vehicleAlpha = alpha;

        return new Pose(pos, rot);
    }

    // ───────────────────────── X-RAY ─────────────────────────

    /** Contorno "rayos X" del balón si un bloque o el propio coche opaco lo tapan. */
    private static void updateXray(Minecraft mc, VehicleEntity car, CustomBallEntity ball, Vec3 camPos) {
        if (ball == null) return;
        Vec3 ballPos = ball.getBoundingBox().getCenter();
        boolean blockedByBlock = mc.level.clip(new ClipContext(camPos, ballPos,
                ClipContext.Block.VISUAL, ClipContext.Fluid.NONE, mc.player)).getType() != HitResult.Type.MISS;
        boolean blockedByCar = vehicleAlpha > 0.5f
                && car.getBoundingBox().inflate(0.15).clip(camPos, ballPos).isPresent();
        ball.setClientXray(blockedByBlock || blockedByCar);
    }

    private static CustomBallEntity findBall(Minecraft mc, VehicleEntity car) {
        if (cachedBall != null && !cachedBall.isRemoved()) return cachedBall;
        var list = mc.level.getEntitiesOfClass(CustomBallEntity.class, car.getBoundingBox().inflate(200));
        cachedBall = list.isEmpty() ? null : list.get(0);
        return cachedBall;
    }

    private static double smoothstep(double a, double b, double x) {
        double t = Mth.clamp((x - a) / (b - a), 0.0, 1.0);
        return t * t * (3.0 - 2.0 * t);
    }
}
