package dev.nucleoarena.client;

import dev.nucleoarena.entity.CustomBallEntity;
import dev.nucleoarena.entity.VehicleEntity;
import dev.nucleoarena.physics.VecUtil;
import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.joml.Quaternionf;

/**
 * Cámara de arena sobre la cámara VANILLA de tercera persona (sin tocar la clase Camera).
 *
 * Cada FRAME (MouseHandlerMixin) se fija la vista del jugador = base + "mirada libre":
 *   · base RIGID: hacia donde apunta el coche · base BALL: del coche hacia el balón (Rocket League);
 *   · mirada libre: el ratón / palanca desvía la cámara hasta ±LOOK_YAW a los lados y ±LOOK_PITCH arriba/abajo,
 *     y al soltarlo vuelve suavemente al centro.
 * F5 (cambiar perspectiva) alterna BALL / RIGID mientras se conduce.
 */
public final class ArenaCamera {
    private ArenaCamera() {}

    public enum Mode { BALL, RIGID }

    private static final float LOOK_YAW   = 90f;      // máx. giro libre a cada lado
    private static final float LOOK_PITCH = 50f;      // máx. arriba / abajo
    private static final float RETURN_RATE = 7.0f;    // 1/s: velocidad de regreso al centro al soltar
    private static final float IDLE_BEFORE_RETURN = 0.10f;
    private static final float RIGID_PITCH_BIAS = 10f;
    private static final float BALL_PITCH_BIAS  = 6f;
    private static final float BALL_FOLLOW_RATE = 22f; // 1/s: seguimiento del balón (más alto = más pegado)

    private static Mode mode = Mode.BALL;
    private static boolean wasDriving;
    private static CustomBallEntity cachedBall;

    private static float lookYaw, lookPitch;          // desvío libre actual
    private static float lastSetYaw, lastSetPitch;    // última vista que fijamos
    private static float smoothYaw, smoothPitch;      // base suavizada (modo balón)
    private static boolean primed;
    private static long lastNanos;
    private static long lastFrameNanos;

    public static void toggleMode() { mode = mode == Mode.BALL ? Mode.RIGID : Mode.BALL; }
    public static float vehicleAlpha() { return 1f; }

    public static void onNotDriving() {
        wasDriving = false;
        primed = false;
        lookYaw = lookPitch = 0f;
        if (cachedBall != null) cachedBall.setClientXray(false);
    }

    /** Cada tick de cliente: F5 + cámara tercera persona + respaldo si no hay actualización por frame. */
    public static void tick(Minecraft mc, VehicleEntity car) {
        if (mc.player == null || mc.level == null) return;
        if (!wasDriving) {
            wasDriving = true;
        } else if (mc.options.getCameraType() != CameraType.THIRD_PERSON_BACK) {
            toggleMode();                                       // F5 pulsado
        }
        mc.options.setCameraType(CameraType.THIRD_PERSON_BACK);

        if (System.nanoTime() - lastFrameNanos > 120_000_000L)  // el hook por frame no funciona: actualiza aquí
            update(mc, car, 0.05f);
        updateXray(mc, car);
    }

    /** Cada frame, desde MouseHandlerMixin. */
    public static void frame(Minecraft mc) {
        if (mc.player == null || !(mc.player.getVehicle() instanceof VehicleEntity car) || !wasDriving) return;
        long now = System.nanoTime();
        float dt = lastNanos == 0 ? 0.016f : Mth.clamp((now - lastNanos) / 1.0E9f, 0.001f, 0.1f);
        lastNanos = now;
        lastFrameNanos = now;
        update(mc, car, dt);
    }

    private static void update(Minecraft mc, VehicleEntity car, float dt) {
        var player = mc.player;
        float pt = mc.getDeltaTracker().getGameTimeDeltaPartialTick(false);
        Vec3 carCenter = car.getRenderCenter(pt);
        CustomBallEntity ball = findBall(mc, car);

        // ── Mirada libre: lo que el ratón movió desde la última vez que fijamos la vista ──
        if (!primed) { lastSetYaw = player.getYRot(); lastSetPitch = player.getXRot(); primed = true; }
        float dy = Mth.wrapDegrees(player.getYRot() - lastSetYaw);
        float dp = player.getXRot() - lastSetPitch;
        boolean moving = Math.abs(dy) + Math.abs(dp) > 0.01f;
        lookYaw   = Mth.clamp(lookYaw + dy, -LOOK_YAW, LOOK_YAW);
        lookPitch = Mth.clamp(lookPitch + dp, -LOOK_PITCH, LOOK_PITCH);
        if (moving) idle = 0f; else idle += dt;
        if (idle > IDLE_BEFORE_RETURN) {                        // soltó el ratón/palanca → vuelve al centro
            float k = (float) Math.exp(-RETURN_RATE * dt);
            lookYaw *= k; lookPitch *= k;
            if (Math.abs(lookYaw) < 0.05f) lookYaw = 0f;
            if (Math.abs(lookPitch) < 0.05f) lookPitch = 0f;
        }

        // ── Base de la cámara ──
        float baseYaw, basePitch;
        if (mode == Mode.BALL && ball != null) {
            Vec3 ballPos = ball.getPosition(pt).add(0, ball.getBbHeight() * 0.5, 0);
            Vec3 dir = ballPos.subtract(carCenter);
            if (dir.lengthSqr() < 1.0E-4) dir = new Vec3(0, 0, 1);
            double horiz = Math.sqrt(dir.x * dir.x + dir.z * dir.z);
            float ty = (float) (Mth.atan2(-dir.x, dir.z) * Mth.RAD_TO_DEG);
            float tp = Mth.clamp((float) (-Mth.atan2(dir.y, horiz) * Mth.RAD_TO_DEG) * 0.8f + BALL_PITCH_BIAS, -35f, 70f);
            float k = 1f - (float) Math.exp(-BALL_FOLLOW_RATE * dt);
            smoothYaw += Mth.wrapDegrees(ty - smoothYaw) * k;
            smoothPitch += (tp - smoothPitch) * k;
            baseYaw = smoothYaw; basePitch = smoothPitch;
        } else {
            Quaternionf q = car.getRenderOrientation(pt);
            Vec3 f = VecUtil.rotate(q, VecUtil.FORWARD);
            baseYaw = (float) (Mth.atan2(-f.x, f.z) * Mth.RAD_TO_DEG);
            basePitch = Mth.clamp((float) Math.toDegrees(-Math.asin(Mth.clamp(f.y, -1.0, 1.0))) * 0.6f + RIGID_PITCH_BIAS, -50f, 60f);
            smoothYaw = baseYaw; smoothPitch = basePitch;
        }

        // ── Fijar la vista (continua, sin saltos de ±180°; yRotO = yRot ⇒ sin interpolación de tick) ──
        float wantYaw = baseYaw + lookYaw;
        float newYaw = lastSetYaw + Mth.wrapDegrees(wantYaw - lastSetYaw);
        float newPitch = Mth.clamp(basePitch + lookPitch, -89f, 89f);
        player.setYRot(newYaw);   player.yRotO = newYaw;
        player.setXRot(newPitch); player.xRotO = newPitch;
        lastSetYaw = newYaw;
        lastSetPitch = newPitch;
    }
    private static float idle;

    /** Contorno "rayos X" del balón si un bloque o el propio coche lo tapan (posición de cámara aproximada). */
    private static void updateXray(Minecraft mc, VehicleEntity car) {
        CustomBallEntity ball = findBall(mc, car);
        if (ball == null) return;
        Vec3 look = mc.player.getLookAngle();
        Vec3 camPos = car.getRenderCenter(1.0f).subtract(look.scale(4.0)).add(0, 1.0, 0);
        Vec3 ballPos = ball.getCenter();
        boolean blockedByBlock = mc.level.clip(new ClipContext(camPos, ballPos,
                ClipContext.Block.VISUAL, ClipContext.Fluid.NONE, mc.player)).getType() != HitResult.Type.MISS;
        boolean blockedByCar = car.getBoundingBox().inflate(0.15).clip(camPos, ballPos).isPresent();
        ball.setClientXray(blockedByBlock || blockedByCar);
    }

    private static CustomBallEntity findBall(Minecraft mc, VehicleEntity car) {
        if (cachedBall != null && !cachedBall.isRemoved()) return cachedBall;
        var list = mc.level.getEntitiesOfClass(CustomBallEntity.class, car.getBoundingBox().inflate(250));
        cachedBall = list.isEmpty() ? null : list.get(0);
        return cachedBall;
    }
}
