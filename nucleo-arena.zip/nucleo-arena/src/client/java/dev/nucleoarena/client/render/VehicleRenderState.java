package dev.nucleoarena.client.render;

import net.minecraft.client.renderer.entity.state.EntityRenderState;
import org.joml.Quaternionf;

public class VehicleRenderState extends EntityRenderState {
    public final Quaternionf orientation = new Quaternionf();
    public float offX, offY, offZ;      // centro de render − posición de la entidad
    public int team, kind;
    public boolean demolished, boosting, supersonic, flipReady;
    public float alpha = 1f;
}
