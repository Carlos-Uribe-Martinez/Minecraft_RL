package dev.nucleoarena.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.nucleoarena.NucleoArena;
import dev.nucleoarena.entity.CustomBallEntity;
import dev.nucleoarena.physics.PhysicsConstants;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.resources.Identifier;

/** Núcleo energético: esfera emisiva con casillas alternas que rueda. Con X-Ray añade una silueta translúcida. */
public class BallRenderer extends EntityRenderer<CustomBallEntity, BallRenderState> {
    private static final Identifier WHITE = Identifier.fromNamespaceAndPath(NucleoArena.MOD_ID, "textures/entity/white.png");

    public BallRenderer(EntityRendererProvider.Context ctx) { super(ctx); }

    @Override public BallRenderState createRenderState() { return new BallRenderState(); }

    @Override
    public void extractRenderState(CustomBallEntity ball, BallRenderState s, float pt) {
        super.extractRenderState(ball, s, pt);
        s.roll.set(ball.getRoll(pt));
        s.xray = ball.isClientXray();
    }

    @Override
    public void submit(BallRenderState s, PoseStack ps, SubmitNodeCollector collector, CameraRenderState cam) {
        final float r = (float) PhysicsConstants.BALL_RADIUS;
        ps.pushPose();
        ps.translate(0.0, r, 0.0);                       // la entidad está en la base de su caja 1.8³
        ps.mulPose(s.roll);
        collector.submitCustomGeometry(ps, RenderTypes.entityCutout(WHITE), (pose, vc) ->
                Boxes.sphere(vc, pose, r, 8, 14, 0xFF7FE8FF, 0xFF1E9BD6, Boxes.FULL_BRIGHT));
        if (s.xray) {
            // ⚠ La silueta "a través de bloques" depende de que debugQuads() desactive el test de profundidad.
            collector.submitCustomGeometry(ps, RenderTypes.debugQuads(), (pose, vc) ->
                    Boxes.sphereFlat(vc, pose, r * 1.04f, 8, 14, 0x6600E5FF));
        }
        ps.popPose();
    }
}
