package dev.nucleoarena.client;

import com.mojang.blaze3d.platform.InputConstants;
import dev.nucleoarena.NucleoArena;
import dev.nucleoarena.entity.VehicleEntity;
import dev.nucleoarena.input.VehicleInput;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;       // 26.1+: antes keybinding.v1.KeyBindingHelper
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

/**
 * Lee el teclado una vez por tick de cliente. Con el coche como vehículo:
 *   1. predice el tick localmente (CarPredictor) → devuelve la entrada con su seq,
 *   2. la envía al servidor.
 *
 * W/S acelerar-reversa · A/D girar (o balanceo con Air Roll) · Espacio saltar/flip · Ctrl izq. boost
 * Alt izq. power-slide · Q air roll · C cambiar cámara · Mayús (sneak) bajar del coche
 */
public final class ClientInputHandler {
    private ClientInputHandler() {}

    private static final KeyMapping.Category CATEGORY =
            KeyMapping.Category.register(Identifier.fromNamespaceAndPath(NucleoArena.MOD_ID, "controls"));

    private static final KeyMapping BOOST     = key("boost",     GLFW.GLFW_KEY_LEFT_CONTROL);
    private static final KeyMapping HANDBRAKE = key("handbrake", GLFW.GLFW_KEY_LEFT_ALT);
    private static final KeyMapping AIR_ROLL  = key("air_roll",  GLFW.GLFW_KEY_Q);
    private static final KeyMapping CAMERA    = key("camera",    GLFW.GLFW_KEY_C);

    private static KeyMapping key(String name, int glfwKey) {
        return KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key." + NucleoArena.MOD_ID + "." + name, InputConstants.Type.KEYSYM, glfwKey, CATEGORY));
    }

    public static void init() {
        ClientTickEvents.END_CLIENT_TICK.register(ClientInputHandler::tick);
    }

    private static void tick(Minecraft mc) {
        if (mc.player == null || !(mc.player.getVehicle() instanceof VehicleEntity car)) return;

        while (CAMERA.consumeClick()) ArenaCamera.toggleMode();

        var o = mc.options;
        float throttle = (o.keyUp.isDown() ? 1f : 0f) - (o.keyDown.isDown() ? 1f : 0f);
        float steer    = (o.keyLeft.isDown() ? 1f : 0f) - (o.keyRight.isDown() ? 1f : 0f);

        boolean jumpPressed = false;                     // consumeClick acumula taps entre ticks
        while (o.keyJump.consumeClick()) jumpPressed = true;

        VehicleInput raw = new VehicleInput(0, throttle, steer, o.keyJump.isDown(), jumpPressed,
                BOOST.isDown(), HANDBRAKE.isDown(), AIR_ROLL.isDown());
        VehicleInput stamped = car.clientDrive(raw);
        ClientPlayNetworking.send(new VehicleInput.Payload(stamped));
    }
}
