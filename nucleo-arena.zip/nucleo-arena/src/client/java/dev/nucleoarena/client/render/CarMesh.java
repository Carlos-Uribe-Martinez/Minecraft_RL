package dev.nucleoarena.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.InputStream;

/**
 * Malla de coche precalculada (low-poly), cargada del classpath: {@code /assets/nucleo_arena/models/<nombre>.nmesh}.
 * Se generó a partir de modelos glTF (ver LICENSE_*.txt) ya orientada al marco del coche
 * (x = izquierda, y = arriba, z = adelante; ruedas tocando y = −0.8) y a la escala de la hitbox.
 *
 * Formato (big-endian): "NMSH", int versión, int nVértices, int nTriángulos,
 *   por vértice: 6 float (pos, normal), byte flag (1 = pintura de equipo), 3 byte (si flag=1: brillo, sombreado, 0;
 *   si no: r, g, b ya sombreados), y por triángulo: 3 ushort de índices.
 */
public final class CarMesh {
    private static final String[] FILES = { "nomad", "caribe" };
    private static final CarMesh[] CACHE = new CarMesh[FILES.length];
    private static final boolean[] TRIED = new boolean[FILES.length];

    private final float[] pos, nrm;
    private final boolean[] team;
    private final int[] c0, c1, c2;
    private final int[] idx;

    private CarMesh(float[] pos, float[] nrm, boolean[] team, int[] c0, int[] c1, int[] c2, int[] idx) {
        this.pos = pos; this.nrm = nrm; this.team = team; this.c0 = c0; this.c1 = c1; this.c2 = c2; this.idx = idx;
    }

    /** Malla del tipo de coche (0 = Nomad, 1 = Caribe) o null si no se pudo cargar (se usa el modelo de cajas). */
    public static CarMesh get(int kind) {
        int k = Math.max(0, Math.min(FILES.length - 1, kind));
        if (!TRIED[k]) {
            TRIED[k] = true;
            try (InputStream raw = CarMesh.class.getResourceAsStream("/assets/nucleo_arena/models/" + FILES[k] + ".nmesh")) {
                if (raw != null) CACHE[k] = read(new DataInputStream(new BufferedInputStream(raw)));
            } catch (Exception e) {
                CACHE[k] = null;
            }
        }
        return CACHE[k];
    }

    private static CarMesh read(DataInputStream in) throws Exception {
        byte[] magic = new byte[4];
        in.readFully(magic);
        if (magic[0] != 'N' || magic[1] != 'M' || magic[2] != 'S' || magic[3] != 'H') throw new IllegalStateException("bad mesh");
        in.readInt();                                   // versión
        int nv = in.readInt(), nt = in.readInt();
        float[] pos = new float[nv * 3], nrm = new float[nv * 3];
        boolean[] team = new boolean[nv];
        int[] c0 = new int[nv], c1 = new int[nv], c2 = new int[nv];
        for (int i = 0; i < nv; i++) {
            for (int j = 0; j < 3; j++) pos[i * 3 + j] = in.readFloat();
            for (int j = 0; j < 3; j++) nrm[i * 3 + j] = in.readFloat();
            team[i] = in.readUnsignedByte() == 1;
            c0[i] = in.readUnsignedByte(); c1[i] = in.readUnsignedByte(); c2[i] = in.readUnsignedByte();
        }
        int[] idx = new int[nt * 3];
        for (int i = 0; i < idx.length; i++) idx[i] = in.readUnsignedShort();
        return new CarMesh(pos, nrm, team, c0, c1, c2, idx);
    }

    /** Dibuja la malla. Cada triángulo se emite como un quad degenerado (último vértice repetido). */
    public void emit(VertexConsumer vc, PoseStack.Pose pose, int teamRgb, float alpha, int light) {
        int a = Math.round(Math.max(0f, Math.min(1f, alpha)) * 255f) << 24;
        int tr = (teamRgb >> 16) & 255, tg = (teamRgb >> 8) & 255, tb = teamRgb & 255;
        for (int t = 0; t < idx.length; t += 3) {
            for (int k = 0; k < 4; k++) {
                int i = idx[t + Math.min(k, 2)];
                int col;
                if (team[i]) {
                    float f = c0[i] / 255f * 1.5f * (c1[i] / 255f);
                    col = a | (clamp(tr * f) << 16) | (clamp(tg * f) << 8) | clamp(tb * f);
                } else {
                    col = a | (c0[i] << 16) | (c1[i] << 8) | c2[i];
                }
                Boxes.v(vc, pose, pos[i * 3], pos[i * 3 + 1], pos[i * 3 + 2], col, light,
                        nrm[i * 3], nrm[i * 3 + 1], nrm[i * 3 + 2]);
            }
        }
    }

    private static int clamp(float v) { return Math.max(0, Math.min(255, Math.round(v))); }
}
