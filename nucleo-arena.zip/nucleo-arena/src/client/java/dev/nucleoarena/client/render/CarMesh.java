package dev.nucleoarena.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Malla low-poly horneada (triángulos con color plano) a partir de modelos glTF (ver CREDITS.md).
 * Archivo: assets/nucleo_arena/models/NAME.mesh, una línea por triángulo:
 *   t x0 y0 z0 x1 y1 z1 x2 y2 z2 nx ny nz RRGGBB cuerpo(0/1)
 * Espacio local del coche: x = izquierda, y = arriba, z = adelante; las ruedas tocan y = −0.8.
 * Los triángulos de "cuerpo" se tiñen con el color del equipo. Se dibuja a doble cara (sin depender del culling).
 */
public final class CarMesh {
    private final float[] pos;      // 9 por triángulo
    private final float[] nrm;      // 3 por triángulo
    private final int[] color;      // RGB por triángulo
    private final boolean[] body;
    private final int count;

    private static final Map<String, CarMesh> CACHE = new HashMap<>();

    /** @return la malla, o null si no se pudo cargar (el renderer usa entonces las cajas procedurales). */
    public static CarMesh get(String name) {
        return CACHE.computeIfAbsent(name, CarMesh::load);
    }

    private static CarMesh load(String name) {
        String path = "/assets/nucleo_arena/models/" + name + ".mesh";
        try (InputStream in = CarMesh.class.getResourceAsStream(path)) {
            if (in == null) return null;
            BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
            List<String[]> rows = new ArrayList<>();
            for (String line; (line = br.readLine()) != null; ) {
                if (line.startsWith("t ")) rows.add(line.split(" "));
            }
            return new CarMesh(rows);
        } catch (Exception e) {
            return null;
        }
    }

    private CarMesh(List<String[]> rows) {
        count = rows.size();
        pos = new float[count * 9]; nrm = new float[count * 3]; color = new int[count]; body = new boolean[count];
        for (int i = 0; i < count; i++) {
            String[] r = rows.get(i);
            for (int k = 0; k < 9; k++) pos[i * 9 + k] = Float.parseFloat(r[1 + k]);
            for (int k = 0; k < 3; k++) nrm[i * 3 + k] = Float.parseFloat(r[10 + k]);
            color[i] = Integer.parseInt(r[13], 16);
            body[i] = "1".equals(r[14]);
        }
    }

    public void draw(VertexConsumer vc, PoseStack.Pose pose, int bodyRgb, float alpha, int light) {
        for (int i = 0; i < count; i++) {
            int rgb = body[i] ? bodyRgb : color[i];
            float nx = nrm[i * 3], ny = nrm[i * 3 + 1], nz = nrm[i * 3 + 2];
            float lit = 0.58f + 0.42f * (0.5f + 0.5f * ny);              // sombreado falso según la normal
            int c = Boxes.shade(Boxes.argb(rgb, alpha), lit);
            int o = i * 9;
            // cara frontal (sentido antihorario); el 4.º vértice repite el 3.º (triángulo como quad)
            Boxes.v(vc, pose, pos[o],     pos[o + 1], pos[o + 2], c, light, nx, ny, nz);
            Boxes.v(vc, pose, pos[o + 3], pos[o + 4], pos[o + 5], c, light, nx, ny, nz);
            Boxes.v(vc, pose, pos[o + 6], pos[o + 7], pos[o + 8], c, light, nx, ny, nz);
            Boxes.v(vc, pose, pos[o + 6], pos[o + 7], pos[o + 8], c, light, nx, ny, nz);
            // cara trasera (orden inverso, normal opuesta)
            Boxes.v(vc, pose, pos[o + 6], pos[o + 7], pos[o + 8], c, light, -nx, -ny, -nz);
            Boxes.v(vc, pose, pos[o + 3], pos[o + 4], pos[o + 5], c, light, -nx, -ny, -nz);
            Boxes.v(vc, pose, pos[o],     pos[o + 1], pos[o + 2], c, light, -nx, -ny, -nz);
            Boxes.v(vc, pose, pos[o],     pos[o + 1], pos[o + 2], c, light, -nx, -ny, -nz);
        }
    }
}
