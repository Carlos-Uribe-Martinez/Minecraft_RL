package dev.nucleoarena.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Malla low-poly horneada (triángulos con color plano) a partir de modelos glTF (ver CREDITS.md).
 * Archivo: assets/nucleo_arena/models/NAME.mesh, una línea por triángulo:
 *   t x0 y0 z0 x1 y1 z1 x2 y2 z2 nx ny nz RRGGBB cuerpo(0/1)
 * Espacio local del coche: x = izquierda, y = arriba, z = adelante; las ruedas tocan y = −0.8.
 * Los triángulos de "cuerpo" se tiñen con el color del equipo. Se dibuja a doble cara (sin depender del culling).
 */
public final class CarMesh {
    private final float[] pos;      // 9 por triángulo
    private final float[] nrm;      // 3 por triángulo
    private final int[] color;      // RGB por triángulo
    private final boolean[] body;
    private final int count;

    private static final Map<String, CarMesh> CACHE = new HashMap<>();

    /** @return la malla, o null si no se pudo cargar (el renderer usa entonces las cajas procedurales). */
    public static CarMesh get(String name) {
        return CACHE.computeIfAbsent(name, CarMesh::load);
    }

    private static CarMesh load(String name) {
        String path = "/assets/nucleo_arena/models/" + name + ".mesh";
        try (InputStream in = CarMesh.class.getResourceAsStream(path)) {
            if (in == null) return null;
            BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
            List<String[]> rows = new ArrayList<>();
            for (String line; (line = br.readLine()) != null; ) {
                if (line.startsWith("t ")) rows.add(line.split(" "));
            }
            return new CarMesh(rows);
        } catch (Exception e) {
            return null;
        }
    }

    private CarMesh(List<String[]> rows) {
        count = rows.size();
        pos = new float[count * 9]; nrm = new float[count * 3]; color = new int[count]; body = new boolean[count];
        for (int i = 0; i < count; i++) {
            String[] r = rows.get(i);
            for (int k = 0; k < 9; k++) pos[i * 9 + k] = Float.parseFloat(r[1 + k]);
            for (int k = 0; k < 3; k++) nrm[i * 3 + k] = Float.parseFloat(r[10 + k]);
            color[i] = Integer.parseInt(r[13], 16);
            body[i] = "1".equals(r[14]);
        }
    }

    // Luz "de estudio" en el espacio del modelo (x izq., y arriba, z adelante): cielo arriba-delante y relleno lateral
    private static final float[] KEY = norm(0.35f, 0.85f, 0.40f), FILL = norm(-0.7f, 0.35f, -0.3f);

    private static float[] norm(float x, float y, float z) {
        float l = (float) Math.sqrt(x * x + y * y + z * z);
        return new float[] { x / l, y / l, z / l };
    }

    public void draw(VertexConsumer vc, PoseStack.Pose pose, int bodyRgb, float alpha, int light) {
        // Mínimo de luz: el coche nunca se ve apagado aunque esté en una zona oscura de la cancha
        int sky = Math.max((light >> 20) & 15, 9), blk = Math.max((light >> 4) & 15, 9);
        light = (sky << 20) | (blk << 4);

        for (int i = 0; i < count; i++) {
            int rgb = body[i] ? bodyRgb : color[i];
            float nx = nrm[i * 3], ny = nrm[i * 3 + 1], nz = nrm[i * 3 + 2];
            float lit = 0.66f + 0.34f * (0.5f + 0.5f * ny);              // sombreado según la normal

            int r = (rgb >> 16) & 255, g = (rgb >> 8) & 255, b = rgb & 255;
            boolean glass = !body[i] && (r + g + b) < 190;               // cristales y piezas oscuras: más reflectantes
            float dKey = Math.max(0f, nx * KEY[0] + ny * KEY[1] + nz * KEY[2]);
            float dFill = Math.max(0f, nx * FILL[0] + ny * FILL[1] + nz * FILL[2]);
            // Reflejo del cielo en superficies que miran arriba (tinte azulado) y del suelo en las que miran abajo
            float sky2 = Math.max(0f, ny) * (body[i] ? 0.30f : glass ? 0.45f : 0.10f);
            r += (int) ((190 - r) * sky2); g += (int) ((215 - g) * sky2); b += (int) ((255 - b) * sky2);
            // Brillo especular (laca metálica): punto fuerte + halo, más intenso en cristales
            float spec = (float) Math.pow(dKey, body[i] ? 22.0 : glass ? 14.0 : 8.0) * (body[i] ? 0.55f : glass ? 0.80f : 0.15f)
                       + (float) Math.pow(dFill, 18.0) * (body[i] ? 0.20f : 0.10f);
            int s255 = (int) (255 * Math.min(spec, 0.9f));
            r = Math.min(255, (int) (r * lit) + s255); g = Math.min(255, (int) (g * lit) + s255); b = Math.min(255, (int) (b * lit) + s255);
            int c = Boxes.argb((r << 16) | (g << 8) | b, alpha);
            int o = i * 9;
            // cara frontal (sentido antihorario); el 4.º vértice repite el 3.º (triángulo como quad)
            Boxes.v(vc, pose, pos[o],     pos[o + 1], pos[o + 2], c, light, nx, ny, nz);
            Boxes.v(vc, pose, pos[o + 3], pos[o + 4], pos[o + 5], c, light, nx, ny, nz);
            Boxes.v(vc, pose, pos[o + 6], pos[o + 7], pos[o + 8], c, light, nx, ny, nz);
            Boxes.v(vc, pose, pos[o + 6], pos[o + 7], pos[o + 8], c, light, nx, ny, nz);
            // cara trasera (orden inverso, normal opuesta)
            Boxes.v(vc, pose, pos[o + 6], pos[o + 7], pos[o + 8], c, light, -nx, -ny, -nz);
            Boxes.v(vc, pose, pos[o + 3], pos[o + 4], pos[o + 5], c, light, -nx, -ny, -nz);
            Boxes.v(vc, pose, pos[o],     pos[o + 1], pos[o + 2], c, light, -nx, -ny, -nz);
            Boxes.v(vc, pose, pos[o],     pos[o + 1], pos[o + 2], c, light, -nx, -ny, -nz);
        }
    }
}
