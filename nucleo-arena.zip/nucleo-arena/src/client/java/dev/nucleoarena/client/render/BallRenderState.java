package dev.nucleoarena.client.render;

import net.minecraft.client.renderer.entity.state.EntityRenderState;
import org.joml.Quaternionf;

public class BallRenderState extends EntityRenderState {
    public final Quaternionf roll = new Quaternionf();
    public boolean xray;
    public boolean puppet;     // lo representa un cubo de azufre: no se dibuja
    public float speed;     // b/t
}
