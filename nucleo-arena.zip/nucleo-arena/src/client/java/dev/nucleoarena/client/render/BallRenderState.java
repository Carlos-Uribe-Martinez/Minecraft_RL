package dev.nucleoarena.client.render;

import net.minecraft.client.renderer.entity.state.EntityRenderState;
import org.joml.Quaternionf;

public class BallRenderState extends EntityRenderState {
    public final Quaternionf roll = new Quaternionf();
    public boolean xray;
    public float speed;     // b/t
}
